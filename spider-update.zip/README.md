> **v0.5.2 Phase-2 research:** added signed NIL/block prevotes and precommits, a local anti-equivocation signing journal, strict weighted QCs, a non-finalizing round-rule model and 11 Rust regression tests. Legacy VoteGuard and live monetary behavior remain untouched. See [phase-2 specification](docs/SPIDERBFT_PHASE2_V052.md) and [release notes](docs/V052_RELEASE_NOTES.md).

> **v0.5.1 BFT design safety gate:** an executable model exposes a current liveness blocker: first-prevote height locks can permanently stall four honest validators. No production finality has been enabled. See [design analysis](docs/SPIDERBFT_PHASE2_DESIGN_V051.md) and [release notes](docs/V051_RELEASE_NOTES.md).

> **v0.5.0 research milestone:** added separate-process proposal/prevote/precommit integration harness. This is **NOT** autonomous distributed consensus, block finality, smart contracts, or mainnet. See [v0.5 release notes](docs/V050_RELEASE_NOTES.md).

# Spider Chain v0.5.2 — Independent Layer-1 Research Prototype

**STATUS: DEVNET RESEARCH ONLY — NOT A LIVE BLOCKCHAIN OR REAL-MONEY SYSTEM.**

Spider Chain is being developed independently in Rust without Cosmos SDK, CometBFT, Ethereum or another blockchain engine. It uses well-established cryptographic and system libraries (Ed25519, SHA-256, Bech32m, serde).

Our long-term goal: direct international transfers in which the receiver obtains the full amount of **real USDT** and the sender pays a small, clearly shown **SPD** network fee separately. **Real USDT, USD-indexed fees, BFT finality, guaranteed low fees and mainnet SPD do not exist yet.** `tUSD` is a fictional test-only asset with no backing or monetary value.

## Development status

| Component | Status |
|---|---|
| Canonical account, signed transfers, nonce, SPD fee, test `tUSD` | Local prototype |
| Locally generated blocks and state hashes | Local prototype, unfinalized |
| Persisted blocks and 127.0.0.1-only RPC | Local prototype |
| Local P2P handshake and block sync | Local prototype, unfinalized |
| **v0.4: static validator set, weighted votes, quorum certificates and durable vote guard** | **Offline safety research, NOT live consensus** |
| **v0.4.1 research: signed timeout quorums, deterministic proposer rotation, fault-injected four-validator rounds** | **In-process simulation; NOT live P2P consensus** |
| **v0.4.4 research: crash-replayable round sequence, conservative cross-round lock and loopback delivery** | **Safety research; NOT distributed finality** |
| Real validator P2P voting, proposer authentication, full locks/unlocks and liveness | Not implemented |
| Spider VM, token factory, staking/slashing and tokenomics | Not implemented |
| Public network, audits, real SPD and USDT | Not implemented |

## Quick verification (Rust stable)

```bash
cargo fmt --all -- --check
cargo check --all-targets
cargo test --all-targets
cargo clippy --all-targets
cargo run --bin spider-node -- demo
# Optional local two-process BFT wire research: see docs/BFT_WIRE_V042.md
```

Read [SpiderBFT research specification](docs/SPIDERBFT.md), [P2P v0.3](docs/P2P_V03.md), [RPC v0.2](docs/RPC_V02.md), [wallet compatibility](docs/WALLET_COMPATIBILITY.md) and [threat model](docs/THREAT_MODEL.md).

**Do not use this repository with actual cryptocurrency, private real-world keys, or exposed public RPC/P2P.** Test key material is publicly known. No security audit has been performed.

## Repository update process

Upload the cumulative patch named `spider-update.zip` to the root of the `kepler-blockchain` repo. The existing `.github/workflows/spider-upgrade.yml` installer validates and tests it before committing source changes and removing the ZIP. **Keep the existing YAML files; do not create a new installer for each release.** If a prior ZIP is still tracked, replace/delete that failed-upload ZIP before installing the new one.

Read [v0.4.3 authenticated transport notes](docs/BFT_WIRE_V042.md) and [v0.4.1 research notes](docs/BFT_ROUNDS_V041.md) for the timeout/view-change simulator and strict limitations.

## Next milestones

1. v0.4.x: signed proposals, durable consensus WAL, nil-vote/locking rules, round-change correctness and model checks.
2. v0.5+: a complete replicated BFT state machine and verified certificate-driven block finalization.
3. Spider VM with deterministic execution and resource accounting.
4. Independent-operator Testnet, economic security, fuzzing, external audits, mainnet readiness review.


## SpiderBFT v0.4.4 — conservative multi-round research

Added authenticated leader proposals, phase-gated vote reception, bounded
recoverable receive journals, localhost TCP research mode, and new negative
integration tests across four separate receivers. See
[docs/BFT_RESEARCH_V043.md](docs/BFT_RESEARCH_V043.md). **No live BFT finality.**

### New in v0.4.4

- A durable round book refuses to skip rounds or accept a new candidate after a prior signed prevote quorum.
- One research writer per journal directory; an unclean crash leaves a **stale** lease that requires careful manual recovery.
- TCP-sent research messages can be persisted and replayed by the round book; they **never** finalize blocks.
- Expanded regression tests cover restarts, damaged history, conflicting round proposals and 4-validator quorum intersection.

See [v0.4.4 release notes](docs/V044_RELEASE_NOTES.md). The GitHub CI build has **not** been verified in this environment.

## v0.4.5 Research verification gate

Four **separate** loopback SpiderBFT research receiver processes and a bounded exhaustive weighted quorum prerequisite check are added to existing Rust CI tests. These checks are not proof of live BFT safety or finality. See [v0.4.5 gate](docs/V045_PROCESS_AND_SAFETY_GATE.md).

## Cumulative Block 2 reactor (31 October 2026)

A durable multi-value reactor and `spider-node validator` private runner are now
implemented. See [acceptance and remaining limits](docs/BLOCK_02_REACTOR_ACCEPTANCE.md)
and [executed checks](docs/BLOCK_02_VERIFICATION.txt). This bounded candidate is
not a completed unbounded protocol or a production release.

## 2026-11-04 research hardening candidate

The cumulative CI repair, durable replay fairness patch, four-process
partition/recovery regression gate, and independent state-root comparator are
documented in [the 2026-11-04 release-gate report](docs/RELEASE_GATE_20261104.md).
**No Rust build, GitHub run, four real remote servers, or security audit has
been confirmed by this release package. It is NOT ready for mainnet.**

## 2026-11-04 Block 3 operations candidate (DEVNET ONLY)

Added a bounded durable validator-side queue, crash/restart safeguards and
refusal to promote HTTP 202 to finality. The gateway now preserves an original
spooled transfer on repeated-POST rejection. Added an optional chmod-600 signing
`key_file`, offline state backup/restore integrity checker, independently
configured HTTPS health monitoring with lag/staleness alarms, strict wallet
receipt shape checks and iOS reference pending-ID persistence.

- [Block 3 operations and backup](docs/BLOCK_03_OPERATIONS_20261104.md)
- [Wallet / iPhone end-to-end acceptance](docs/WALLET_E2E_ACCEPTANCE_20261104.md)
- [SPD economics/genesis/governance/legal review](docs/SPD_MAINNET_DECISION_RECORD_20261104.md)
- Run: `python3 -m unittest discover -s ops/tests -p 'test*.py' -v`
- `python3 ops/mainnet_policy_gate.py --require-complete` deliberately exits 2.

**NOT DONE:** native Cargo CI, four actual independent hosts, physical iPhone
end-to-end TestFlight, security audit, legal approvals, SPD issuance, public
network and any real USD token integration. Never run with real funds.
