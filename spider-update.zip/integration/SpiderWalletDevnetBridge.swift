// Optional application-level integration facade for Spider Wallet iOS 17+.
// This is TEST SPD on the research devnet only, not a mainnet asset.
// Import alongside SpiderDevnetSigner.swift + SpiderCertifiedWalletClient.swift.
// Private keys stay in the app; this bridge never persists or uploads them.
import Foundation
import CryptoKit

struct SpiderQueuedDevnetTransfer {
    let id: String
    let from: String
    let to: String
    let amountAtomic: UInt64
    // This is not a BFT commit. Show "Pending (test SPD)" in the UI.
    let finalized: Bool = false
}

enum SpiderWalletBridgeError: Error {
    case incompatibleIdentity
    case pendingAccountTransfer
    case insufficientCertifiedBalance
    case arithmeticOverflow
    case invalidRecipient
    case staleCertifiedState
    case invalidFinalityResponse
}

actor SpiderWalletDevnetBridge {
    private let client: SpiderCertifiedWalletClient
    private var reservedSenders = Set<String>()
    // Protect certified nonces from re-use until this app sees BFT confirmation.
    // Non-secret TX IDs survive an iOS process restart; no seed/private key is stored.
    private var pendingBySender: [String: String]
    private let defaults: UserDefaults
    private let storageKey: String

    init(client: SpiderCertifiedWalletClient, defaults: UserDefaults = .standard) {
        self.client = client
        self.defaults = defaults
        self.storageKey = "SpiderDevnetPending.\(client.expectedChainID).\(client.expectedGenesisHash)"
        let saved = defaults.dictionary(forKey: self.storageKey) as? [String: String] ?? [:]
        self.pendingBySender = saved.filter { sender, id in
            sender.hasPrefix("spider1") && id.count == 64 &&
            id.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) })
        }
    }

    private func persistPending() {
        defaults.set(pendingBySender, forKey: storageKey)
    }

    // Do not drop an unconfirmed TX after a timeout, restart or network error.
    // Only a certified receipt from the pinned gateway may clear its reservation.
    func reconcilePendingAfterRestart() async throws {
        for (sender, id) in pendingBySender {
            let receipt = try await client.confirmation(id)
            if receipt.finalized {
                guard receipt.height != nil, receipt.block_hash != nil else {
                    throw SpiderWalletBridgeError.invalidFinalityResponse
                }
                pendingBySender.removeValue(forKey: sender)
            }
        }
        persistPending()
    }

    func sendTestSPD(to recipient: String, amountAtomic: UInt64,
                     signingKey: Curve25519.Signing.PrivateKey) async throws -> SpiderQueuedDevnetTransfer {
        let sender = SpiderDevnetSigner.address(for: signingKey.publicKey.rawRepresentation)
        // Prevent same-wallet local concurrent sends from reusing a certified nonce.
        guard pendingBySender[sender] == nil, reservedSenders.insert(sender).inserted else {
            throw SpiderWalletBridgeError.pendingAccountTransfer
        }
        defer { reservedSenders.remove(sender) }
        guard recipient.hasPrefix("spider1"), recipient.count == sender.count,
              recipient.utf8.allSatisfy({ $0 >= 33 && $0 <= 126 }) else {
            throw SpiderWalletBridgeError.invalidRecipient
        }
        let status = try await client.status()  // Pins network & genesis.
        guard !status.real_spd, !status.real_usdt,
              status.chain_id == SpiderDevnetSigner.chainID else {
            throw SpiderWalletBridgeError.incompatibleIdentity
        }
        let account = try await client.account(sender)
        guard account.height <= status.height && account.chain_id == status.chain_id,
              account.address == sender else { throw SpiderWalletBridgeError.staleCertifiedState }
        let (fee, feeOverflow) = SpiderDevnetSigner.baseGas.multipliedReportingOverflow(by: SpiderDevnetSigner.defaultGasPrice)
        let (total, totalOverflow) = amountAtomic.addingReportingOverflow(fee)
        guard !feeOverflow, !totalOverflow else { throw SpiderWalletBridgeError.arithmeticOverflow }
        guard account.balances["SPD", default: 0] >= total else {
            throw SpiderWalletBridgeError.insufficientCertifiedBalance
        }
        let transfer = try SpiderDevnetSigner.makeSPDTransfer(
            from: sender, to: recipient, amountAtomic: amountAtomic,
            nonce: account.nonce, certifiedHeight: status.height)
        let signed = try SpiderDevnetSigner.sign(transfer, privateKey: signingKey)
        // Reserve before crossing the network: a lost HTTP response must not
        // permit a second send using the same certified account nonce.
        pendingBySender[sender] = signed.id()
        persistPending()
        let receipt = try await client.submit(signed) // HTTP 202, not confirmation.
        guard receipt.id == signed.id() && !receipt.real_spd && !receipt.broadcast else {
            throw SpiderWalletBridgeError.invalidFinalityResponse
        }
        pendingBySender[sender] = receipt.id
        persistPending()
        return SpiderQueuedDevnetTransfer(id: receipt.id, from: sender,
                                          to: recipient, amountAtomic: amountAtomic)
    }

    func certifiedConfirmation(_ transactionID: String) async throws -> SpiderTransactionConfirmation {
        let result = try await client.confirmation(transactionID)
        if result.finalized {
            guard result.height != nil, result.block_hash != nil else {
                throw SpiderWalletBridgeError.invalidFinalityResponse
            }
            let cleared = pendingBySender.filter { $0.value == transactionID }.map { $0.key }
            for sender in cleared { pendingBySender.removeValue(forKey: sender) }
            persistPending()
        }
        return result
    }
}
