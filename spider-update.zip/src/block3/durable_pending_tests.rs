//! Durable validator queue acceptance gates, separate from BFT finality proofs.
use crate::{
    address, consensus::{Validator, ValidatorSet},
    finality_gate::certified_node::CertifiedNode,
    ledger::{Account, Asset, Genesis, Ledger},
    tx::{SignedTransfer, Transfer}, BASE_TRANSFER_GAS, SPD,
};
use ed25519_dalek::SigningKey;
use std::{collections::BTreeMap, fs, path::PathBuf, sync::atomic::{AtomicU64, Ordering}};

static SERIAL: AtomicU64 = AtomicU64::new(0);
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!("spider-block3-pending-{}-{}", std::process::id(), SERIAL.fetch_add(1, Ordering::Relaxed)));
        fs::create_dir(&path).unwrap();
        Self(path)
    }
}
impl Drop for Temp { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); } }

fn fixture() -> (Genesis, ValidatorSet, SigningKey, String) {
    let owner = SigningKey::from_bytes(&[89_u8; 32]);
    let addr = address::from_public_key(&owner.verifying_key().to_bytes());
    let genesis = Genesis {
        chain_id: "spider-devnet-1".into(), timestamp_ms: 1,
        assets: vec![Asset { id: SPD.into(), decimals: 9, initial_supply: 1_000_000 }],
        accounts: BTreeMap::from([(addr.clone(), Account { nonce: 0, balances: BTreeMap::from([(SPD.into(), 1_000_000)]) })]),
    };
    let ledger = Ledger::from_genesis(genesis.clone()).unwrap();
    let validators = (1..=4).map(|n| Validator {public_key: hex::encode(SigningKey::from_bytes(&[n; 32]).verifying_key().to_bytes()), power: 1}).collect();
    let set = ValidatorSet::new(ledger.chain_id, ledger.genesis_hash, validators).unwrap();
    (genesis, set, owner, addr)
}
fn signed(owner: &SigningKey, addr: &str) -> SignedTransfer {
    Transfer { chain_id: "spider-devnet-1".into(), sender: addr.into(), recipient: addr.into(),
        asset_id: SPD.into(), amount: 10, nonce: 0, gas_limit: BASE_TRANSFER_GAS,
        max_fee_per_gas: 1, expiry_height: 20 }.sign(owner)
}

#[test]
fn survives_validator_restart_without_promoting_to_finality() {
    let t = Temp::new();
    let dir = t.0.join("node");
    let (genesis, set, key, addr) = fixture();
    let tx = signed(&key, &addr);
    {
        let mut node = CertifiedNode::open(&dir, genesis.clone(), set.clone()).unwrap();
        node.submit(tx.clone(), 10).unwrap();
        assert_eq!(node.height(), 0);
        assert_eq!(node.pending_transfers(), &[tx.clone()]);
    }
    let mut restarted = CertifiedNode::open(&dir, genesis, set).unwrap();
    assert_eq!(restarted.height(), 0);
    assert_eq!(restarted.pending_transfers(), &[tx.clone()]);
    assert!(restarted.candidate(10).unwrap().transactions.iter().any(|t| t.id() == tx.id()));
    assert!(restarted.submit(tx, 10).is_err());
}

#[test]
fn corrupt_snapshot_fails_closed() {
    let t = Temp::new();
    let dir = t.0.join("node");
    let (genesis, set, key, addr) = fixture();
    {
        let mut node = CertifiedNode::open(&dir, genesis.clone(), set.clone()).unwrap();
        node.submit(signed(&key, &addr), 10).unwrap();
    }
    let pending = dir.with_extension("pending").join("pending.json");
    fs::write(&pending, b"{\"version\":1,\"transfers\":[]}").unwrap();
    assert!(CertifiedNode::open(&dir, genesis, set).is_err());
}

#[test]
fn foreign_validator_set_cannot_read_prior_queue() {
    let t = Temp::new();
    let dir = t.0.join("node");
    let (genesis, set, _, _) = fixture();
    { let _node = CertifiedNode::open(&dir, genesis.clone(), set.clone()).unwrap(); }
    let mut snap: serde_json::Value = serde_json::from_slice(&fs::read(dir.with_extension("pending").join("pending.json")).unwrap()).unwrap();
    snap["set_hash"] = "forged".into();
    fs::write(dir.with_extension("pending").join("pending.json"), serde_json::to_vec(&snap).unwrap()).unwrap();
    assert!(CertifiedNode::open(&dir, genesis, set).is_err());
}

#[cfg(unix)]
#[test]
fn symbolic_link_pending_directory_is_forbidden() {
    use std::os::unix::fs::symlink;
    let t = Temp::new();
    let dir = t.0.join("node");
    symlink(&t.0, dir.with_extension("pending")).unwrap();
    let (genesis, set, _, _) = fixture();
    assert!(CertifiedNode::open(&dir, genesis, set).is_err());
}

#[test]
fn missing_snapshot_from_existing_queue_fails_closed() {
    let t = Temp::new();
    let dir = t.0.join("node");
    let (genesis, set, _, _) = fixture();
    { let _node = CertifiedNode::open(&dir, genesis.clone(), set.clone()).unwrap(); }
    fs::remove_file(dir.with_extension("pending").join("pending.json")).unwrap();
    assert!(CertifiedNode::open(&dir, genesis, set).is_err());
}
