//! Crash-recoverable, bounded validator-side signed-transfer queue (devnet only).
//! Admission is NOT certification. The finality journal remains the only source
//! of committed state; an inconsistent pending snapshot fails closed.
use crate::{ledger::Ledger, tx::SignedTransfer};
use serde::{Deserialize, Serialize};
use std::{fs::{self, File, OpenOptions}, io::{Read, Write}, path::{Path, PathBuf}};

const CAP: u64 = 1024 * 1024;
const MAX_PENDING: usize = 128;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Snapshot {
    version: u8,
    chain_id: String,
    genesis_hash: String,
    set_hash: String,
    certified_height: u64,
    transfers: Vec<SignedTransfer>,
}

pub struct PendingStore {
    dir: PathBuf,
    chain_id: String,
    genesis_hash: String,
    set_hash: String,
}

fn metadata_file(path: &Path) -> Result<Option<u64>, String> {
    match fs::symlink_metadata(path) {
        Ok(m) if m.is_file() && !m.file_type().is_symlink() && m.len() <= CAP => Ok(Some(m.len())),
        Ok(_) => Err("unsafe, non-regular or oversized pending snapshot".into()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(e) => Err(e.to_string()),
    }
}

fn candidate_time(ledger: &Ledger) -> u64 {
    ledger.blocks.last().map_or(1, |b| b.timestamp_ms)
}

fn validate_queue(ledger: &Ledger, transactions: &[SignedTransfer]) -> Result<(), String> {
    if transactions.len() > MAX_PENDING {
        return Err("pending queue exceeds bounded capacity".into());
    }
    let mut ids = std::collections::BTreeSet::new();
    for tx in transactions {
        if !tx.verify_signature() || !ids.insert(tx.id()) {
            return Err("invalid signature or duplicate durable transaction".into());
        }
    }
    ledger.make_block(transactions.to_vec(), candidate_time(ledger))
        .map_err(|e| format!("pending transaction needs operator reconciliation: {e}"))?;
    Ok(())
}

impl PendingStore {
    pub fn open(path: impl AsRef<Path>, ledger: &Ledger, set_hash: &str) -> Result<(Self, Vec<SignedTransfer>), String> {
        let path = path.as_ref();
        let existed = match fs::symlink_metadata(path) {
            Ok(meta) if meta.is_dir() && !meta.file_type().is_symlink() => true,
            Ok(_) => return Err("unsafe pending store directory".into()),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                #[cfg(unix)] {
                    use std::os::unix::fs::DirBuilderExt;
                    let mut builder = fs::DirBuilder::new();
                    builder.mode(0o700);
                    builder.create(path).map_err(|e| e.to_string())?;
                }
                #[cfg(not(unix))] fs::create_dir(path).map_err(|e| e.to_string())?;
                false
            },
            Err(e) => return Err(e.to_string()),
        };
        let dir = fs::canonicalize(path).map_err(|e| e.to_string())?;
        let store = Self { dir, chain_id: ledger.chain_id.clone(), genesis_hash: ledger.genesis_hash.clone(), set_hash: set_hash.to_string() };
        let file = store.dir.join("pending.json");
        let recovered = if metadata_file(&file)?.is_some() {
            let mut data = Vec::new();
            File::open(&file).map_err(|e| e.to_string())?.take(CAP + 1)
                .read_to_end(&mut data).map_err(|e| e.to_string())?;
            if data.len() as u64 > CAP { return Err("oversized durable pending snapshot".into()); }
            let snapshot: Snapshot = serde_json::from_slice(&data).map_err(|e| e.to_string())?;
            if snapshot.version != 1 || snapshot.chain_id != store.chain_id || snapshot.genesis_hash != store.genesis_hash
                || snapshot.set_hash != store.set_hash || snapshot.certified_height > ledger.height() {
                return Err("pending snapshot chain, validators or height mismatch".into());
            }
            if snapshot.transfers.len() > MAX_PENDING { return Err("pending snapshot capacity exceeded".into()); }
            // A crash can occur after the certified block reached stable storage
            // but before the queue snapshot advanced. Remove ONLY IDs that are
            // demonstrably in authenticated, replayed certified history.
            let committed: std::collections::BTreeSet<_> = ledger.blocks.iter().flat_map(|b| b.transactions.iter().map(|t| t.id())).collect();
            let remaining: Vec<_> = snapshot.transfers.into_iter().filter(|tx| !committed.contains(&tx.id())).collect();
            validate_queue(ledger, &remaining)?; // fail closed on any other invalid record
            remaining
        } else {
            if existed {
                return Err("missing durable snapshot from existing pending store".into());
            }
            // One-time upgrade from the earlier volatile mempool. No old
            // in-memory records can be reconstructed from disk.
            Vec::new()
        };
        store.save(&recovered, ledger.height())?;
        Ok((store, recovered))
    }

    pub fn save(&self, transactions: &[SignedTransfer], height: u64) -> Result<(), String> {
        if transactions.len() > MAX_PENDING { return Err("pending queue capacity exceeded".into()); }
        let snapshot = Snapshot { version: 1, chain_id: self.chain_id.clone(), genesis_hash: self.genesis_hash.clone(),
            set_hash: self.set_hash.clone(), certified_height: height, transfers: transactions.to_vec() };
        let bytes = serde_json::to_vec(&snapshot).map_err(|e| e.to_string())?;
        if bytes.len() as u64 > CAP { return Err("pending snapshot exceeds 1 MiB cap".into()); }
        let tmp = self.dir.join("pending.tmp");
        if metadata_file(&tmp)?.is_some() { fs::remove_file(&tmp).map_err(|e| e.to_string())?; }
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; options.mode(0o600); }
        let mut f = options.open(&tmp).map_err(|e| e.to_string())?;
        f.write_all(&bytes).and_then(|_| f.sync_all()).map_err(|e| e.to_string())?;
        fs::rename(&tmp, self.dir.join("pending.json")).map_err(|e| e.to_string())?;
        File::open(&self.dir).and_then(|d| d.sync_all()).map_err(|e| e.to_string())
    }
}

#[cfg(test)]
#[path = "durable_pending_tests.rs"]
mod tests;
