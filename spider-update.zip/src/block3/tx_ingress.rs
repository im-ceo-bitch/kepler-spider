//! Block 3: bounded, loopback-only signed-transfer ingress into the *real*
//! SpiderBFT reactor. 202 means queued locally, NOT gossiped, finalized, or
//! even guaranteed to be selected by the nominated block proposer.
//!
//! This must not be exposed to the Internet or an iPhone directly. A future
//! authenticated gateway must relay signed payloads, not private keys.
use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    time::Duration,
};

use crate::{bft_reactor::Reactor, tx::SignedTransfer};
use serde_json::{json, Value};

const HEADER_LIMIT: usize = 8192;
const BODY_LIMIT: usize = 64 * 1024;
const IO_TIMEOUT: Duration = Duration::from_millis(250);

#[derive(Debug)]
struct Request {
    method: String,
    path: String,
    body: Vec<u8>,
}

fn read_request(stream: &mut TcpStream) -> Result<Request, &'static str> {
    let mut buffer = Vec::new();
    let mut part = [0u8; 2048];
    let header_end = loop {
        let n = stream
            .read(&mut part)
            .map_err(|_| "request read timed out")?;
        if n == 0 {
            return Err("incomplete HTTP headers");
        }
        buffer.extend_from_slice(&part[..n]);
        if let Some(pos) = buffer.windows(4).position(|w| w == b"\r\n\r\n") {
            let end = pos + 4;
            if end > HEADER_LIMIT {
                return Err("HTTP headers too large");
            }
            break end;
        }
        if buffer.len() > HEADER_LIMIT {
            return Err("HTTP headers too large");
        }
    };
    let headers =
        std::str::from_utf8(&buffer[..header_end]).map_err(|_| "invalid HTTP header encoding")?;
    let mut lines = headers.split("\r\n");
    let line = lines.next().ok_or("empty request")?;
    let mut words = line.split(' ');
    let method = words.next().ok_or("missing HTTP method")?;
    let path = words.next().ok_or("missing HTTP path")?;
    let version = words.next().ok_or("missing HTTP version")?;
    if words.next().is_some() || !matches!(version, "HTTP/1.0" | "HTTP/1.1") {
        return Err("invalid HTTP request line");
    }
    if path.len() > 256 || !path.starts_with('/') || path.contains('?') || path.contains('#') {
        return Err("invalid transaction ingress path");
    }
    let mut length = None;
    let mut host_seen = false;
    let mut json_type = false;
    for header in lines.filter(|line| !line.is_empty()) {
        let (key, value) = header.split_once(':').ok_or("invalid HTTP header")?;
        let value = value.trim();
        if key.eq_ignore_ascii_case("transfer-encoding") || key.eq_ignore_ascii_case("expect") {
            return Err("unsupported HTTP transfer encoding");
        }
        if key.eq_ignore_ascii_case("content-length") {
            if length.is_some() {
                return Err("duplicate Content-Length");
            }
            let n = value
                .parse::<usize>()
                .map_err(|_| "invalid Content-Length")?;
            if n == 0 || n > BODY_LIMIT {
                return Err("invalid request body size");
            }
            length = Some(n);
        }
        if key.eq_ignore_ascii_case("host") {
            if host_seen {
                return Err("duplicate Host");
            }
            host_seen = true;
            let host = value.split(':').next().unwrap_or("");
            if !matches!(host, "localhost" | "127.0.0.1" | "[::1]") {
                return Err("transaction ingress Host must be loopback");
            }
        }
        if key.eq_ignore_ascii_case("content-type") {
            if json_type {
                return Err("duplicate Content-Type");
            }
            if value != "application/json" {
                return Err("Content-Type must be application/json");
            }
            json_type = true;
        }
    }
    if method != "POST" || path != "/v1/transactions" {
        return Ok(Request {
            method: method.into(),
            path: path.into(),
            body: Vec::new(),
        });
    }
    if !host_seen || !json_type {
        return Err("Host and application/json Content-Type required");
    }
    let size = length.ok_or("Content-Length required")?;
    let mut body = buffer[header_end..].to_vec();
    if body.len() > size {
        return Err("HTTP pipelining or oversized body forbidden");
    }
    while body.len() < size {
        let remaining = (size - body.len()).min(part.len());
        let n = stream
            .read(&mut part[..remaining])
            .map_err(|_| "request body timed out")?;
        if n == 0 {
            return Err("incomplete request body");
        }
        body.extend_from_slice(&part[..n]);
    }
    Ok(Request {
        method: method.into(),
        path: path.into(),
        body,
    })
}

fn process(request: Request, reactor: &mut Reactor, timestamp_ms: u64) -> (u16, Value) {
    if request.method != "POST" || request.path != "/v1/transactions" {
        return (
            405,
            json!({"error": "only POST /v1/transactions supported"}),
        );
    }
    let tx: SignedTransfer = match serde_json::from_slice(&request.body) {
        Ok(value) => value,
        Err(_) => return (400, json!({"error": "invalid signed transfer JSON"})),
    };
    if !tx.verify_signature() {
        return (400, json!({"error": "invalid signed transfer signature"}));
    }
    // Reject invalid nonce, chain, balances, fees, expiry and duplicates using
    // the very same candidate-validation path as the consensus reactor.
    match reactor.submit(tx, timestamp_ms) {
        Ok(id) => (
            202,
            json!({
                "id": id,
                "status": "queued_locally_not_finalized",
                "broadcast": false,
                "durable_mempool": true,
                "real_spd": false,
                "note": "inclusion requires an independently verified BFT commit"
            }),
        ),
        Err(error) => (422, json!({"error": error, "accepted": false})),
    }
}

fn respond(stream: &mut TcpStream, code: u16, value: Value) -> Result<(), String> {
    let data = serde_json::to_vec(&value).map_err(|e| e.to_string())?;
    let reason = match code {
        202 => "Accepted",
        400 => "Bad Request",
        405 => "Method Not Allowed",
        422 => "Unprocessable Content",
        _ => "Error",
    };
    let header = format!(
        "HTTP/1.1 {code} {reason}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
        data.len()
    );
    stream
        .write_all(header.as_bytes())
        .map_err(|e| e.to_string())?;
    stream.write_all(&data).map_err(|e| e.to_string())
}

/// Called from the validator event loop at most twice per turn, ensuring that
/// submitting transactions cannot monopolize consensus networking.
pub fn poll_ingress(
    listener: &TcpListener,
    reactor: &mut Reactor,
    timestamp_ms: u64,
) -> Result<u64, String> {
    if !listener
        .local_addr()
        .map_err(|e| e.to_string())?
        .ip()
        .is_loopback()
    {
        return Err("transaction ingress listener must be loopback-only".into());
    }
    let mut accepted = 0;
    for _ in 0..2 {
        let (mut stream, remote) = match listener.accept() {
            Ok(pair) => pair,
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
            Err(e) => return Err(e.to_string()),
        };
        if !remote.ip().is_loopback() {
            return Err("non-loopback transaction peer".into());
        }
        stream
            .set_read_timeout(Some(IO_TIMEOUT))
            .map_err(|e| e.to_string())?;
        stream
            .set_write_timeout(Some(IO_TIMEOUT))
            .map_err(|e| e.to_string())?;
        let (code, result) = match read_request(&mut stream) {
            Ok(req) => process(req, reactor, timestamp_ms),
            Err(error) => (400, json!({"error": error, "accepted": false})),
        };
        if code == 202 {
            accepted += 1;
        }
        if let Err(error) = respond(&mut stream, code, result) {
            eprintln!("Block 3 local ingress response error: {error}");
        }
    }
    Ok(accepted)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        address,
        bft_reactor::Message,
        bft_rounds,
        consensus::{Validator, ValidatorSet},
        ledger::{Account, Asset, Genesis, Ledger},
        tx::Transfer,
        BASE_TRANSFER_GAS, SPD,
    };
    use ed25519_dalek::SigningKey;
    use std::{
        collections::BTreeMap,
        fs,
        sync::atomic::{AtomicU64, Ordering},
        thread,
    };
    static SERIAL: AtomicU64 = AtomicU64::new(0);

    fn fixture() -> (Reactor, SigningKey, String) {
        let owner = SigningKey::from_bytes(&[62; 32]);
        let addr = address::from_public_key(&owner.verifying_key().to_bytes());
        let genesis = Genesis {
            chain_id: "spider-devnet-1".into(),
            timestamp_ms: 1,
            assets: vec![Asset {
                id: SPD.into(),
                decimals: 9,
                initial_supply: 1_000_000,
            }],
            accounts: BTreeMap::from([(
                addr.clone(),
                Account {
                    nonce: 0,
                    balances: BTreeMap::from([(SPD.into(), 1_000_000)]),
                },
            )]),
        };
        let ledger = Ledger::from_genesis(genesis.clone()).unwrap();
        let validators: Vec<SigningKey> =
            (1..=4).map(|n| SigningKey::from_bytes(&[n; 32])).collect();
        let set = ValidatorSet::new(
            ledger.chain_id,
            ledger.genesis_hash,
            validators
                .iter()
                .map(|key| Validator {
                    public_key: hex::encode(key.verifying_key().to_bytes()),
                    power: 1,
                })
                .collect(),
        )
        .unwrap();
        let root = std::env::temp_dir().join(format!(
            "spider-block3-tx-ingress-{}-{}",
            std::process::id(),
            SERIAL.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        let leader_id = bft_rounds::proposer(&set, 1, 0).unwrap();
        let leader = validators
            .iter()
            .find(|key| hex::encode(key.verifying_key().to_bytes()) == leader_id)
            .unwrap();
        (
            Reactor::open(
                root,
                genesis,
                set,
                SigningKey::from_bytes(&leader.to_bytes()),
            )
            .unwrap(),
            owner,
            addr,
        )
    }

    fn transfer(owner: &SigningKey, addr: &str) -> SignedTransfer {
        Transfer {
            chain_id: "spider-devnet-1".into(),
            sender: addr.into(),
            recipient: addr.into(),
            asset_id: SPD.into(),
            amount: 10,
            nonce: 0,
            gas_limit: BASE_TRANSFER_GAS,
            max_fee_per_gas: 1,
            expiry_height: 20,
        }
        .sign(owner)
    }

    #[test]
    fn signature_queue_and_replay_are_distinct_from_finality() {
        let (mut reactor, owner, addr) = fixture();
        let tx = transfer(&owner, &addr);
        let request = || Request {
            method: "POST".into(),
            path: "/v1/transactions".into(),
            body: serde_json::to_vec(&tx).unwrap(),
        };
        let (code, result) = process(request(), &mut reactor, 10);
        assert_eq!(code, 202);
        assert_eq!(result["status"], "queued_locally_not_finalized");
        assert_eq!(reactor.height(), 0);
        // The signed payload is passed to the *actual proposer*, not merely
        // accepted by an unrelated simulated ledger or RPC stub.
        let outbound = reactor.tick(10).unwrap();
        assert!(outbound.iter().any(|message| match message {
            Message::Proposal(p) => p
                .proposal
                .block
                .transactions
                .iter()
                .any(|item| item.id() == tx.id()),
            _ => false,
        }));
        assert_eq!(process(request(), &mut reactor, 10).0, 422);
        let mut forged = tx.clone();
        forged.signature = "00".repeat(64);
        let (code, _) = process(
            Request {
                method: "POST".into(),
                path: "/v1/transactions".into(),
                body: serde_json::to_vec(&forged).unwrap(),
            },
            &mut reactor,
            10,
        );
        assert_eq!(code, 400);
        assert_eq!(reactor.height(), 0);
        let foreign = Transfer {
            chain_id: "foreign-chain".into(),
            sender: addr.clone(),
            recipient: addr.clone(),
            asset_id: SPD.into(),
            amount: 10,
            nonce: 0,
            gas_limit: BASE_TRANSFER_GAS,
            max_fee_per_gas: 1,
            expiry_height: 20,
        }
        .sign(&owner);
        assert_eq!(
            process(
                Request {
                    method: "POST".into(),
                    path: "/v1/transactions".into(),
                    body: serde_json::to_vec(&foreign).unwrap(),
                },
                &mut reactor,
                10
            )
            .0,
            422
        );
        assert_eq!(reactor.height(), 0);
    }

    #[test]
    fn loopback_http_accepts_signed_body_and_rejects_smuggling() {
        let (mut reactor, owner, addr) = fixture();
        let tx = serde_json::to_vec(&transfer(&owner, &addr)).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        listener.set_nonblocking(true).unwrap();
        let port = listener.local_addr().unwrap();
        let client = thread::spawn(move || {
            let mut stream = TcpStream::connect(port).unwrap();
            let header = format!("POST /v1/transactions HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: {}\r\n\r\n", tx.len());
            stream.write_all(header.as_bytes()).unwrap();
            stream.write_all(&tx).unwrap();
            let mut result = String::new();
            stream.read_to_string(&mut result).unwrap();
            result
        });
        // The client TCP handshake has completed before the bounded poll.
        let mut accepted = 0;
        for _ in 0..100 {
            accepted += poll_ingress(&listener, &mut reactor, 10).unwrap();
            if accepted > 0 {
                break;
            }
            thread::sleep(Duration::from_millis(2));
        }
        assert_eq!(accepted, 1);
        assert!(client
            .join()
            .unwrap()
            .contains("queued_locally_not_finalized"));
        assert_eq!(reactor.height(), 0);
    }
    #[test]
    fn rejects_ambiguous_http_framing_and_remote_hosts() {
        let invalid: &[&[u8]] = &[
            b"POST /v1/transactions HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: 2\r\nContent-Length: 2\r\n\r\n{}",
            b"POST /v1/transactions HTTP/1.1\r\nHost: localhost\r\nTransfer-Encoding: chunked\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}",
            b"POST /v1/transactions HTTP/1.1\r\nHost: other.example\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}",
            b"POST /v1/transactions HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}EXTRA",
        ];
        for invalid_request in invalid {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let mut client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
            client.write_all(invalid_request).unwrap();
            let (mut server, _) = listener.accept().unwrap();
            server.set_read_timeout(Some(IO_TIMEOUT)).unwrap();
            assert!(read_request(&mut server).is_err());
        }
    }
}
