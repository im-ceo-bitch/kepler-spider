//! Spider Protocol v0.5.2 research implementation.
//! NOT production ready: deterministic BFT round research only; no live finality, VM or real USDT.
#![forbid(unsafe_code)]

pub mod address;
pub mod bft_phase2;
pub mod bft_proposal;
pub mod bft_reactor;
pub mod bft_roundbook;
pub mod bft_rounds;
pub mod bft_safe_signer;
pub mod bft_session;
pub mod bft_wire;
pub mod block;
pub mod codec;
pub mod consensus;
pub mod crypto;
pub mod finality_gate;
pub mod ledger;
pub mod node;
pub mod p2p;
pub mod rpc;
pub mod storage;
pub mod tx;

pub const SPD: &str = "SPD";
pub const TEST_DOLLAR: &str = "tUSD";
pub const SPD_DECIMALS: u8 = 9;
pub const TEST_DOLLAR_DECIMALS: u8 = 6;
pub const BASE_TRANSFER_GAS: u64 = 21_000;
pub const DEVNET_CHAIN_ID: &str = "spider-devnet-1";

pub mod bft_runtime;

// Block 3: certified-only devnet synchronization; no public peer discovery.
#[path = "block3/certified_sync.rs"]
pub mod certified_sync;

// Block 3: loopback-only read RPC for authenticated certified-devnet state.
#[path = "block3/certified_rpc.rs"]
pub mod certified_rpc;

// Block 3: local, explicitly unfinalized transaction intake for the BFT reactor.
#[path = "block3/tx_ingress.rs"]
pub mod tx_ingress;

// Block 3: durable, never-finality-claiming validator mempool snapshots.
#[path = "block3/durable_pending.rs"]
pub mod durable_pending;
