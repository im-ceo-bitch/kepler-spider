//! Private loopback validator runner for the bounded Block 2 reactor.
//! Configuration supplies genesis, static membership, key and independent store.
use crate::{
    bft_reactor::{Message, Reactor},
    consensus::ValidatorSet,
    ledger::Genesis,
    tx::SignedTransfer,
};
use ed25519_dalek::SigningKey;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    error::Error,
    fs,
    io::{Read, Write},
    net::{SocketAddr, TcpListener, TcpStream},
    path::PathBuf,
    thread,
    time::{Duration, Instant},
};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Config {
    genesis: Genesis,
    validators: ValidatorSet,
    #[serde(default)]
    key_hex: Option<String>,
    #[serde(default)]
    key_file: Option<PathBuf>,
    directory: PathBuf,
    listen: SocketAddr,
    peers: Vec<SocketAddr>,
    target_height: u64,
    // Opt-in development-only long-running mode for a local four-validator Wallet lab.
    #[serde(default)]
    wallet_devnet_live: bool,
    #[serde(default)]
    tx_listen: Option<SocketAddr>,
    #[serde(default)]
    wallet_listen: Option<SocketAddr>,
    #[serde(default = "default_timeout")]
    timeout_ms: u64,
    #[serde(default = "default_duration")]
    duration_ms: u64,
}
fn default_timeout() -> u64 {
    4000
}
fn default_duration() -> u64 {
    30000
}
const FRAME: usize = 4 * 1024 * 1024;
const TX_BATCH_LIMIT: usize = 8;

/// A transfer batch is distinct from the existing consensus array wire format,
/// preserving compatibility with the signed BFT frame tests. Not encrypted;
/// ONLY permitted between loopback validators inside the private devnet.
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct TransferBatch {
    kind: String,
    transfers: Vec<SignedTransfer>,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum Incoming {
    Consensus(Vec<Message>),
    Transfers(TransferBatch),
}

/// Re-validate each signed transfer against this validator's candidate ledger.
/// Replays of known valid transfers are idempotent, not extra voting power.
/// Returns (newly_queued, invalid_or_stale), never a finality assertion.
pub fn import_signed_batch(
    reactor: &mut Reactor,
    transfers: Vec<SignedTransfer>,
    timestamp_ms: u64,
) -> Result<(usize, usize), String> {
    if transfers.is_empty() || transfers.len() > TX_BATCH_LIMIT {
        return Err("invalid signed transfer relay batch size".into());
    }
    let mut queued = 0usize;
    let mut rejected = 0usize;
    for transfer in transfers {
        let id = transfer.id();
        if reactor.pending_transfers().iter().any(|old| old.id() == id) {
            continue;
        }
        if reactor.submit(transfer, timestamp_ms).is_ok() {
            queued += 1;
        } else {
            rejected += 1;
        }
    }
    Ok((queued, rejected))
}

// A replayable reactor has to retain old evidence, but retransmitting the
// entire history at the same cadence as current-round votes causes queue
// amplification after a partition. This is transport scheduling only: the
// receiver still verifies every signature and certificate without exceptions.
const HISTORY_REPLAY_INTERVAL_MS: u64 = 900;
const HISTORY_MESSAGES_PER_REPLAY: usize = 32;

fn partition_consensus_gossip(
    messages: Vec<Message>,
    current_round: u32,
) -> (Vec<Message>, Vec<Message>) {
    let mut priority = Vec::new();
    let mut history = Vec::new();
    for message in messages {
        let is_priority = match &message {
            Message::Commit(_) | Message::Round(_) | Message::Polka(_, _) => true,
            Message::Proposal(p) => p.proposal.round == current_round,
            Message::Vote(v) => v.round == current_round,
            Message::Timeout(t) => t.round == current_round,
        };
        if is_priority {
            priority.push(message);
        } else {
            history.push(message);
        }
    }
    (priority, history)
}

// Round-robin replay guarantees that *every* historical signed message is
// eventually offered to peers. The cursor survives successive loop turns and
// resets naturally when a new block replaces the active reactor state.
fn rotating_replay<T: Clone>(history: &[T], cursor: &mut usize, budget: usize) -> Vec<T> {
    if history.is_empty() || budget == 0 {
        *cursor = 0;
        return Vec::new();
    }
    let count = budget.min(history.len());
    let start = *cursor % history.len();
    let selected = (0..count)
        .map(|offset| history[(start + offset) % history.len()].clone())
        .collect();
    *cursor = (start + count) % history.len();
    selected
}

fn receive(mut stream: TcpStream) -> Result<Incoming, Box<dyn Error>> {
    stream.set_read_timeout(Some(Duration::from_millis(250)))?;
    let mut header = [0; 4];
    stream.read_exact(&mut header)?;
    let len = u32::from_be_bytes(header) as usize;
    if len == 0 || len > FRAME {
        return Err("invalid frame length".into());
    }
    let mut bytes = vec![0; len];
    stream.read_exact(&mut bytes)?;
    Ok(serde_json::from_slice(&bytes)?)
}
fn send(addr: SocketAddr, bytes: &[u8]) -> Result<(), Box<dyn Error>> {
    if bytes.is_empty() || bytes.len() > FRAME {
        return Err("invalid outbound frame".into());
    }
    let mut s = TcpStream::connect_timeout(&addr, Duration::from_millis(100))?;
    s.set_write_timeout(Some(Duration::from_millis(500)))?;
    s.write_all(&(bytes.len() as u32).to_be_bytes())?;
    s.write_all(bytes)?;
    Ok(())
}
pub fn run(path: &str) -> Result<(), Box<dyn Error>> {
    let bytes = fs::read(path)?;
    if bytes.len() > FRAME {
        return Err("configuration too large".into());
    }
    let c: Config = serde_json::from_slice(&bytes)?;
    if !c.listen.ip().is_loopback()
        || c.peers.iter().any(|a| !a.ip().is_loopback())
        || c.peers.len() > 16
        || c.timeout_ms < 200
        || c.duration_ms > 300000
        || (c.wallet_devnet_live && (c.tx_listen.is_none() || c.wallet_listen.is_none()))
        || c.tx_listen
            .is_some_and(|a| !a.ip().is_loopback() || a == c.listen || c.peers.contains(&a))
        || c.wallet_listen.is_some_and(|a| {
            !a.ip().is_loopback() || a == c.listen || c.peers.contains(&a) || c.tx_listen == Some(a)
        })
    {
        return Err("private lab requires loopback peers and bounded timers".into());
    }
    let key: [u8; 32] = match (&c.key_hex, &c.key_file) {
        (Some(_), Some(_)) | (None, None) => return Err("exactly one validator signing key source required".into()),
        (Some(value), None) => {
            eprintln!("WARNING: inline key_hex is devnet-only; migrate to a chmod-600 key_file");
            hex::decode(value)?.try_into().map_err(|_| "key must be 32 bytes")?
        }
        (None, Some(path)) => {
            let m = fs::symlink_metadata(path)?;
            if !m.is_file() || m.file_type().is_symlink() || m.len() > 128 {
                return Err("unsafe validator signing key file".into());
            }
            #[cfg(unix)] {
                use std::os::unix::fs::PermissionsExt;
                if m.permissions().mode() & 0o077 != 0 {
                    return Err("validator signing key_file must be chmod 600".into());
                }
            }
            let mut f = fs::File::open(path)?;
            let opened = f.metadata()?;
            if !opened.is_file() || opened.len() > 128 {
                return Err("unsafe opened validator signing key file".into());
            }
            let mut contents = String::new();
            f.take(129).read_to_string(&mut contents)?;
            hex::decode(contents.trim())?.try_into().map_err(|_| "key_file must contain 32 bytes as hex")?
        }
    };
    eprintln!("VALIDATOR startup: opening persisted reactor state");
    let mut reactor = Reactor::open(
        c.directory,
        c.genesis,
        c.validators,
        SigningKey::from_bytes(&key),
    )?;
    let listener = TcpListener::bind(c.listen)?;
    listener.set_nonblocking(true)?;
    let tx_listener = match c.tx_listen {
        Some(addr) => {
            let listener = TcpListener::bind(addr)?;
            listener.set_nonblocking(true)?;
            Some(listener)
        }
        None => None,
    };
    let wallet_listener = match c.wallet_listen {
        Some(addr) => {
            let listener = TcpListener::bind(addr)?;
            listener.set_nonblocking(true)?;
            Some(listener)
        }
        None => None,
    };
    eprintln!(
        "VALIDATOR listening on {} with {} peers at height={} round={} wallet_devnet_live={}",
        c.listen,
        c.peers.len(),
        reactor.height(),
        reactor.round(),
        c.wallet_devnet_live
    );
    let start = Instant::now();
    let mut round_start = Instant::now();
    let mut slot = (reactor.height(), reactor.round());
    let mut finished = None;
    let mut accepted = 0u64;
    let mut malformed_frames = 0u64;
    let mut last_frame_error = String::new();
    let mut last_gossip = Instant::now();
    let mut last_history_replay = Instant::now();
    let mut history_replay_cursor = 0usize;
    let mut last_gossip_slot = (u64::MAX, u32::MAX);
    let mut last_priority_digest: Option<[u8; 32]> = None;
    let mut rejected = 0u64;
    let mut transport_failures = 0u64;
    let mut last_rejection = String::new();
    let mut last_report = Instant::now();
    while c.wallet_devnet_live || start.elapsed() < Duration::from_millis(c.duration_ms) {
        // Never allow a burst of TCP reads to monopolize the consensus loop.
        // 128 sockets * 500 ms used to risk a 64-second stall before the next
        // local timeout or outgoing quorum message. The bounded queue is drained
        // on subsequent turns; no inbound consensus frame is bypassed.
        for _ in 0..8 {
            match listener.accept() {
                Ok((s, _)) => match receive(s) {
                    Ok(Incoming::Consensus(messages)) => {
                        if messages.is_empty() || messages.len() > 64 {
                            rejected += 1;
                            last_rejection = "unbounded or empty consensus message batch".into();
                            continue;
                        }
                        for message in messages {
                            match reactor.receive(message) {
                                Ok(()) => accepted += 1,
                                Err(reason) => {
                                    rejected += 1;
                                    last_rejection = reason;
                                }
                            }
                        }
                    }
                    Ok(Incoming::Transfers(batch)) => {
                        if batch.kind != "signed_transfers_v1" {
                            rejected += 1;
                            last_rejection = "invalid transfer relay type".into();
                        } else {
                            let timestamp = 1_800_000_000_000
                                + reactor.height() * 1000
                                + u64::from(reactor.round());
                            match import_signed_batch(&mut reactor, batch.transfers, timestamp) {
                                Ok((queued, invalid)) => {
                                    accepted += queued as u64;
                                    rejected += invalid as u64;
                                }
                                Err(reason) => {
                                    rejected += 1;
                                    last_rejection = reason;
                                }
                            }
                        }
                    }
                    Err(error) => {
                        malformed_frames += 1;
                        last_frame_error = error.to_string();
                    }
                },
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                Err(e) => return Err(e.into()),
            }
        }
        let next = (reactor.height(), reactor.round());
        if slot != next {
            slot = next;
            round_start = Instant::now();
        }
        // Increasing timeout gives a partially synchronous private network time to converge.
        if round_start.elapsed()
            >= Duration::from_millis(c.timeout_ms * (u64::from(reactor.round()) + 1))
        {
            reactor.timeout()?;
            round_start = Instant::now();
        }
        let timestamp = 1_800_000_000_000 + reactor.height() * 1000 + u64::from(reactor.round());
        if let Some(ref local) = tx_listener {
            // Only verified signed transfers enter the actual BFT candidate pool.
            // A 202 reply explicitly does not mean a certified commit.
            let _ = crate::tx_ingress::poll_ingress(local, &mut reactor, timestamp)?;
        }
        let messages = reactor.tick(timestamp)?;
        if let Some(ref read_only) = wallet_listener {
            // Reads are derived directly from the BFT reactor's certified
            // ledger, not a second simulator or unsynchronized mirror.
            let _ = crate::certified_rpc::poll_validator_wallet_rpc(read_only, &reactor)?;
        }
        // Send current-round votes, proposals, timeouts and QC/commit evidence
        // promptly; replay old messages at a separate bounded cadence. During
        // the 2+2 partition recovery test, re-sending every historical vote
        // every 350ms congested the single-threaded loopback receive loop.
        // Historical evidence is not discarded: rotating_replay is fair.
        let gossip_slot = (reactor.height(), reactor.round());
        if gossip_slot.0 != last_gossip_slot.0 {
            // History belongs to a specific height. Restart replay from the
            // beginning when the finalized height changes.
            history_replay_cursor = 0;
        }
        let (priority, history) = partition_consensus_gossip(messages, gossip_slot.1);
        // Newly signed votes must not wait for the next retransmit timer.
        // A hash of authenticated output is only a local scheduling hint, not
        // any kind of consensus proof or signature.
        let hashed = Sha256::digest(serde_json::to_vec(&priority)?);
        let mut priority_digest = [0_u8; 32];
        priority_digest.copy_from_slice(&hashed);
        let urgent_due = gossip_slot != last_gossip_slot
            || last_priority_digest != Some(priority_digest)
            || last_gossip.elapsed() >= Duration::from_millis(350);
        let history_due =
            last_history_replay.elapsed() >= Duration::from_millis(HISTORY_REPLAY_INTERVAL_MS);
        if urgent_due || history_due {
            let backfill = if history_due {
                rotating_replay(
                    &history,
                    &mut history_replay_cursor,
                    HISTORY_MESSAGES_PER_REPLAY,
                )
            } else {
                Vec::new()
            };
            // Put current round and finality first in the TCP accept queue.
            // A fixed frame cap prevents an old-state replay from blocking
            // timeouts or new signatures for a complete loop turn.
            let mut frames = Vec::new();
            if urgent_due {
                for batch in priority.chunks(16) {
                    let bytes = serde_json::to_vec(batch)?;
                    if bytes.len() > FRAME {
                        return Err("priority consensus batch exceeds frame limit".into());
                    }
                    frames.push(bytes);
                }
            }
            for batch in backfill.chunks(16) {
                let bytes = serde_json::to_vec(batch)?;
                if bytes.len() > FRAME {
                    return Err("historical consensus batch exceeds frame limit".into());
                }
                frames.push(bytes);
            }
            // Signed transfers are not certificates, and may never preempt
            // consensus evidence. Rejected transfers still take the same
            // verification path on every receiving validator.
            if urgent_due {
                for batch in reactor.pending_transfers().chunks(TX_BATCH_LIMIT) {
                    let bytes = serde_json::to_vec(&TransferBatch {
                        kind: "signed_transfers_v1".into(),
                        transfers: batch.to_vec(),
                    })?;
                    if bytes.len() > FRAME {
                        return Err("transfer relay frame too large".into());
                    }
                    frames.push(bytes);
                }
            }
            for addr in &c.peers {
                for frame in &frames {
                    if send(*addr, frame).is_err() {
                        transport_failures += 1;
                    }
                }
            }
            if urgent_due {
                last_gossip = Instant::now();
                last_gossip_slot = gossip_slot;
                last_priority_digest = Some(priority_digest);
            }
            if history_due {
                last_history_replay = Instant::now();
            }
        }
        if !c.wallet_devnet_live && reactor.height() >= c.target_height {
            let first = *finished.get_or_insert_with(Instant::now);
            // Continue serving finalized evidence to slower validators.
            // A node exiting immediately after its own commit can prevent a
            // healthy peer from ever seeing the quorum it needs.
            if first.elapsed() > Duration::from_millis(8000) {
                println!(
                    "CERTIFIED height={} root={}",
                    reactor.height(),
                    reactor.state_root()
                );
                return Ok(());
            }
        }
        if last_report.elapsed() >= Duration::from_secs(2) {
            println!(
                "REACTOR height={} round={} target={} pending={} accepted={} rejected={} frame_errors={} send_errors={} last_rejection={:?} last_frame_error={:?}",
                reactor.height(), reactor.round(), c.target_height, reactor.pending_transfers().len(),
                accepted, rejected, malformed_frames, transport_failures,
                last_rejection, last_frame_error
            );
            last_report = Instant::now();
        }
        // A 30ms full-state replay saturated the loopback receiver with old
        // votes during partition recovery. Replay at a bounded interval;
        // urgent commit/round certificates are prioritized by Reactor::outbox.
        thread::sleep(Duration::from_millis(100));
    }
    // Reaching the target immediately before the bounded deadline is success,
    // even if the optional post-finality dissemination grace is truncated.
    if !c.wallet_devnet_live && reactor.height() >= c.target_height {
        println!(
            "CERTIFIED height={} root={}",
            reactor.height(),
            reactor.state_root()
        );
        return Ok(());
    }
    Err(format!(
        "bounded validator run expired: reached height={} round={}, target height={}, peers={}, accepted={}, rejected={}, frame_errors={}, send_errors={}, last_rejection={:?}, last_frame_error={:?}",
        reactor.height(), reactor.round(), c.target_height, c.peers.len(),
        accepted, rejected, malformed_frames, transport_failures,
        last_rejection, last_frame_error
    )
    .into())
}

#[cfg(test)]
mod block3_relay_wire_tests {
    use super::*;

    #[test]
    fn historical_replay_is_fair_and_does_not_preempt_current_vote_or_qc() {
        use crate::{
            bft_phase2::{Ballot, Phase2Vote},
            consensus::{TimeoutCertificate, VoteStep},
        };
        let vote = |round| {
            Message::Vote(Phase2Vote {
                chain_id: String::new(),
                genesis_hash: String::new(),
                validator_set_hash: String::new(),
                height: 1,
                round,
                step: VoteStep::Prevote,
                target: Ballot::Nil,
                signer: String::new(),
                signature: String::new(),
            })
        };
        let (priority, old) = partition_consensus_gossip(
            vec![
                vote(0),
                vote(2),
                Message::Round(TimeoutCertificate { votes: vec![] }),
                vote(1),
            ],
            2,
        );
        assert_eq!(priority.len(), 2);
        assert!(matches!(&priority[0], Message::Vote(v) if v.round == 2));
        assert!(matches!(&priority[1], Message::Round(_)));
        assert_eq!(old.len(), 2);
        let mut cursor = 0;
        let a = rotating_replay(&[0, 1, 2, 3, 4], &mut cursor, 2);
        let b = rotating_replay(&[0, 1, 2, 3, 4], &mut cursor, 2);
        let c = rotating_replay(&[0, 1, 2, 3, 4], &mut cursor, 2);
        assert_eq!(a, vec![0, 1]);
        assert_eq!(b, vec![2, 3]);
        assert_eq!(c, vec![4, 0]);
        assert_eq!(cursor, 1);
    }

    #[test]
    fn signed_transfer_frames_have_a_separate_explicit_wire_type() {
        let batch = TransferBatch {
            kind: "signed_transfers_v1".into(),
            transfers: Vec::new(),
        };
        let bytes = serde_json::to_vec(&batch).unwrap();
        let incoming: Incoming = serde_json::from_slice(&bytes).unwrap();
        match incoming {
            Incoming::Transfers(actual) => assert_eq!(actual.kind, "signed_transfers_v1"),
            Incoming::Consensus(_) => panic!("transfer frame parsed as consensus"),
        }
        // The legacy signed-consensus array remains valid on the wire.
        let legacy: Incoming = serde_json::from_slice(b"[]").unwrap();
        assert!(matches!(legacy, Incoming::Consensus(_)));
    }
}
