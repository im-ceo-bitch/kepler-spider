//! Experimental certified-ledger boundary, NOT a proven live BFT consensus.
//! Atomic one-file evidence+block commit, authenticated re-execution on replay.
use crate::{
    bft_phase2::{Ballot, Phase2Quorum},
    bft_proposal::SignedProposal,
    consensus::{TimeoutCertificate, ValidatorSet, VoteStep},
    ledger::{Genesis, Ledger},
};
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
};
const CAP: u64 = 4 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FinalityEvidence {
    pub proposal: SignedProposal,
    pub prevotes: Phase2Quorum,
    pub precommits: Phase2Quorum,
    /// Round 0 requires no change proof. Higher-round proposals must include
    /// every intervening signed timeout QC, beginning with round 0.
    #[serde(default)]
    pub view_changes: Vec<TimeoutCertificate>,
}
impl FinalityEvidence {
    /// Independently authenticate all signatures and execute the proposal.
    pub fn verify(&self, set: &ValidatorSet, ledger: &Ledger) -> Result<Ledger, String> {
        set.ensure_valid().map_err(|e| e.to_string())?;
        self.proposal
            .verify_candidate(set, ledger)
            .map_err(|e| e.to_string())?;
        let height = self.proposal.height;
        let round = self.proposal.round;
        // A higher-round proposal cannot be marked certified without
        // independently authenticated permission to leave EACH earlier round.
        // This is necessary, not sufficient, for a complete BFT view-change
        // protocol (the bundle does not transfer conflicting valid-round locks).
        if round > view_change::MAX_VIEW_CHANGE_ROUND || self.view_changes.len() != round as usize {
            return Err("missing, excess or unsupported signed view-change evidence".into());
        }
        for (expected, tc) in self.view_changes.iter().enumerate() {
            tc.verify(set, height, expected as u32)
                .map_err(|e| e.to_string())?;
        }
        let target = Ballot::Block(self.proposal.block.hash.clone());
        self.prevotes
            .verify(set, height, round, VoteStep::Prevote, &target)
            .map_err(|e| e.to_string())?;
        self.precommits
            .verify(set, height, round, VoteStep::Precommit, &target)
            .map_err(|e| e.to_string())?;
        let mut next = ledger.clone();
        next.apply_block(self.proposal.block.clone())
            .map_err(|e| e.to_string())?;
        Ok(next)
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    chain_id: String,
    genesis_hash: String,
    set_hash: String,
}

fn read_bounded(path: &Path, max: u64) -> Result<Vec<u8>, String> {
    let meta = fs::symlink_metadata(path).map_err(|e| e.to_string())?;
    if !meta.is_file() || meta.file_type().is_symlink() || meta.len() > max {
        return Err("invalid/oversized evidence file".into());
    }
    let file = File::open(path).map_err(|e| e.to_string())?;
    let opened = file.metadata().map_err(|e| e.to_string())?;
    if !opened.is_file() || opened.len() > max {
        return Err("invalid evidence file after open".into());
    }
    let mut bytes = Vec::new();
    file.take(max + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() as u64 > max {
        return Err("oversized evidence file".into());
    }
    Ok(bytes)
}
fn write_new(path: &Path, data: &[u8]) -> Result<(), String> {
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|e| e.to_string())?;
    file.write_all(data).map_err(|e| e.to_string())?;
    file.sync_all().map_err(|e| e.to_string())
}
fn sync_directory(path: &Path) -> Result<(), String> {
    File::open(path)
        .and_then(|x| x.sync_all())
        .map_err(|e| e.to_string())
}
fn record_name(height: u64) -> String {
    format!("{height:020}.json")
}

/// Single-owner experimental finality journal (separate from LocalNode).
/// Uses an OS-held advisory lock that automatically releases on process crash.
/// The stable LOCK inode is never removed, preventing concurrent owners from
/// racing on a replacement inode. Filesystem deletion or duplicated keys still
/// require external checkpointing/key custody controls.
pub struct FinalityJournal {
    root: PathBuf,
    _owner: File,
    set: ValidatorSet,
    pub ledger: Ledger,
    // Digests are recorded only AFTER replaying authenticated evidence.
    verified_records: BTreeMap<u64, String>,
}
impl FinalityJournal {
    pub fn open(
        path: impl AsRef<Path>,
        genesis: Genesis,
        set: ValidatorSet,
    ) -> Result<Self, String> {
        set.ensure_valid().map_err(|e| e.to_string())?;
        let ledger = Ledger::from_genesis(genesis).map_err(|e| e.to_string())?;
        if ledger.chain_id != set.chain_id || ledger.genesis_hash != set.genesis_hash {
            return Err("validator set and genesis mismatch".into());
        }
        fs::create_dir_all(path.as_ref()).map_err(|e| e.to_string())?;
        let root = fs::canonicalize(path).map_err(|e| e.to_string())?;
        let lock_path = root.join("LOCK");
        if let Ok(metadata) = fs::symlink_metadata(&lock_path) {
            if !metadata.is_file() || metadata.file_type().is_symlink() {
                return Err("unsafe finality journal owner file".into());
            }
        }
        let owner = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&lock_path)
            .map_err(|e| e.to_string())?;
        owner
            .try_lock()
            .map_err(|_| "certified journal is already owned".to_string())?;
        sync_directory(&root)?;
        Self::open_locked(root, owner, ledger, set)
    }
    fn open_locked(
        root: PathBuf,
        owner: File,
        mut ledger: Ledger,
        set: ValidatorSet,
    ) -> Result<Self, String> {
        let manifest = Manifest {
            chain_id: ledger.chain_id.clone(),
            genesis_hash: ledger.genesis_hash.clone(),
            set_hash: set.hash(),
        };
        let marker = root.join("manifest.json");
        if !marker.exists() {
            for entry in fs::read_dir(&root).map_err(|e| e.to_string())? {
                if entry.map_err(|e| e.to_string())?.file_name().to_str() != Some("LOCK") {
                    return Err("missing manifest from nonempty journal".into());
                }
            }
            write_new(
                &marker,
                &serde_json::to_vec(&manifest).map_err(|e| e.to_string())?,
            )?;
            sync_directory(&root)?;
        }
        let saved: Manifest =
            serde_json::from_slice(&read_bounded(&marker, 4096)?).map_err(|e| e.to_string())?;
        if saved.chain_id != manifest.chain_id
            || saved.genesis_hash != manifest.genesis_hash
            || saved.set_hash != manifest.set_hash
        {
            return Err("journal belongs to different genesis or validator set".into());
        }
        let mut records = Vec::new();
        let mut verified_records = BTreeMap::new();
        for entry in fs::read_dir(&root).map_err(|e| e.to_string())? {
            let entry = entry.map_err(|e| e.to_string())?;
            let name = entry.file_name().to_string_lossy().to_string();
            if name == "LOCK" || name == "manifest.json" {
                continue;
            }
            if name.len() != 25
                || !name.ends_with(".json")
                || !name[..20].bytes().all(|x| x.is_ascii_digit())
                || !entry.file_type().map_err(|e| e.to_string())?.is_file()
            {
                return Err(format!("unexpected or damaged journal entry: {name}"));
            }
            records.push(name);
        }
        records.sort();
        for (index, name) in records.iter().enumerate() {
            let height = u64::try_from(index + 1).map_err(|e| e.to_string())?;
            if name != &record_name(height) {
                return Err("gap in certified block heights".into());
            }
            let bytes = read_bounded(&root.join(name), CAP)?;
            let proof: FinalityEvidence =
                serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
            ledger = proof.verify(&set, &ledger)?;
            verified_records.insert(height, crate::codec::hex_hash(&bytes));
        }
        Ok(Self {
            root,
            _owner: owner,
            set,
            ledger,
            verified_records,
        })
    }
    /// Return a record that was authenticated during journal replay or append.
    /// Fail closed if the on-disk file has been modified or removed since then.
    /// Callers must independently verify this evidence before accepting it on
    /// another node. This API never constitutes an unsigned block sync.
    pub fn evidence_at(&self, height: u64) -> Result<FinalityEvidence, String> {
        if height == 0 || height > self.ledger.height() {
            return Err("certified height is out of range".into());
        }
        let bytes = read_bounded(&self.root.join(record_name(height)), CAP)?;
        let authenticated = self
            .verified_records
            .get(&height)
            .ok_or_else(|| "missing replay digest for certified evidence".to_owned())?;
        if &crate::codec::hex_hash(&bytes) != authenticated {
            return Err("certified evidence was changed after authenticated replay".into());
        }
        let proof: FinalityEvidence = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
        if proof.proposal.height != height
            || proof.proposal.block.hash != self.ledger.blocks[(height - 1) as usize].hash
        {
            return Err("journal proof differs from certified ledger".into());
        }
        Ok(proof)
    }

    /// Publish block+certificates in ONE file after full validation.
    /// Incomplete staging files fail closed on next open.
    pub fn append(&mut self, evidence: FinalityEvidence) -> Result<(), String> {
        let staged = evidence.verify(&self.set, &self.ledger)?;
        let height = staged.height();
        let final_path = self.root.join(record_name(height));
        if final_path.exists() {
            return Err("height already recorded".into());
        }
        let temp = self.root.join(format!(".staging-{height:020}"));
        let data = serde_json::to_vec(&evidence).map_err(|e| e.to_string())?;
        if data.len() as u64 > CAP {
            return Err("oversized evidence bundle".into());
        }
        write_new(&temp, &data)?;
        fs::rename(&temp, &final_path).map_err(|e| e.to_string())?;
        sync_directory(&self.root)?;
        self.verified_records
            .insert(height, crate::codec::hex_hash(&data));
        self.ledger = staged;
        Ok(())
    }
}

// Kept within the Block 2-owned module so Block 1 immutable checksums remain intact.
pub mod timeouts {
    //! Durable, single-owner journal for signed SpiderBFT research timeout QCs.
    //!
    //! A QC is authenticated before publication and on every restart. The highest
    //! contiguous authenticated round is the only round permitted after restart.
    //! This is NOT a production BFT view-change proof, and does not authorize a
    //! conflicting proposal or override any precommit block lock.
    use std::{
        collections::BTreeMap,
        fs::{self, File, OpenOptions},
        io::{Read, Write},
        path::{Path, PathBuf},
    };

    use crate::consensus::{TimeoutCertificate, ValidatorSet};

    const MAX_RECORD: u64 = 256 * 1024;

    fn sync_dir(root: &Path) -> Result<(), String> {
        File::open(root)
            .and_then(|file| file.sync_all())
            .map_err(|e| e.to_string())
    }

    fn name(height: u64, round: u32) -> String {
        format!("{height:020}-{round:07}.json")
    }

    fn parse_name(filename: &str) -> Result<(u64, u32), String> {
        if filename.len() != 33
            || filename.as_bytes()[20] != b'-'
            || !filename.ends_with(".json")
            || !filename[..20].bytes().all(|b| b.is_ascii_digit())
            || !filename[21..28].bytes().all(|b| b.is_ascii_digit())
        {
            return Err("invalid timeout QC journal filename".into());
        }
        let height = filename[..20].parse::<u64>().map_err(|e| e.to_string())?;
        let round = filename[21..28].parse::<u32>().map_err(|e| e.to_string())?;
        if height == 0 {
            return Err("invalid timeout QC height".into());
        }
        Ok((height, round))
    }

    fn checked_bytes(path: &Path) -> Result<Vec<u8>, String> {
        let meta = fs::symlink_metadata(path).map_err(|e| e.to_string())?;
        if !meta.is_file() || meta.file_type().is_symlink() || meta.len() > MAX_RECORD {
            return Err("unsafe or oversized timeout QC journal record".into());
        }
        let opened = File::open(path).map_err(|e| e.to_string())?;
        let meta = opened.metadata().map_err(|e| e.to_string())?;
        if !meta.is_file() || meta.len() > MAX_RECORD {
            return Err("unsafe opened timeout QC record".into());
        }
        let mut bytes = Vec::new();
        opened
            .take(MAX_RECORD + 1)
            .read_to_end(&mut bytes)
            .map_err(|e| e.to_string())?;
        if bytes.len() as u64 > MAX_RECORD {
            return Err("oversized timeout QC record".into());
        }
        Ok(bytes)
    }

    /// One process owns this journal, independently from vote and finality journals.
    /// The stable OWNER inode must not be deleted/replaced by an administrator.
    pub struct TimeoutQcJournal {
        root: PathBuf,
        _owner: File,
        set: ValidatorSet,
    }

    impl TimeoutQcJournal {
        pub fn open(path: impl AsRef<Path>, set: ValidatorSet) -> Result<Self, String> {
            set.ensure_valid().map_err(|e| e.to_string())?;
            fs::create_dir_all(path.as_ref()).map_err(|e| e.to_string())?;
            let root = fs::canonicalize(path).map_err(|e| e.to_string())?;
            let marker = root.join("OWNER");
            if let Ok(meta) = fs::symlink_metadata(&marker) {
                if !meta.is_file() || meta.file_type().is_symlink() {
                    return Err("unsafe timeout QC owner inode".into());
                }
            }
            let owner = OpenOptions::new()
                .read(true)
                .write(true)
                .create(true)
                .truncate(false)
                .open(&marker)
                .map_err(|e| e.to_string())?;
            owner
                .try_lock()
                .map_err(|_| "timeout QC journal is already owned".to_owned())?;
            sync_dir(&root)?;
            Ok(Self {
                root,
                _owner: owner,
                set,
            })
        }

        /// Validate ALL historical QCs, not only the requested height, so a corrupt
        /// persisted record never silently becomes trusted state after restart.
        pub fn load(
            &self,
            current_height: u64,
        ) -> Result<BTreeMap<u32, TimeoutCertificate>, String> {
            if current_height == 0 {
                return Err("cannot load timeout QCs for height zero".into());
            }
            let mut active = BTreeMap::new();
            for entry in fs::read_dir(&self.root).map_err(|e| e.to_string())? {
                let entry = entry.map_err(|e| e.to_string())?;
                let filename = entry
                    .file_name()
                    .into_string()
                    .map_err(|_| "invalid UTF-8 in timeout QC journal".to_owned())?;
                if filename == "OWNER" {
                    continue;
                }
                let (height, round) = parse_name(&filename)?;
                if height > current_height {
                    return Err("future timeout QC would skip an unfinalized height".into());
                }
                let data = checked_bytes(&entry.path())?;
                let cert: TimeoutCertificate = serde_json::from_slice(&data)
                    .map_err(|e| format!("malformed timeout QC journal entry: {e}"))?;
                cert.verify(&self.set, height, round)
                    .map_err(|e| e.to_string())?;
                if height == current_height {
                    active.insert(round, cert);
                }
            }
            for (expected, found) in active.keys().enumerate() {
                if *found != expected as u32 {
                    return Err("noncontiguous timeout QC round history".into());
                }
            }
            Ok(active)
        }

        /// Fsync a verified QC *before* the caller changes local round. Never
        /// replace records, and fail closed if a different certificate is present.
        pub fn record(
            &self,
            height: u64,
            round: u32,
            cert: &TimeoutCertificate,
        ) -> Result<(), String> {
            cert.verify(&self.set, height, round)
                .map_err(|e| e.to_string())?;
            let bytes = serde_json::to_vec(cert).map_err(|e| e.to_string())?;
            if bytes.len() as u64 > MAX_RECORD {
                return Err("timeout QC exceeds size limit".into());
            }
            let dest = self.root.join(name(height, round));
            match OpenOptions::new().create_new(true).write(true).open(&dest) {
                Ok(mut file) => {
                    file.write_all(&bytes).map_err(|e| e.to_string())?;
                    file.sync_all().map_err(|e| e.to_string())?;
                    sync_dir(&self.root)
                }
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
                    if checked_bytes(&dest)? == bytes {
                        Ok(())
                    } else {
                        Err("different or damaged timeout QC at same height/round".into())
                    }
                }
                Err(e) => Err(e.to_string()),
            }
        }
    }
}
pub use timeouts::TimeoutQcJournal;

// Block 2 additive, independent view-change proof validator.
pub mod view_change {
    //! Authenticated view-change and competing-proposal intake for SpiderBFT.
    //!
    //! This deliberately does not claim that a timeout QC alone proves it is
    //! safe to abandon a lock. A valid-round certificate must authenticate the
    //! proposed value; the durable safe signer remains the authority on locks.
    use std::collections::BTreeMap;

    use serde::{Deserialize, Serialize};

    use crate::{
        bft_phase2::{Ballot, Phase2Quorum},
        bft_proposal::SignedProposal,
        consensus::{TimeoutCertificate, ValidatorSet, VoteStep},
        ledger::Ledger,
    };

    // Shared protocol round domain. A finality bundle still has a strict
    // 4-MiB durable size ceiling; reaching it is a resource refusal, not an
    // independently invented 32-round consensus/finality disagreement.
    pub const MAX_VIEW_CHANGE_ROUND: u32 = crate::consensus::MAX_VOTE_ROUND;

    /// A proposal may be valid in the current round without a previously observed
    /// polka, or may carry an authenticated polka from an earlier round.
    /// The proposer signature authenticates the exact block; each QC authenticates
    /// its own height, round and block hash. The proof metadata cannot authorize a
    /// different candidate value.
    #[derive(Clone, Debug, Serialize, Deserialize)]
    #[serde(deny_unknown_fields)]
    pub struct JustifiedProposal {
        pub proposal: SignedProposal,
        pub valid_round: Option<u32>,
        pub valid_round_qc: Option<Phase2Quorum>,
        pub view_changes: Vec<TimeoutCertificate>,
    }

    impl JustifiedProposal {
        pub fn verify(&self, set: &ValidatorSet, ledger: &Ledger) -> Result<(), String> {
            self.proposal
                .verify_candidate(set, ledger)
                .map_err(|e| e.to_string())?;
            let height = self.proposal.height;
            let round = self.proposal.round;
            if round > MAX_VIEW_CHANGE_ROUND || self.view_changes.len() != round as usize {
                return Err("view change sequence must cover every preceding round".into());
            }
            for (previous, certificate) in self.view_changes.iter().enumerate() {
                certificate
                    .verify(set, height, previous as u32)
                    .map_err(|e| e.to_string())?;
            }
            match (self.valid_round, self.valid_round_qc.as_ref()) {
                (None, None) => Ok(()),
                (Some(valid_round), Some(qc)) if valid_round < round => {
                    qc.verify(
                        set,
                        height,
                        valid_round,
                        VoteStep::Prevote,
                        &Ballot::Block(self.proposal.block.hash.clone()),
                    )
                    .map_err(|e| e.to_string())?;
                    Ok(())
                }
                _ => Err("missing, inconsistent or non-earlier valid-round proof".into()),
            }
        }
    }

    /// Reject a leader's double proposal for the same (height, round), even if both
    /// individual signatures are mathematically valid. A new round MAY propose a
    /// different valid block; lock/unlock eligibility is enforced by the signer.
    #[derive(Default)]
    pub struct ProposalInbox {
        seen: BTreeMap<(u64, u32, String), String>,
    }
    impl ProposalInbox {
        pub fn observe(
            &mut self,
            proof: &JustifiedProposal,
            set: &ValidatorSet,
            ledger: &Ledger,
        ) -> Result<bool, String> {
            proof.verify(set, ledger)?;
            let proposal = &proof.proposal;
            let key = (proposal.height, proposal.round, proposal.proposer.clone());
            if let Some(prior) = self.seen.get(&key) {
                if prior != &proposal.block.hash {
                    return Err("signed leader equivocation: different block in same round".into());
                }
                return Ok(false);
            }
            if self.seen.len() >= 512 {
                return Err("proposal inbox capacity exceeded".into());
            }
            self.seen.insert(key, proposal.block.hash.clone());
            Ok(true)
        }
        pub fn reset_after_finality(&mut self) {
            self.seen.clear();
        }
    }

    /// Power overlap lower bound for two verified quorums, by inclusion/exclusion.
    /// This is a mathematical test helper, not a model-checking or formal proof of
    /// complete protocol safety under arbitrary asynchronous scheduling.
    pub fn minimum_quorum_overlap(
        total_power: u128,
        first: u128,
        second: u128,
    ) -> Result<u128, String> {
        if total_power == 0 || first > total_power || second > total_power {
            return Err("impossible quorum power".into());
        }
        Ok(first.saturating_add(second).saturating_sub(total_power))
    }
}

// Block 2 additive, authenticated state application boundary.
pub mod certified_node {
    //! Explicit certified-ledger node: signed BFT evidence is required for ANY
    //! append. It does not expose the legacy unfinalized LocalNode::produce_block.
    //! This is an offline/standalone node boundary, NOT a public network daemon.
    use std::path::Path;
    use crate::durable_pending::PendingStore;

    use crate::{
        block::Block,
        consensus::ValidatorSet,
        finality_gate::{FinalityEvidence, FinalityJournal},
        ledger::Genesis,
        tx::SignedTransfer,
    };

    pub struct CertifiedNode {
        pub journal: FinalityJournal,
        pending: Vec<SignedTransfer>,
        pending_store: PendingStore,
        validators: ValidatorSet,
        poisoned: bool,
    }

    impl CertifiedNode {
        pub fn open(
            root: impl AsRef<Path>,
            genesis: Genesis,
            validators: ValidatorSet,
        ) -> Result<Self, String> {
            let journal = FinalityJournal::open(root.as_ref(), genesis, validators.clone())?;
            // Sibling of the strict evidence journal: mixing unfinalized data
            // into FinalityJournal would break its authenticated replay format.
            let (pending_store, pending) = PendingStore::open(
                root.as_ref().with_extension("pending"), &journal.ledger, &validators.hash(),
            )?;
            Ok(Self { journal, pending, pending_store, validators, poisoned: false })
        }

        pub fn height(&self) -> u64 {
            self.journal.ledger.height()
        }

        pub fn durable_healthy(&self) -> bool { !self.poisoned }

        /// Read-only snapshot for bounded devnet gossip. The mempool remains
        /// private, unfinalized and constrained to 128 validated transfers.
        pub fn pending_transfers(&self) -> &[SignedTransfer] {
            &self.pending
        }

        /// A pending transaction is validated against the entire pending queue.
        /// This does NOT change the certified ledger or create a finalized block.
        pub fn submit(&mut self, tx: SignedTransfer, timestamp_ms: u64) -> Result<String, String> {
            if self.poisoned { return Err("durable pending state uncertain; restart required".into()); }
            if self.pending.len() >= 128 {
                return Err("certified node mempool full".into());
            }
            if !tx.verify_signature() {
                return Err("invalid transaction signature".into());
            }
            let id = tx.id();
            if self.pending.iter().any(|old| old.id() == id) {
                return Err("duplicate pending transaction".into());
            }
            let mut proposed = self.pending.clone();
            proposed.push(tx);
            self.journal
                .ledger
                .make_block(proposed.clone(), timestamp_ms)
                .map_err(|e| e.to_string())?;
            if let Err(e) = self.pending_store.save(&proposed, self.journal.ledger.height()) {
                self.poisoned = true;
                return Err(format!("durable queue write failed; restart required: {e}"));
            }
            self.pending = proposed;
            Ok(id)
        }

        /// Candidates can be sent to the nominated proposer. Only receipt of a
        /// fully verified certificate can modify the durable certified ledger.
        pub fn candidate(&self, timestamp_ms: u64) -> Result<Block, String> {
            if self.poisoned { return Err("durable pending state uncertain; restart required".into()); }
            self.journal
                .ledger
                .make_block(self.pending.clone(), timestamp_ms)
                .map_err(|e| e.to_string())
        }

        pub fn import_evidence(&mut self, evidence: FinalityEvidence) -> Result<u64, String> {
            if self.poisoned { return Err("durable pending state uncertain; restart required".into()); }
            // A plainly invalid proof must not poison a healthy node; a failure
            // during an otherwise verified journal append is durability-uncertain.
            evidence.verify(&self.validators, &self.journal.ledger)?;
            if let Err(e) = self.journal.append(evidence) {
                self.poisoned = true;
                return Err(format!("certified append persistence uncertain; restart required: {e}"));
            }
            // Only certified IDs may be discarded automatically. Unconfirmed
            // transfers survive a different valid block when still executable.
            let certified_ids: std::collections::BTreeSet<_> = self.journal.ledger.blocks
                .last().into_iter().flat_map(|b| b.transactions.iter().map(|t| t.id())).collect();
            let remaining: Vec<_> = self.pending.iter().filter(|tx| !certified_ids.contains(&tx.id())).cloned().collect();
            let timestamp = self.journal.ledger.blocks.last().map_or(1, |b| b.timestamp_ms);
            if let Err(e) = self.journal.ledger.make_block(remaining.clone(), timestamp) {
                self.poisoned = true;
                return Err(format!("pending transfer invalid after certified block; operator reconciliation required: {e}"));
            }
            if let Err(e) = self.pending_store.save(&remaining, self.height()) {
                self.poisoned = true;
                return Err(format!("pending checkpoint failed after certified block; restart required: {e}"));
            }
            self.pending = remaining;
            Ok(self.height())
        }
    }
}
