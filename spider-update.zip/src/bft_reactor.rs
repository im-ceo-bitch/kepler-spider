//! Bounded static-membership reactor. Transport independent; local durable state
//! and certificate-only ledger writes. Research implementation, not audited.
use crate::{
    bft_phase2::{Ballot, Phase2Quorum, Phase2Vote},
    bft_proposal::SignedProposal,
    bft_rounds,
    bft_safe_signer::Phase2SafeSigner,
    block::Block,
    consensus::{SignedTimeout, TimeoutCertificate, ValidatorSet, VoteGuard, VoteStep},
    finality_gate::{
        certified_node::CertifiedNode,
        view_change::{JustifiedProposal, MAX_VIEW_CHANGE_ROUND},
        FinalityEvidence,
    },
    ledger::Genesis,
    tx::SignedTransfer,
};
use ed25519_dalek::SigningKey;
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::{self, File, OpenOptions},
    io::Write,
    path::{Path, PathBuf},
};
type Result<T> = std::result::Result<T, String>;
// No 32-round consensus limit: the authenticated round limit is shared with
// proposal/finality verification. Persistence size and journal record caps
// still impose a resource ceiling; hitting those caps fails closed.
const MAX_STATE: usize = 16 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", content = "data", deny_unknown_fields)]
pub enum Message {
    Proposal(JustifiedProposal),
    Vote(Phase2Vote),
    Timeout(SignedTimeout),
    Round(TimeoutCertificate),
    Polka(JustifiedProposal, Phase2Quorum),
    Commit(FinalityEvidence),
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct State {
    set_hash: String,
    height: u64,
    round: u32,
    proposals: BTreeMap<u32, JustifiedProposal>,
    votes: Vec<Phase2Vote>,
    timeouts: Vec<SignedTimeout>,
    rounds: Vec<TimeoutCertificate>,
    valid: Option<(JustifiedProposal, Phase2Quorum)>,
    // Durable signing intent precedes signature creation, including NIL.
    intent: Option<Ballot>,
    timed_out: bool,
}
impl State {
    fn new(set: &ValidatorSet, height: u64) -> Self {
        Self {
            set_hash: set.hash(),
            height,
            round: 0,
            proposals: BTreeMap::new(),
            votes: vec![],
            timeouts: vec![],
            rounds: vec![],
            valid: None,
            intent: None,
            timed_out: false,
        }
    }
}

pub struct Reactor {
    root: PathBuf,
    set: ValidatorSet,
    key: SigningKey,
    signer: Phase2SafeSigner,
    node: CertifiedNode,
    state: State,
    // A failed durability barrier makes this process unsafe to keep using.
    poisoned: bool,
}
impl Reactor {
    pub fn open(
        root: impl AsRef<Path>,
        genesis: Genesis,
        set: ValidatorSet,
        key: SigningKey,
    ) -> Result<Self> {
        fs::create_dir_all(root.as_ref()).map_err(|e| e.to_string())?;
        let root = fs::canonicalize(root).map_err(|e| e.to_string())?;
        let signer = Phase2SafeSigner::open(
            root.join("signer"),
            set.clone(),
            SigningKey::from_bytes(&key.to_bytes()),
        )
        .map_err(|e| e.to_string())?;
        let node = CertifiedNode::open(root.join("certified"), genesis, set.clone())?;
        let path = root.join("reactor.json");
        let state = if path.exists() {
            let meta = fs::symlink_metadata(&path).map_err(|e| e.to_string())?;
            if !meta.is_file() || meta.file_type().is_symlink() || meta.len() > MAX_STATE as u64 {
                return Err("invalid reactor state file".into());
            }
            let saved: State = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
                .map_err(|e| e.to_string())?;
            if saved.set_hash != set.hash() || saved.height > node.height() + 1 {
                return Err("reactor state identity/height mismatch".into());
            }
            if saved.height <= node.height() {
                State::new(&set, node.height() + 1)
            } else {
                saved
            }
        } else {
            // A missing snapshot with existing signing reservations is never a fresh node.
            if fs::read_dir(signer.root().join("votes"))
                .map_err(|e| e.to_string())?
                .next()
                .is_some()
            {
                return Err("missing reactor state with existing votes".into());
            }
            State::new(&set, node.height() + 1)
        };
        let mut result = Self {
            root,
            set,
            key,
            signer,
            node,
            state,
            poisoned: false,
        };
        result.validate_state()?;
        // Legacy snapshots could persist the Polka while omitting the
        // authenticated proposal and its individual prevotes. Reconstruct
        // that verifiable material before joining the network. On any
        // inconsistent replay (including an equivocated slot), fail closed.
        if let Some((proposal, qc)) = result.state.valid.clone() {
            result.remember_polka(proposal, qc)?;
            result.validate_state()?;
        }
        result.save()?;
        Ok(result)
    }
    pub fn height(&self) -> u64 {
        self.node.height()
    }
    pub fn round(&self) -> u32 {
        self.state.round
    }
    pub fn state_root(&self) -> String {
        self.node.journal.ledger.state_root()
    }
    pub fn submit(&mut self, tx: SignedTransfer, timestamp: u64) -> Result<String> {
        self.ensure_healthy()?;
        self.node.submit(tx, timestamp)
    }
    /// Verified but NOT final transfers, to be relayed to the next proposer.
    /// Callers must never interpret this queue as certified ledger state.
    pub fn pending_transfers(&self) -> &[SignedTransfer] {
        self.node.pending_transfers()
    }
    /// Expose only the locally verified journal, never the unconfirmed pool.
    /// The caller must not take ownership or mutate its certified ledger.
    pub fn certified_journal(&self) -> &crate::finality_gate::FinalityJournal {
        &self.node.journal
    }
    pub fn evidence(&self, height: u64) -> Result<FinalityEvidence> {
        self.node.journal.evidence_at(height)
    }
    fn ensure_healthy(&self) -> Result<()> {
        if self.poisoned || !self.node.durable_healthy() {
            return Err("reactor or pending durability uncertain; stop and restart validator".into());
        }
        Ok(())
    }
    fn persist_or_poison(&mut self) -> Result<()> {
        self.ensure_healthy()?;
        if let Err(error) = self.save() {
            self.poisoned = true;
            return Err(format!(
                "reactor persistence failed; restart required: {error}"
            ));
        }
        Ok(())
    }
    fn save(&self) -> Result<()> {
        let bytes = serde_json::to_vec(&self.state).map_err(|e| e.to_string())?;
        if bytes.len() > MAX_STATE {
            return Err("reactor state capacity exceeded".into());
        }
        let tmp = self.root.join("reactor.tmp");
        if tmp.exists() {
            fs::remove_file(&tmp).map_err(|e| e.to_string())?;
        }
        let mut f = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&tmp)
            .map_err(|e| e.to_string())?;
        f.write_all(&bytes)
            .and_then(|_| f.sync_all())
            .map_err(|e| e.to_string())?;
        fs::rename(tmp, self.root.join("reactor.json")).map_err(|e| e.to_string())?;
        File::open(&self.root)
            .and_then(|f| f.sync_all())
            .map_err(|e| e.to_string())
    }
    fn validate_state(&self) -> Result<()> {
        let s = &self.state;
        if s.height != self.node.height().checked_add(1).ok_or("height overflow")?
            || s.round > MAX_VIEW_CHANGE_ROUND
            || s.rounds.len() != s.round as usize
            || s.proposals.len() > (s.round as usize).saturating_add(1)
            || s.votes.len()
                > (s.round as usize)
                    .saturating_add(1)
                    .saturating_mul(self.set.members.len())
                    .saturating_mul(2)
            || s.timeouts.len()
                > (s.round as usize)
                    .saturating_add(1)
                    .saturating_mul(self.set.members.len())
        {
            return Err("invalid reactor bounds".into());
        }
        for (r, qc) in s.rounds.iter().enumerate() {
            qc.verify(&self.set, s.height, r as u32)
                .map_err(|e| e.to_string())?;
        }
        for (r, p) in &s.proposals {
            if *r != p.proposal.round || *r > s.round {
                return Err("invalid stored proposal round".into());
            }
            p.verify(&self.set, &self.node.journal.ledger)?;
        }
        let mut vote_slots = BTreeSet::new();
        for v in &s.votes {
            v.verify(&self.set).map_err(|e| e.to_string())?;
            let step = match v.step {
                VoteStep::Prevote => 1_u8,
                VoteStep::Precommit => 2_u8,
            };
            if !vote_slots.insert((v.round, step, v.signer.clone())) {
                return Err("duplicate or equivocated persisted vote slot".into());
            }
            if v.height != s.height || v.round > s.round {
                return Err("invalid stored vote slot".into());
            }
        }
        let mut timeout_slots = BTreeSet::new();
        for t in &s.timeouts {
            t.verify(&self.set).map_err(|e| e.to_string())?;
            if !timeout_slots.insert((t.round, t.signer.clone())) {
                return Err("duplicate or equivocated persisted timeout slot".into());
            }
            if t.height != s.height || t.round > s.round {
                return Err("invalid stored timeout slot".into());
            }
        }
        if let Some((p, qc)) = &s.valid {
            self.verify_polka(p, qc)?;
        }
        if let Some(Ballot::Block(hash)) = &s.intent {
            if s.proposals.get(&s.round).map(|p| &p.proposal.block.hash) != Some(hash) {
                return Err("vote intent lacks proposal".into());
            }
        }
        Ok(())
    }
    fn verify_polka(&self, p: &JustifiedProposal, qc: &Phase2Quorum) -> Result<()> {
        p.verify(&self.set, &self.node.journal.ledger)?;
        if p.proposal.round > self.state.round {
            return Err("future polka".into());
        }
        qc.verify(
            &self.set,
            self.state.height,
            p.proposal.round,
            VoteStep::Prevote,
            &Ballot::Block(p.proposal.block.hash.clone()),
        )
        .map_err(|e| e.to_string())?;
        Ok(())
    }
    fn remember_polka(&mut self, p: JustifiedProposal, qc: Phase2Quorum) -> Result<bool> {
        self.verify_polka(&p, &qc)?;
        // A Polka can be the first authenticated packet received for a block.
        // Preserve its independently verified proposal, otherwise delayed
        // precommits can never finalize after lost/reordered Proposal packets.
        let mut changed = self.remember_proposal(p.clone())?;
        // Polka carries an authenticated quorum. Retain those signed prevotes
        // as well: finality requires BOTH independently checkable QCs, and a
        // peer may never receive the separate prevote packets after restart.
        for vote in qc.votes.iter().cloned() {
            changed |= self.accept(Message::Vote(vote))?;
        }
        if self
            .state
            .valid
            .as_ref()
            .is_none_or(|(old, _)| old.proposal.round < p.proposal.round)
        {
            self.state.valid = Some((p, qc));
            changed = true;
        }
        Ok(changed)
    }
    /// Replayed proposal metadata is not signed, but its valid-round quorum
    /// is independently authenticated against the signed block commitment.
    /// Never let a stripped proposal permanently hide an authentic later QC.
    /// We accept only monotonically stronger verified justifications and do
    /// not change the nominated signed block or the active round.
    fn remember_proposal(&mut self, p: JustifiedProposal) -> Result<bool> {
        let round = p.proposal.round;
        if round > self.state.round {
            return Err("proposal from an unknown future round".into());
        }
        if let Some(old) = self.state.proposals.get(&round) {
            if old.proposal.block.hash != p.proposal.block.hash {
                return Err("leader equivocation".into());
            }
            if p.valid_round > old.valid_round {
                self.state.proposals.insert(round, p);
                return Ok(true);
            }
            return Ok(false);
        }
        self.state.proposals.insert(round, p);
        Ok(true)
    }
    // A leader's signed proposal carries an authenticated chain of timeout
    // certificates for all preceding rounds. A lagging validator must be able
    // to replay that chain in order, rather than waiting for separately
    // delivered Round packets which can arrive after the proposal.
    fn advance_with_proposal(&mut self, proposal: &JustifiedProposal) -> Result<()> {
        if proposal.proposal.height != self.state.height {
            return Err("proposal belongs to another active height".into());
        }
        if proposal.proposal.round > MAX_VIEW_CHANGE_ROUND {
            return Err("proposal exceeds reactor round bound".into());
        }
        while self.state.round < proposal.proposal.round {
            let round = self.state.round as usize;
            let certificate = proposal
                .view_changes
                .get(round)
                .ok_or("proposal lacks intermediate round certificate")?
                .clone();
            self.accept(Message::Round(certificate))?;
        }
        Ok(())
    }
    pub fn receive(&mut self, message: Message) -> Result<()> {
        self.ensure_healthy()?;
        // Reject invalid remote input without mutating the working state.
        // Certificate append is a separate durable transaction: on partial I/O
        // failure the only safe action is to stop signing until clean replay.
        let incoming_height = match &message {
            Message::Commit(proof) if proof.proposal.height > self.node.height() => {
                Some(proof.proposal.height)
            }
            _ => None,
        };
        let previous_height = self.node.height();
        let previous = self.state.clone();
        let changed = match self.accept(message) {
            Ok(changed) => changed,
            Err(e) => {
                self.state = previous;
                if self.node.height() != previous_height
                    || incoming_height.is_some_and(|h| {
                        let journal = self.root.join("certified");
                        journal.join(format!(".staging-{h:020}")).exists()
                            || journal.join(format!("{h:020}.json")).exists()
                    })
                {
                    self.poisoned = true;
                    return Err(format!(
                        "certified journal may have changed; restart required: {e}"
                    ));
                }
                return Err(e);
            }
        };
        // Retransmitted votes, certificates and blocks are normal in BFT.
        // Avoid rewriting an unchanged snapshot on network replay.
        if changed {
            self.persist_or_poison()?;
        }
        Ok(())
    }
    fn accept(&mut self, message: Message) -> Result<bool> {
        match message {
            Message::Proposal(p) => {
                p.verify(&self.set, &self.node.journal.ledger)?;
                if p.proposal.height != self.state.height {
                    return Err("proposal is not in active height".into());
                }
                // Store previously unseen, independently authenticated historical
                // proposals even after view change. Their delayed votes may form
                // a finality QC; dropping them prevents certified catch-up.
                // Never rewind the active round or sign a historical ballot.
                if p.proposal.round > self.state.round {
                    self.advance_with_proposal(&p)?;
                }
                return self.remember_proposal(p);
            }
            Message::Vote(v) => {
                v.verify(&self.set).map_err(|e| e.to_string())?;
                if v.height != self.state.height || v.round > self.state.round {
                    return Err("vote outside active height/known rounds".into());
                }
                if let Some(old) = self.state.votes.iter().find(|old| {
                    old.round == v.round && old.step == v.step && old.signer == v.signer
                }) {
                    if old != &v {
                        return Err("double vote".into());
                    }
                    return Ok(false);
                } else {
                    self.state.votes.push(v);
                }
            }
            Message::Timeout(t) => {
                t.verify(&self.set).map_err(|e| e.to_string())?;
                if t.height != self.state.height || t.round > self.state.round {
                    return Err("timeout outside active slot".into());
                }
                // Historical authenticated timeouts are already represented by
                // durable round QCs; never recreate them after a view change.
                if t.round < self.state.round {
                    return Ok(false);
                }
                if let Some(old) = self
                    .state
                    .timeouts
                    .iter()
                    .find(|old| old.round == t.round && old.signer == t.signer)
                {
                    if old != &t {
                        return Err("conflicting signed timeout".into());
                    }
                    return Ok(false);
                }
                self.state.timeouts.push(t);
            }
            Message::Round(qc) => {
                let r = qc.votes.first().ok_or("empty round certificate")?.round;
                qc.verify(&self.set, self.state.height, r)
                    .map_err(|e| e.to_string())?;
                if r < self.state.round {
                    return Ok(false);
                }
                if r != self.state.round || r >= MAX_VIEW_CHANGE_ROUND {
                    return Err("round outside bounded reactor".into());
                }
                self.state.rounds.push(qc);
                self.state.round += 1;
                self.state.intent = None;
                self.state.timed_out = false;
            }
            Message::Polka(p, qc) => {
                return self.remember_polka(p, qc);
            }
            Message::Commit(proof) => {
                if proof.proposal.height <= self.node.height() {
                    let old = self.node.journal.evidence_at(proof.proposal.height)?;
                    if old.proposal.block.hash != proof.proposal.block.hash {
                        return Err("conflicting finalized history".into());
                    }
                    return Ok(false);
                }
                self.node.import_evidence(proof)?;
                self.state = State::new(&self.set, self.node.height() + 1);
            }
        }
        Ok(true)
    }
    fn quorum(&self, round: u32, step: VoteStep, hash: &str) -> Option<Phase2Quorum> {
        let target = Ballot::Block(hash.into());
        let q = Phase2Quorum {
            votes: self
                .state
                .votes
                .iter()
                .filter(|v| v.round == round && v.step == step && v.target == target)
                .cloned()
                .collect(),
        };
        q.verify(&self.set, self.state.height, round, step, &target)
            .ok()?;
        Some(q)
    }
    /// Caller supplies monotonic timer events. Repeated timeouts are idempotent.
    pub fn timeout(&mut self) -> Result<()> {
        self.ensure_healthy()?;
        if self.state.intent.is_none() {
            self.state.intent = Some(Ballot::Nil);
        }
        self.state.timed_out = true;
        self.persist_or_poison()
    }
    /// Execute one deterministic reactor turn. Persist before releasing messages.
    pub fn tick(&mut self, timestamp: u64) -> Result<Vec<Message>> {
        self.ensure_healthy()?;
        let id = hex::encode(self.key.verifying_key().to_bytes());
        let h = self.state.height;
        let r = self.state.round;
        // Late QCs can finalize an older round, even after a local timeout.
        for p in self.state.proposals.values().cloned().collect::<Vec<_>>() {
            let pr = p.proposal.round;
            let hash = &p.proposal.block.hash;
            if let Some(pv) = self.quorum(pr, VoteStep::Prevote, hash) {
                if self.remember_polka(p.clone(), pv.clone())? {
                    self.persist_or_poison()?;
                }
                if let Some(pc) = self.quorum(pr, VoteStep::Precommit, hash) {
                    let evidence = FinalityEvidence {
                        proposal: p.proposal,
                        prevotes: pv,
                        precommits: pc,
                        view_changes: p.view_changes,
                    };
                    self.receive(Message::Commit(evidence.clone()))?;
                    return Ok(vec![Message::Commit(evidence)]);
                }
            }
        }
        let tc = TimeoutCertificate {
            votes: self
                .state
                .timeouts
                .iter()
                .filter(|v| v.round == r)
                .cloned()
                .collect(),
        };
        if r < MAX_VIEW_CHANGE_ROUND && tc.verify(&self.set, h, r).is_ok() {
            self.receive(Message::Round(tc))?;
            return self.outbox();
        }
        if !self.state.proposals.contains_key(&r)
            && id == bft_rounds::proposer(&self.set, h, r).map_err(|e| e.to_string())?
        {
            let (block, valid_round, valid_round_qc) = match &self.state.valid {
                Some((p, qc)) if p.proposal.round < r => (
                    p.proposal.block.clone(),
                    Some(p.proposal.round),
                    Some(qc.clone()),
                ),
                _ => (self.node.candidate(timestamp)?, None, None),
            };
            // Reserve the full candidate BEFORE proposer signing; timestamp and
            // mempool changes after restart cannot cause an alternate proposal.
            // Candidate reservations are part of the signing safety boundary.
            // Even a pre-signature failed write may leave a partial candidate
            // behind. Never resume in-process or silently sign another block.
            let reservation = (|| -> Result<Block> {
                let candidate_path = self.root.join(format!("candidate-{h}-{r}.json"));
                if let Ok(meta) = fs::symlink_metadata(&candidate_path) {
                    if !meta.is_file()
                        || meta.file_type().is_symlink()
                        || meta.len() > MAX_STATE as u64
                    {
                        return Err("unsafe candidate reservation".into());
                    }
                    let bytes = fs::read(&candidate_path).map_err(|e| e.to_string())?;
                    if bytes.len() > MAX_STATE {
                        return Err("candidate too large".into());
                    }
                    serde_json::from_slice(&bytes).map_err(|e| e.to_string())
                } else {
                    let bytes = serde_json::to_vec(&block).map_err(|e| e.to_string())?;
                    if bytes.len() > MAX_STATE {
                        return Err("candidate too large".into());
                    }
                    let mut f = OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(&candidate_path)
                        .map_err(|e| e.to_string())?;
                    f.write_all(&bytes)
                        .and_then(|_| f.sync_all())
                        .map_err(|e| e.to_string())?;
                    File::open(&self.root)
                        .and_then(|f| f.sync_all())
                        .map_err(|e| e.to_string())?;
                    Ok(block)
                }
            })();
            let block = match reservation {
                Ok(block) => block,
                Err(error) => {
                    self.poisoned = true;
                    return Err(format!(
                        "candidate reservation unsafe; restart required: {error}"
                    ));
                }
            };
            let proposal = SignedProposal::sign(
                &self.set,
                &self.key,
                &VoteGuard::open(self.root.join(format!("proposer-{h}-{r}")))
                    .map_err(|e| e.to_string())?,
                &self.node.journal.ledger,
                r,
                block,
            )
            .map_err(|e| e.to_string())?;
            let p = JustifiedProposal {
                proposal,
                valid_round,
                valid_round_qc,
                view_changes: self.state.rounds.clone(),
            };
            self.receive(Message::Proposal(p))?;
        }
        let proposal = self.state.proposals.get(&r).cloned();
        if self.state.intent.is_none() {
            if let Some(p) = &proposal {
                let target = Ballot::Block(p.proposal.block.hash.clone());
                self.state.intent = Some(
                    self.signer
                        .eligible_ballot(h, r, target, p.valid_round_qc.as_ref())
                        .map_err(|e| e.to_string())?,
                );
                self.persist_or_poison()?;
            }
        }
        let unlock = match (
            &proposal,
            self.signer.locked_value(h).map_err(|e| e.to_string())?,
        ) {
            (Some(p), Some((_, hash))) if hash != p.proposal.block.hash => p.valid_round_qc.clone(),
            _ => None,
        };
        if let Some(target) = self.state.intent.clone() {
            let vote = self
                .signer
                .prevote(h, r, target.clone(), unlock.as_ref())
                .map_err(|e| e.to_string())?;
            self.receive(Message::Vote(vote))?;
            if let (Ballot::Block(hash), Some(p)) = (&target, &proposal) {
                if let Some(qc) = self.quorum(r, VoteStep::Prevote, hash) {
                    if self.remember_polka(p.clone(), qc.clone())? {
                        self.persist_or_poison()?;
                    }
                    let vote = self
                        .signer
                        .precommit(h, r, target, &qc, unlock.as_ref())
                        .map_err(|e| e.to_string())?;
                    self.receive(Message::Vote(vote))?;
                }
            }
        }
        if self.state.timed_out {
            let t = VoteGuard::open(self.root.join("timeouts"))
                .map_err(|e| e.to_string())?
                .timeout(&self.set, &self.key, h, r)
                .map_err(|e| e.to_string())?;
            self.receive(Message::Timeout(t))?;
        }
        // All state mutations have already been persisted before publication.
        // A no-op tick must not synchronously rewrite the entire snapshot.
        self.outbox()
    }
    fn outbox(&self) -> Result<Vec<Message>> {
        // Certified catch-up data takes priority over historical gossip. In a
        // slow receiver's TCP backlog this avoids burying finalized blocks
        // behind thousands of replayed old votes.
        let mut out = Vec::new();
        for h in self.node.height().saturating_sub(15).max(1)..=self.node.height() {
            out.push(Message::Commit(self.evidence(h)?));
        }
        out.extend(self.state.rounds.iter().cloned().map(Message::Round));
        if let Some(proposal) = self.state.proposals.get(&self.state.round) {
            out.push(Message::Proposal(proposal.clone()));
        }
        out.extend(
            self.state
                .votes
                .iter()
                .filter(|v| v.round == self.state.round)
                .cloned()
                .map(Message::Vote),
        );
        out.extend(
            self.state
                .timeouts
                .iter()
                .filter(|t| t.round == self.state.round)
                .cloned()
                .map(Message::Timeout),
        );
        if let Some((p, qc)) = &self.state.valid {
            out.push(Message::Polka(p.clone(), qc.clone()));
        }
        // Prior-round votes remain available for delayed QCs. They are sent
        // after the current height/round and finalized evidence.
        out.extend(
            self.state
                .proposals
                .iter()
                .filter(|(r, _)| **r < self.state.round)
                .map(|(_, p)| Message::Proposal(p.clone())),
        );
        out.extend(
            self.state
                .votes
                .iter()
                .filter(|v| v.round < self.state.round)
                .cloned()
                .map(Message::Vote),
        );
        out.extend(
            self.state
                .timeouts
                .iter()
                .filter(|t| t.round < self.state.round)
                .cloned()
                .map(Message::Timeout),
        );
        Ok(out)
    }
}
