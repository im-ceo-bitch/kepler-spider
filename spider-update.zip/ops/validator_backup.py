#!/usr/bin/env python3
"""Offline-only validator state backup and checksum-verified restore.

Never backs up signing keys. No backup may be trusted as a proof of BFT
finality: replay the Rust verifier and compare certified state roots on restore.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import zipfile

MAX_FILES = 20_000
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 512 * 1024 * 1024
PREFIXES = ('signer', 'certified', 'certified.pending', 'timeouts')
ROOT_NAMES = ('reactor.json',)
DENIED = ('secret', 'private', 'seed', 'mnemonic', 'token', 'password', 'key_file', 'key_hex')


def allowed(name: str) -> bool:
    p = PurePosixPath(name)
    if p.is_absolute() or str(p) != name or not p.parts or any(x in ('..', '.', '') for x in p.parts):
        return False
    if any(word in part.lower() for part in p.parts for word in DENIED):
        return False
    if len(p.parts) == 1:
        return name in ROOT_NAMES or (name.startswith('candidate-') and name.endswith('.json'))
    return p.parts[0] in PREFIXES or p.parts[0].startswith('proposer-')


def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_member(info: zipfile.ZipInfo) -> str:
    name = info.filename
    if info.is_dir() or not allowed(name) or info.file_size > MAX_FILE or info.file_size < 0:
        raise ValueError('unsafe archive member: ' + repr(name))
    file_type = stat.S_IFMT(info.external_attr >> 16)
    if file_type not in (0, stat.S_IFREG):
        raise ValueError('archive contains a special file: ' + name)
    return name


def verify_archive(archive: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(archive, 'r') as z:
        entries = z.infolist()
        if len(entries) > MAX_FILES + 1 or not entries or sum(i.file_size for i in entries) > MAX_TOTAL:
            raise ValueError('unsafe backup file count/size')
        if sum(i.filename == 'manifest.json' for i in entries) != 1:
            raise ValueError('backup manifest missing or duplicated')
        manifest_info = z.getinfo('manifest.json')
        if manifest_info.file_size > 1024 * 1024:
            raise ValueError('manifest too large')
        manifest = json.loads(z.read(manifest_info))
        if not isinstance(manifest, dict) or manifest.get('format') != 'SPIDER-OFFLINE-BACKUP-V1':
            raise ValueError('invalid backup format')
        expected = manifest.get('files')
        if not isinstance(expected, dict) or len(expected) > MAX_FILES:
            raise ValueError('invalid backup manifest file list')
        seen = set()
        actual = {}
        for info in entries:
            if info.filename == 'manifest.json':
                continue
            name = check_member(info)
            if name in seen or name not in expected:
                raise ValueError('duplicate/undocumented backup member')
            seen.add(name)
            data = z.read(info)
            if len(data) != info.file_size or expected[name] != {'size': len(data), 'sha256': hash_bytes(data)}:
                raise ValueError('corrupted backup: ' + name)
            actual[name] = data
        if set(expected) != seen:
            raise ValueError('missing backup records')
        return actual


def offline_locks(root: Path):
    """Hold exclusive ownership locks while copying; refuses a running Rust node."""
    import fcntl  # POSIX; intentionally no silent cross-platform fallback
    handles = []
    try:
        for name in ('signer/OWNER', 'certified/LOCK'):
            p = root / name
            if not p.exists():
                continue
            if not p.is_file() or p.is_symlink():
                raise ValueError('unsafe owner lock')
            fd = p.open('rb')
            handles.append(fd)
            try:
                fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as e:
                raise ValueError('validator appears to be running; stop it before backup') from e
        return handles
    except Exception:
        for h in handles:
            h.close()
        raise


def backup(root: Path, dest: Path, stopped: bool) -> int:
    if not stopped:
        raise ValueError('explicit --confirm-stopped is mandatory')
    if root.is_symlink() or not root.is_dir() or dest.exists():
        raise ValueError('invalid state root or existing backup destination')
    if root.resolve() in dest.resolve().parents:
        raise ValueError('backup must be outside validator state directory')
    locks = offline_locks(root)
    try:
        files = {}
        total = 0
        for p in sorted(root.rglob('*')):
            if p.is_symlink():
                raise ValueError('symlink in validator state: ' + str(p))
            if p.is_dir():
                continue
            rel = p.relative_to(root).as_posix()
            if not allowed(rel) or not p.is_file():
                raise ValueError('unrecognized or potentially secret state file: ' + rel)
            size = p.stat().st_size
            if size > MAX_FILE or len(files) >= MAX_FILES or total + size > MAX_TOTAL:
                raise ValueError('backup exceeds bounded limits')
            files[rel] = p.read_bytes()
            total += len(files[rel])
        if not files or not any(n.startswith('certified/') for n in files):
            raise ValueError('no certified journal to back up')
        manifest = {'format': 'SPIDER-OFFLINE-BACKUP-V1', 'files': {n: {'size':len(b), 'sha256':hash_bytes(b)} for n,b in files.items()},
                    'warning': 'Hash integrity only. Rust certificate verification and secret-key restoration are separate.'}
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(dest, 'x', compression=zipfile.ZIP_STORED) as z:
                z.writestr('manifest.json', json.dumps(manifest, sort_keys=True, separators=(',', ':')))
                for name, data in files.items():
                    z.writestr(name, data)
            verify_archive(dest)
        except Exception:
            dest.unlink(missing_ok=True)
            raise
        return len(files)
    finally:
        for handle in locks:
            handle.close()


def restore(archive: Path, root: Path) -> int:
    # Verify *before* creating any state directory.
    records = verify_archive(archive)
    if root.exists() or root.is_symlink():
        raise ValueError('restore target must not exist; never overwrite validator WAL')
    root.mkdir(mode=0o700, parents=False)
    try:
        for rel, data in records.items():
            dest = root.joinpath(*PurePosixPath(rel).parts)
            dest.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with dest.open('xb') as f:
                os.chmod(dest, 0o600)
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
        # Rust startup is still required to cryptographically replay the journal.
        return len(records)
    except Exception:
        shutil.rmtree(root)
        raise


def main():
    p = argparse.ArgumentParser(description='Offline Spider Chain validator state backup (never includes private keys)')
    sub = p.add_subparsers(dest='cmd', required=True)
    create = sub.add_parser('create')
    create.add_argument('--state-dir', type=Path, required=True)
    create.add_argument('--output', type=Path, required=True)
    create.add_argument('--confirm-stopped', action='store_true')
    verify = sub.add_parser('verify')
    verify.add_argument('--archive', type=Path, required=True)
    recover = sub.add_parser('restore')
    recover.add_argument('--archive', type=Path, required=True)
    recover.add_argument('--state-dir', type=Path, required=True)
    args = p.parse_args()
    if args.cmd == 'create':
        count = backup(args.state_dir, args.output, args.confirm_stopped)
    elif args.cmd == 'verify':
        count = len(verify_archive(args.archive))
    else:
        count = restore(args.archive, args.state_dir)
    print(f'PASS {args.cmd}: {count} files; cryptographic evidence replay remains mandatory')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile) as e:
        sys.exit(f'SPIDER BACKUP FAILED: {e}')
