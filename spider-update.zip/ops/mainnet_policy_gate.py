#!/usr/bin/env python3
"""Human evidence checklist; not a cryptographic audit or automatic mainnet activation."""
import argparse
import json
from pathlib import Path
import re

EXPECTED = frozenset((
    'consensus_safety_review', 'four_independent_hosts',
    'partition_recovery_and_byzantine_testing',
    'wallet_https_to_certified_receipt_real_device',
    'wallet_restart_and_double_send_regression',
    'key_custody_and_multisignature_ops',
    'backup_restore_and_corrupt_disk_drill',
    'independent_security_audit',
    'validator_join_leave_slashing_and_governance',
    'spd_emission_fees_and_vesting',
    'genesis_address_multisigner_review',
    'legal_classification_uzbekistan_and_target_markets',
    'aml_sanctions_privacy_and_consumer_protection',
    'incident_management_and_upgrade_drill',
))
HEX = re.compile(r'[a-f0-9]{64}\Z')

def check(path: Path):
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('network') != 'spider-mainnet-1' or data.get('release_target') != 'CLOSED_NO_REAL_ASSETS':
        raise ValueError('mainnet is deliberately release-locked')
    decisions = data.get('decisions')
    if not isinstance(decisions, dict) or decisions.keys() != EXPECTED:
        raise ValueError('required mainnet decisions absent or changed')
    outstanding = []
    for name in sorted(EXPECTED):
        entry = decisions[name]
        if not isinstance(entry, dict) or type(entry.get('approved')) is not bool:
            raise ValueError('invalid approval structure: ' + name)
        if not (entry['approved'] and isinstance(entry.get('evidence_sha256'), str)
                and HEX.fullmatch(entry['evidence_sha256'])):
            outstanding.append(name)
    return outstanding

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Spider Chain mainnet checklist (NEVER an automated launch authorization)')
    p.add_argument('--policy', type=Path, default=Path('launch/mainnet-readiness.json'))
    p.add_argument('--require-complete', action='store_true')
    a = p.parse_args()
    try:
        missing = check(a.policy)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as e:
        p.exit(2, f'BLOCKED: invalid release policy: {e}\n')
    print(json.dumps({'status': 'BLOCKED' if missing else 'DOCUMENTARY_REVIEW_COMPLETE_NOT_AUTOMATED_LAUNCH', 'outstanding': missing}, indent=2))
    if a.require_complete and missing:
        p.exit(2, f'BLOCKED: {len(missing)} mainnet acceptance items lack human sign-off\n')
