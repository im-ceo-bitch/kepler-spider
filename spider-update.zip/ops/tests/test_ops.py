"""Executable operational safeguards; no production finality claim."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

HERE = Path(__file__).resolve().parents[1]
def load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / (name + '.py'))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

backup = load('validator_backup')
probe = load('devnet_probe')

class BackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = Path(self.tmp.name)
        self.root = self.p / 'validator'
        (self.root / 'certified').mkdir(parents=True)
        (self.root / 'signer').mkdir()
        (self.root / 'certified.pending').mkdir()
        (self.root / 'reactor.json').write_text('{}')
        (self.root / 'certified' / 'manifest.json').write_text('a')
        (self.root / 'certified' / 'LOCK').write_text('')
        (self.root / 'signer' / 'OWNER').write_text('')
        (self.root / 'certified.pending' / 'pending.json').write_text('b')
        self.zip = self.p / 'state.zip'

    def test_roundtrip_and_corruption_detection(self):
        with self.assertRaisesRegex(ValueError, 'confirm-stopped'):
            backup.backup(self.root, self.zip, False)
        self.assertEqual(backup.backup(self.root, self.zip, True), 5)
        self.assertEqual(len(backup.verify_archive(self.zip)), 5)
        restored = self.p / 'recovered'
        self.assertEqual(backup.restore(self.zip, restored), 5)
        self.assertEqual((restored / 'certified.pending' / 'pending.json').read_text(), 'b')
        with self.assertRaises(ValueError):
            backup.restore(self.zip, restored)
        tampered = self.p / 'corrupt.zip'
        with zipfile.ZipFile(self.zip) as z, zipfile.ZipFile(tampered, 'w') as out:
            for member in z.namelist():
                data = z.read(member)
                out.writestr(member, b'changed' if member == 'reactor.json' else data)
        with self.assertRaisesRegex(ValueError, 'corrupted'):
            backup.verify_archive(tampered)

    def test_secrets_and_symlinks_refused(self):
        (self.root / 'secret.key').write_text('unsafe')
        with self.assertRaises(ValueError):
            backup.backup(self.root, self.zip, True)
        (self.root / 'secret.key').unlink()
        (self.root / 'signer' / 'linked').symlink_to(self.root / 'reactor.json')
        with self.assertRaises(ValueError):
            backup.backup(self.root, self.zip, True)

    def test_zip_path_traversal_refused(self):
        with zipfile.ZipFile(self.zip, 'w') as z:
            z.writestr('manifest.json', json.dumps({'format':'SPIDER-OFFLINE-BACKUP-V1', 'files':{'../escape':{'size':1, 'sha256':'0'*64}}}))
            z.writestr('../escape', 'x')
        with self.assertRaises(ValueError):
            backup.restore(self.zip, self.p / 'out')
        self.assertFalse((self.p / 'out').exists())

class ProbeTests(unittest.TestCase):
    def status(self, h=3, root='a'*64, chain='spider-devnet-1'):
        return dict(network='SPIDER_CERTIFIED_DEVNET_RESEARCH', chain_id=chain,
                    genesis_hash='b'*64, height=h, state_root=root, real_spd=False, real_usdt=False)

    def test_stale_monitor_and_height_rollback(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'progress.json'
            status = [self.status(2)]
            probe.track_progress(path, ['a'], status, 'spider-devnet-1', 'b'*64, 60, now=100)
            probe.track_progress(path, ['a'], status, 'spider-devnet-1', 'b'*64, 60, now=140)
            with self.assertRaisesRegex(ValueError, 'stale'):
                probe.track_progress(path, ['a'], status, 'spider-devnet-1', 'b'*64, 60, now=161)
            with self.assertRaisesRegex(ValueError, 'backwards'):
                probe.track_progress(path, ['a'], [self.status(1)], 'spider-devnet-1', 'b'*64, 60, now=150)
            probe.track_progress(path, ['a'], [self.status(3)], 'spider-devnet-1', 'b'*64, 60, now=162)

    def test_equal_roots_and_lag(self):
        self.assertEqual(probe.validate(['a', 'b'], [self.status(), self.status()], 'spider-devnet-1', 'b'*64, 1)['nodes'], 2)
        with self.assertRaisesRegex(ValueError, 'FORK'):
            probe.validate(['a', 'b'], [self.status(), self.status(root='c'*64)], 'spider-devnet-1', 'b'*64, 1)
        with self.assertRaisesRegex(ValueError, 'lag'):
            probe.validate(['a', 'b'], [self.status(2), self.status(7)], 'spider-devnet-1', 'b'*64, 2)
        with self.assertRaisesRegex(ValueError, 'identity'):
            probe.validate(['a'], [self.status(chain='foreign')], 'spider-devnet-1', 'b'*64, 2)
        with self.assertRaisesRegex(ValueError, 'snapshot'):
            probe.validate(['a'], [self.status(root='bad')], 'spider-devnet-1', 'b'*64, 2)

if __name__ == '__main__': unittest.main()
