import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'mainnet_policy_gate.py'
spec = importlib.util.spec_from_file_location('mainnet_policy_gate', SOURCE)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)

class MainnetGateTests(unittest.TestCase):
    def test_mainnet_draft_is_always_blocked(self):
        path = SOURCE.parents[1] / 'launch/mainnet-readiness.json'
        missing = policy.check(path)
        self.assertEqual(len(missing), len(policy.EXPECTED))

    def test_missing_requirement_or_false_evidence_rejected(self):
        raw = json.loads((SOURCE.parents[1] / 'launch/mainnet-readiness.json').read_text())
        raw['decisions'].pop('independent_security_audit')
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'policy.json'
            path.write_text(json.dumps(raw))
            with self.assertRaises(ValueError): policy.check(path)
            raw['decisions']['independent_security_audit'] = {'approved': True, 'evidence_sha256': 'not-a-hash'}
            path.write_text(json.dumps(raw))
            self.assertIn('independent_security_audit', policy.check(path))

if __name__ == '__main__': unittest.main()
