#!/usr/bin/env python3
"""Independent, fail-closed HTTPS read probe for up to 4 Spider devnet endpoints.
An authenticated status endpoint is NOT equivalent to verifying a BFT proof.
"""
from __future__ import annotations
import argparse
import json
import re
import ssl
import os
import stat
import time
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
from pathlib import Path
import sys

HEX = re.compile(r'[a-f0-9]{64}\Z')


def validate(origins: list[str], statuses: list[dict], chain: str, genesis: str, max_lag: int) -> dict:
    if len(origins) != len(statuses) or not 1 <= len(origins) <= 4:
        raise ValueError('one to four independently reachable endpoints required')
    roots = {}
    heights = []
    for origin, s in zip(origins, statuses):
        if (s.get('network') != 'SPIDER_CERTIFIED_DEVNET_RESEARCH' or s.get('chain_id') != chain
                or s.get('genesis_hash') != genesis or s.get('real_spd') is not False
                or s.get('real_usdt') is not False):
            raise ValueError(f'invalid network identity at {origin}')
        h = s.get('height'); root = s.get('state_root')
        if type(h) is not int or h < 0 or not isinstance(root, str) or not HEX.fullmatch(root):
            raise ValueError(f'invalid certified state snapshot at {origin}')
        heights.append(h)
        if h in roots and roots[h] != root:
            raise ValueError(f'FORK ALERT: different state roots at height={h}')
        roots[h] = root
    if max(heights) - min(heights) > max_lag:
        raise ValueError('validator certified-height lag exceeds threshold')
    return {'status': 'research_status_only_not_certificate_verification', 'nodes': len(origins),
            'min_height': min(heights), 'max_height': max(heights), 'matching_roots_at_equal_heights': True}


def fetch(origin: str, token: str) -> dict:
    u = urlsplit(origin)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('', '/'):
        raise ValueError('health origins must be HTTPS hosts without credentials or paths')
    req = Request(origin.rstrip('/') + '/v1/status', headers={'Authorization': 'Bearer ' + token})
    with urlopen(req, timeout=8, context=ssl.create_default_context()) as response:
        if response.status != 200:
            raise ValueError('status request failed')
        data = response.read(32769)
        if len(data) > 32768:
            raise ValueError('status exceeds 32 KiB')
        return json.loads(data)


def track_progress(checkpoint: Path, origins: list[str], statuses: list[dict],
                   chain: str, genesis: str, stale_seconds: int, now: float | None = None):
    """A persistent stagnation alarm. Single writer; safe from symlink substitution."""
    if stale_seconds < 60:
        raise ValueError('stale threshold must be >=60 seconds')
    now = time.time() if now is None else now
    current = dict(zip(origins, (s['height'] for s in statuses)))
    old = None
    try:
        meta = checkpoint.lstat()
    except FileNotFoundError:
        pass
    else:
        if not stat.S_ISREG(meta.st_mode) or meta.st_size > 16384:
            raise ValueError('unsafe monitoring checkpoint')
        old = json.loads(checkpoint.read_text())
        if old.get('chain_id') != chain or old.get('genesis_hash') != genesis:
            raise ValueError('monitor checkpoint network changed')
    previous = old.get('nodes', {}) if old else {}
    updated = {}
    for origin, height in current.items():
        last = previous.get(origin, {})
        if type(last.get('height')) is int and height < last['height']:
            raise ValueError('certified height rolled backwards at ' + origin)
        since = last.get('since') if last.get('height') == height else now
        if type(since) not in (int, float) or since > now:
            raise ValueError('invalid monitoring clock/checkpoint')
        if now - since >= stale_seconds:
            raise ValueError('certified height stale at ' + origin)
        updated[origin] = {'height': height, 'since': since}
    record = {'version': 1, 'chain_id': chain, 'genesis_hash': genesis, 'nodes': updated}
    # Atomic file replacement prevents a truncated checkpoint from passing.
    raw = json.dumps(record, sort_keys=True).encode()
    if len(raw) > 16384:
        raise ValueError('checkpoint too large')
    tmp = checkpoint.with_name(checkpoint.name + '.tmp')
    if tmp.is_symlink() or tmp.exists():
        raise ValueError('stale or unsafe monitoring checkpoint temp file')
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(tmp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, checkpoint)
    directory_fd = os.open(checkpoint.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def main():
    p = argparse.ArgumentParser(description='Spider verified-devnet read-only HTTPS probe')
    p.add_argument('--origin', action='append', required=True, help='One per independent endpoint, up to 4')
    p.add_argument('--token-file', type=Path, action='append', required=True,
                   help='One separate chmod-600 token file per --origin in the same order')
    p.add_argument('--chain-id', required=True)
    p.add_argument('--genesis-hash', required=True)
    p.add_argument('--max-lag', type=int, default=2)
    p.add_argument('--state-file', type=Path, help='Durable local checkpoint for stagnation alerts')
    p.add_argument('--stale-seconds', type=int, default=600)
    a = p.parse_args()
    if len(a.origin) > 4 or len(a.origin) != len(a.token_file) or a.max_lag < 0 or not HEX.fullmatch(a.genesis_hash):
        p.error('invalid endpoint count, lag or genesis hash')
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'gateway'))
    from spider_wallet_gateway import token_from_file
    tokens = [token_from_file(str(p)) for p in a.token_file]
    statuses = [fetch(origin, token) for origin, token in zip(a.origin, tokens)]
    result = validate(a.origin, statuses, a.chain_id, a.genesis_hash, a.max_lag)
    if a.state_file:
        track_progress(a.state_file, a.origin, statuses, a.chain_id, a.genesis_hash, a.stale_seconds)
    print(json.dumps(result, sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as e:
        sys.exit(f'SPIDER DEVNET PROBE FAILED: {e}')
