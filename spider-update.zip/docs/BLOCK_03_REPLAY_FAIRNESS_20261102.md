# Spider Chain — Block 3: durable wallet ingress replay, incremental patch (2026-11-02)

**Status:** Block 3 Devnet engineering increment, not a public/mainnet-ready network.
**Dependency:** The operator reports that the preceding Block 2 ZIP Installer run completed successfully. Block 2 is **frozen as a Devnet implementation**, not independently security-audited; this patch deliberately does not change any consensus, Rust, signing, or Block 1 source file.

## Fixed

The HTTPS backend (`gateway/spider_wallet_gateway.py`) previously selected the 16 oldest `signed_pending` records on **every** retry iteration. When 17–256 unfinalized transfers accumulated during an outage, the remaining requests could be starved forever. It also deleted every request older than 24 hours even when no certified finality had been observed.

- Retry uses a bounded 16-item **wrapping, stable transaction-ID cursor**. All rows receive service across rounds. SQLite WAL + `synchronous=FULL` remain unchanged.
- Never delete an unfinalized signed payload based **only** on wall-clock age. The queue removes requests when the existing trusted certified-state reader returns `{ "id": <same exact txid>, "finalized": true }`, or the existing initial submission flow gets a definitive local 400/422 response. A replay 422 does not erase prior evidence.
- The existing hard 256-entry capacity is **preserved**. Old or impossible-to-finalize transfers may exhaust the queue; adding explicit expiry-height evidence and an audited operator remediation workflow is a required follow-up. Operators must not interpret persistent retries as a payment confirmation.
- No raw private keys, mnemonics, BFT votes, certificate validation, or consensus thresholds are changed.

## Verification

The release candidate is checked in a disposable tree after applying this ZIP on top of the previous cumulative patch. Use:

```bash
python3 -m unittest discover -s gateway/tests -v
python3 tools/block1_release_gate.py
cargo fmt --all -- --check
cargo check --all-targets
cargo test --all-targets
cargo clippy --all-targets
```

The new 4 tests cover 256-row fairness, old-row preservation, verified transaction-ID matching before removal, restart persistence, and queue bounds. **Rust/Cargo cannot be verified in the authoring container**; all GitHub Installer Rust gates must still succeed before this is accepted. Nothing in this patch changes Rust sources.

## Remaining to complete Block 3

1. Public multi-host encrypted/authenticated P2P validator operation with persistent peer scoring, reconnect/backoff, resource quotas, controlled identity rotation and observability.
2. Durable *validator-side* mempool and admission decisions derived from certified state; gateway SQLite durability alone does not prove consensus persistence.
3. Height-aware expiry evidence, operator-visible queue metrics, controlled retention and recovery of stale pending transactions.
4. End-to-end four-server finalization and catch-up tests after partitions, including network abuse, disk faults and wallet transaction receipts.
5. Independent security audit and key/operations runbook before storing real value.

Do **not** treat HTTP 202, a durable queued request, or this patch as finality, real SPD or real USDT functionality.
