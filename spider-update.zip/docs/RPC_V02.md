# Spider Local Node / RPC v0.2

**Status: local Devnet research only. NOT P2P, NOT BFT/consensus-final, NOT real USDT.**

## Run

```bash
cargo run --bin spider-node -- demo
cargo run --bin spider-node -- serve ./spider-devnet-data 7741
```

`serve` binds **only** `127.0.0.1`. There is no remote listener, TLS, API authentication, CORS, or production key storage. Never proxy this dev-only RPC to the public internet. The `/v1/dev/produce-block` endpoint deliberately allows anyone on the local machine to construct a *local* block. The defaults embed PUBLICLY KNOWN devnet test keys; do not send any money or genuine stablecoins to these addresses.

### Read-only RPC

```bash
curl http://127.0.0.1:7741/v1/status
curl http://127.0.0.1:7741/v1/fees
curl http://127.0.0.1:7741/v1/accounts/spider1...
curl http://127.0.0.1:7741/v1/blocks/1
curl http://127.0.0.1:7741/v1/transactions/<64-hex-txid>
```

### Dev-only write RPC

```bash
curl -X POST -H 'Content-Type: application/json' \
  --data-binary @signed-transfer.json \
  http://127.0.0.1:7741/v1/transactions

curl -X POST -H 'Content-Length: 0' \
  http://127.0.0.1:7741/v1/dev/produce-block
```

Signed JSON must contain `payload` with canonical Spider Transfer v1 fields, `public_key` (64 lowercase hex characters), `signature` (128 lowercase hex characters). Sign the canonical binary `Transfer.signing_bytes()` output with Ed25519, **never a JSON string**. `POST /v1/transactions` validates the entire pending queue; a `202` means **pending only**, not settled. `produce-block` must be manually called in this stage. Blocks are **local records, not consensus-finalized**.

`GET /v1/accounts/<address>` returns `nonce`, atomic-unit `balances`, `height`, `chain_id` and explicitly reports `finality: local_only_not_consensus_final`. All numeric balances use unsigned JSON integers, no floating point, and assets are `SPD` (9 decimals) or `tUSD` (6 decimals). `tUSD` is an unbacked test asset and NOT Tether USDT. Fee is `21000 × max_fee_per_gas` SPD atomic units; it is **not** pegged to $1.

## Persistence / failure model

- Genesis is written once in `<dir>/genesis.json` and cannot silently be changed.
- Each validated block is stored in an append-only numbered file in `<dir>/blocks` using a fsynced staging file, rename and directory sync before HTTP acknowledgement.
- Recovery independently replays all blocks and checks previous hashes, signatures, nonces, fees and roots. Corruption or gaps cause startup failure, not silent acceptance.
- A `LOCK` file prevents two node processes from using one state folder. **After a hard crash**, ensure there is no running node before manually removing a stale `LOCK` file.
- A `.staging-*` temporary file left by a crash can be removed only after inspection and backup, while no process is running. Never remove committed block files.
- A mempool is not durable. Pending transactions are lost on restart, must be rechecked and resubmitted by their signer.
- Not yet hardened against disk-full, malicious local users, slowloris attacks, OS power-loss edge cases, large-state scalability or adversarial network traffic.

## Wallet adapter contract

The iOS wallet can **later** implement an RPC adapter to read `GET /v1/status` and `GET /v1/accounts/<address>`. It must reject wrong `chain_id`, must not display demo balances as real funds, and must not show local blocks as finalized payments. This server is loopback-only, so a phone in the outside world cannot connect to a remote machine yet. A secure production endpoint will require BFT and additional RPC hardening.

> **Historical v0.2 scope notice:** The volatile mempool statement above applies to legacy `LocalNode` v0.2. The separate `CertifiedNode`/SpiderBFT Block 3 research ingress uses a bounded persistent signed queue since the 2026-11-04 candidate. Neither should be treated as a production wallet balance or mainnet finality.
