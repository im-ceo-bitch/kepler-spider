# Spider Chain Block 3 — Wallet integration bridge (DEVNET ONLY)

This cumulative patch includes all earlier Block 3 stages 1–6. It is intended
for a checkout with Block 2 already installed and verified. Do **not** install
any earlier Block 3 ZIP first. It does not touch the Block 1 checksum manifest.

## What the new pieces solve

- `src/bft_runtime.rs`: an **opt-in** `wallet_devnet_live: true` config flag
  keeps the private loopback validator running for iOS development rather than
  exiting after a bounded CI target height; ordinary CI/process configs retain
  their previous bounded behavior. This is **not** a publicly reachable node.
- `gateway/spider_wallet_gateway.py`: HTTP listener on 127.0.0.1 only. TLS must
  terminate at a separate reverse proxy. 64 KiB max signed request body, 32
  worker limit, bearer authorization, routes restricted to certified reads and
  already-signed transaction submissions, minute-based request limits.
- An fsync-backed SQLite queue retains signed payloads across gateway restarts
  and retries when the validator returns. It never holds private keys. A
  durable gateway payload is **NOT a finality certificate**. As of the
  2026-11-04 Block 3 increment, the validator also checkpoints its signed
  candidate queue before returning 202; the two stores remain independently
  verified. The gateway no longer silently expires records at 24 hours.
  Expired/stale records require explicit operator reconciliation, never an
  automatic payment-success interpretation. See `docs/BLOCK_03_OPERATIONS_20261104.md`.
- `integration/SpiderDevnetSigner.swift`: native iOS CryptoKit Ed25519 signing,
  canonical length-prefixed transfer bytes, exact Rust-compatible txid, and
  Spider Bech32m addresses. It receives a `CryptoKit` private key from the
  wallet; it does NOT handle seed or mnemonic derivation.
- `integration/SpiderCertifiedWalletClient.swift`: HTTPS authenticated
  transport; checks chain identity and txid, and treats 202 only as queued.
  Finality requires `/v1/transactions/{id}/status` with `finalized:true`.
- `gateway/tests/test_gateway.py` is executed by `cargo test` via an existing
  Rust test target. This verifies the gateway with deterministic mock backends;
  it does not substitute for a real four-validator end-to-end test.

## Preconditions

1. Block 2 installed, `Rust checks` passes on `main`.
2. Install **this single** `spider-update.zip` through the existing ZIP Installer,
   and require a successful Installer **and** subsequent `Rust checks` run.
3. You have a server with Python 3.11+, Caddy 2.10+, and a real DNS hostname with
   HTTPS. A plain public-IP HTTP endpoint is explicitly forbidden.
4. Four validator configurations use the **same** genesis and ValidatorSet and
   distinct signer keys/store paths. No secrets are ever committed to GitHub.
5. The genesis allocates test SPD to the *actual* wallet address you intend to
   use; without genesis funds, the validator must reject spending.

## Run the local four-validator lab

Existing validator private config format requires `genesis`, `validators`,
`key_hex`, `directory`, `listen`, `peers`, `target_height`, `timeout_ms`,
`duration_ms`. For ONE validator on a private server, add:

```json
{
  "tx_listen": "127.0.0.1:28981",
  "wallet_listen": "127.0.0.1:28982",
  "wallet_devnet_live": true
}
```

Merge these into a *complete* existing private-lab config; do not replace it
with the snippet. Keep these two ports unique across the four validators and
make sure `listen` / `peers` remain loopback. Run each validator in a separate
process with its own genesis-identical configuration and private storage:

```sh
cargo run --release --bin spider-validator -- /secure/config/validator-0.json
```

Use another `tx_listen` and `wallet_listen` pair (or omit both) for the other
three. The gateway routes to the first validator's RPC/ingress, and BFT gossip
shares the signed transactions within this local four-node network. The local
private validator does NOT provide encrypted, authenticated Internet P2P.

## Set up the authenticated HTTPS gateway

```sh
# Run locally on the private server, not in a public GitHub repository.
sudo install -d -m 700 -o "$(id -un)" /var/lib/spider-wallet-devnet
python3 -c 'import secrets; print(secrets.token_hex(32))' > /var/lib/spider-wallet-devnet/token
chmod 600 /var/lib/spider-wallet-devnet/token
python3 gateway/spider_wallet_gateway.py \
  --token-file /var/lib/spider-wallet-devnet/token \
  --db /var/lib/spider-wallet-devnet/pending.sqlite3 \
  --listen-port 29080 --read-port 28982 --submit-port 28981
```

Replace `wallet-devnet.example.com` in `gateway/Caddyfile.example` with your
host. Configure HTTPS DNS and Caddy; reverse proxy only to `127.0.0.1:29080`.
Ensure ports 28981, 28982, 29080 and the validator gossip ports are **not**
open to the Internet. Put the Python gateway and Caddy under your service
manager for automatic restart. The gateway token is a per-device DEVNET secret,
provisioned securely to the iPhone Keychain; never hardcode it into the binary,
include it in screenshots or commit it to GitHub. Rotate on exposure.

```sh
curl --fail --silent --show-error \
  -H "Authorization: Bearer $(cat /var/lib/spider-wallet-devnet/token)" \
  https://wallet-devnet.example.com/v1/status
```

Check `network` is `SPIDER_CERTIFIED_DEVNET_RESEARCH`, `chain_id` and
`genesis_hash` match the *actual* run, and `height` advances as BFT blocks
commit. Account reads must show a test SPD balance allocated at genesis.

## Wire the SDK into the iOS Spider Wallet project

Copy the three Swift files (`SpiderDevnetSigner.swift`,
`SpiderCertifiedWalletClient.swift`, `SpiderWalletDevnetBridge.swift`) from `integration/` into the iOS app target, and add
`SpiderDevnetSignerTests.swift` only to an XCTest target. Run the fixture test
on iPhone/iOS Simulator. **Do not** convert Spider Wallet's existing 10-word
mnemonic to an Ed25519 private key by guesswork. Your wallet's key derivation
must be explicitly designed and tested before importing real wallet identity.
You can create a *separate* ephemeral Ed25519 DEVNET key in Keychain for now.

```swift
import CryptoKit

// Get privateKey from Spider Wallet's secure devnet Keychain subsystem.
let myAddress = SpiderDevnetSigner.address(for: privateKey.publicKey.rawRepresentation)
let account = try await client.account(myAddress)
let network = try await client.status()
let transfer = try SpiderDevnetSigner.makeSPDTransfer(
    from: myAddress, to: recipientAddress, amountAtomic: 1_000_000_000,
    nonce: account.nonce, certifiedHeight: network.height)
let signed = try SpiderDevnetSigner.sign(transfer, privateKey: privateKey)
let queued = try await client.submit(signed)
// queued.status == "queued_locally_not_finalized" is NOT a successful transfer.
let confirmation = try await client.waitForCertifiedFinality(queued.id)
if confirmation.finalized {
    // ONLY NOW update the UI to "confirmed test SPD".
}
// On timeout, show "pending / status unknown", never "payment failed".
```

`client` is configured with identical HTTPS `readBaseURL` and `submitBaseURL`,
expected chain ID `spider-devnet-1`, the real genesis hash, and a 64-char
hex bearer token read from Keychain. Do not use `127.0.0.1` as an iPhone URL.
The signer does not verify wallet funds; use balance/fees and report errors
from the validator. All SPD figures are atomic integers (`SPD_DECIMALS = 9`).

## Release gates — honest scope

- `python3 -m unittest discover -s gateway/tests -v`
- `cargo fmt --all -- --check`
- `cargo check --all-targets`
- `cargo test --all-targets` (runs Python gateway tests from Rust)
- `cargo clippy --all-targets`
- iOS XCTest `SpiderDevnetSignerTests` on macOS Xcode (not available here).
- **Manual four-validator end-to-end test:** sign on the iPhone, submit via
  HTTPS, verify signed transaction reaches proposer, validate committed BFT
  evidence, see finalized status and updated receiver/sender balance.
- Replay and restart the wallet gateway and validator. Check no false success.

**Not closed:** geographically distributed encrypted P2P, peer discovery,
reviewed long-term chain liveness, public Testnet, security audit and Mainnet.
This package enables DEVNET integration work, not production transfers or USDT.
