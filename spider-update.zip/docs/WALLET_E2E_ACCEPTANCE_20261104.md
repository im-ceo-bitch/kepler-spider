# Spider Wallet → HTTPS gateway → BFT → Wallet: acceptance protocol

**Current outcome: CODE AND SMOKE TESTS ONLY. Full physical iPhone E2E NOT EXECUTED.** A production app TestFlight build, a real device and four independent, reachable Rust validators are not accessible in this archive.

## Present in source

- `gateway/spider_wallet_gateway.py`: loopback backend behind a separately configured HTTPS reverse proxy. Authenticates bearer token and canonical Ed25519 transfers, persists a SQLite spool at FULL sync and retries it after outages without treating HTTP 202 as finality. It removes a request only when a matching transaction ID is reported finalized in the certified-reader service. Refer to gateway tests for simulated restart/outage/duplicate scenarios.
- `src/block3/tx_ingress.rs`: loopback signed transfer admission into the real bounded BFT reactor, now with durable validator-side queue. A 202 signals **queued, unfinalized**.
- `src/block3/certified_rpc.rs`: serves account state, transaction history and receipts from the journal of independently verified evidence, not from a non-finalized local block simulator. RPC trust in the served journal is not light-client cryptographic verification on the phone.
- `integration/SpiderCertifiedWalletClient.swift`, `integration/SpiderDevnetSigner.swift`, `integration/SpiderWalletDevnetBridge.swift`: **REFERENCE ONLY; not installed in the Spider Wallet app in this ZIP**. Signs locally, requires HTTPS and matching chain/genesis, checks 202/receipt shapes, and reserves a sender's nonce before network send. Stores **only tx IDs** in `UserDefaults` to persist pending state across app restarts; no private key is transmitted. After an HTTP timeout, preserve uncertain submission state until independently resolved. Do not blindly use the same nonce again.

## Live TestFlight acceptance checklist (must be executed)

1. Build Rust with locked dependencies and pass all native 4-validator CI tests first. Launch four **separately operated** private validators using unique signing keys and identical genesis/validator set, with secure peer transport. Keep research RPC bound to localhost; provision four HTTPS gateways with proper CA certificates and separate tokens.
2. Check initial `GET /v1/status` from each endpoint and compare same-height roots. Independently replay each node's authenticated evidence journal with Rust; never accept matching JSON alone as a valid proof.
3. Integrate reference Swift files into the **actual Wallet repository** and run XCTest/real iPhone TestFlight, with token in Keychain and app-specific network configuration. Verify certificate trust, pinned genesis and encrypted device storage for **signing** keys.
4. Send a **test SPD** payment. Confirm no secret material crosses the network; verify signed tx ID matches Rust; 202 must show pending and must never increase the certified balance.
5. Wait for **verified certificate inclusion** on multiple independent nodes. Only after a matching certified transaction ID with block height/hash should the UI show a devnet confirmation. For true independent mobile finality, add BFT QC verification to the wallet, not only HTTPS RPC status.
6. Duplicate-tap and concurrent-send test: one nonce is reserved, no conflicting second transfer is sent. Simulate a lost HTTPS response and restart the app: pending ID must survive, be shown as uncertain, and be reconciled without spending again.
7. Restart the gateway while an accepted test transaction is queued. Verify that SQLite spool replays it without eventual silent loss and is only removed after the matching certified receipt. Kill and restart one validator mid-queue; verify signed queue replay and state consistency.
8. Test 2+2 partition and recovery, unavailable readers, wrong genesis, invalid signatures, client timeouts, old snapshot, power loss and malicious certificate. **Fail closed** if certification cannot be independently proven.
9. Archive signed CI and operator evidence for each pass. No real assets, third-party funds or public mainnet until code audit, legal classification and governing approvals are independently completed.

## Test commands

```bash
python3 -m unittest discover -s gateway/tests -p 'test*.py' -v
python3 -m unittest discover -s ops/tests -p 'test*.py' -v
# Operator-only real HTTPS smoke, after deployment; no private keys in args:
python3 gateway/block3_wallet_smoke.py \
  --url https://YOUR_DEVNET_GATEWAY --token-file /secure/token \
  --chain-id spider-devnet-1 --genesis-hash 64_LOWERCASE_HEX \
  --account spider1YOUR_REAL_DEVNET_ACCOUNT \
  --signed-json /secure/already-signed-test-transfer.json
```

**Do not claim live iPhone E2E solely from gateway unit tests or loopback Rust mocks.**
