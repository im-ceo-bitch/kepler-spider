# SpiderBFT native process CI recovery — 4 November 2026

## Actual upstream failure

The supplied GitHub Actions log `logs_113352285789.zip` shows `cargo check`
and most Rust tests passing. Its legacy installer invoked **`cargo test --all-targets`**
without `--test-threads=1` and launched two resource-intensive, four-process
native network tests at the same time. The release gate timed out one child at
28 seconds while the Rust peer itself allows up to **30 seconds to reach height
2**, followed by an evidence gossip period. The parallel multiheight test also
ended without signed precommit QC, with logs describing packets targeting
unexpected heights/rounds. This log cannot prove whether the latter was solely
resource starvation or a real liveness problem; the tests remain mandatory.

## Candidate corrections

1. The two black-box native gate scripts are now called **sequentially from one
   Rust integration test**. This also works with the older ZIP installer's
   default-parallel test invocation. Neither script is skipped or weakened.
2. Python subprocess deadlines now exceed the actual Rust peer's per-height
   deadline and verified evidence dissemination grace, with bounded margin.
3. The peer gossips independently verified historical finality evidence **in
   ascending height order, before new proposals and votes**, so a lagging peer
   can authenticate and replay height N before accepting height N+1.
4. Successful peers retain their live loopback listener for 5 seconds after
   local certification so they can help slower replicas catch up.
5. Diagnostic errors now report the actual height, round, quorum vote counts,
   round-change certificate count and accepted/rejected messages.

**No change** to >2/3 quorum thresholds, Ed25519 verification, vote guards,
block execution, journal integrity, strict evidence replay or the safety tests.
Failed tests still block installation. No allowance for real funds or mainnet.

## Gates / release decision

Run the cumulative patch through the GitHub ZIP Installer, then require a
successful separate `Spider Chain — research release gates` workflow on the
installed commit. `cargo fmt --check`, `cargo check --locked --all-targets`,
`cargo test --locked --all-targets -- --test-threads=1`, `cargo clippy` and the
Python suites must all pass. Run the native four-peer test several times after
that to detect timing-dependent failures; one green run is not a safety audit.

The local authoring environment lacks `cargo`/`rustc` and cannot download Rust.
Accordingly, this update is **UNVERIFIED RUST** until GitHub reports a green
run. Independent WAN validator deployment remains out of scope for this ZIP.
