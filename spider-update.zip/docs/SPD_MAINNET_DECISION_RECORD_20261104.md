# Spider Chain — proposed SPD economics, genesis, governance and legal sign-off

**No on-chain money launch is approved.** The files in `launch/` are explicitly DRAFT data; they do not mint a token, deploy contracts, initialize mainnet or constitute an official offering.

## Illustrative SPD economic proposal (requires founder approval)

`launch/spd-economics-draft.json`: **illustrative only**, fixed 1,000,000,000 SPD / 9 decimals / 1,000,000,000,000,000,000 atomic units, with a proposed split of 40% ecosystem, 20% validator reward reserve, 20% treasury, 15% team vesting, 5% liquidity. **No staking, slashing, automated vesting, distribution, reward or governance logic exists to enforce these values today.** This allocation is a discussion proposal, not a claim that accounts have been created or tokens minted.

The current `Ledger` stores the asset `SPD` and an accumulating `fee_pool_spd`. Gas for a simple transfer is 21,000 units; minimum price used by the devnet RPC is 1 atomic SPD/gas. Economic feasibility, fee revenue, fee distribution, incentives, inflation or supply caps beyond genesis must be reviewed and encoded before mainnet. Existing `tUSD` is fictitious and does not become real Tether USDT through a name change.

## Genesis and governance

`launch/genesis-draft.json` deliberately contains no recipient addresses or usable timestamp, and is **not** accepted as Rust `Genesis`. For a real genesis, obtain public validator identities and allocation addresses from independent operators, sign a canonical genesis hash, inspect every balance and check total issued supply exactly equals configured initial supply in integer atomic units. Maintain at least two independent reproductions of the genesis hash; never publish private signing keys.

**Governance proposal, NOT implemented:** static initial committee of four independent operators, >2/3 BFT certification, off-chain 3-of-4 signoff on releases, 14-day public upgrade notice, signed emergency exception with postmortem, pre-upgrade state-root snapshot and backward-compatibility dry run. This is an *operational proposal*, not an on-chain voting or slashing mechanism. Do not pretend an off-chain approval proves protocol safety.

`ops/mainnet_policy_gate.py` checks all 14 required evidence records. `--require-complete` returns exit code **2** on the currently unapproved template. Even a zero-exit documentary checklist could not replace cryptographic verification, regulatory review, or a security audit.

## Uzbekistan: preliminary public-regulation references (checked 2026-11-04)

- National Agency for Prospective Projects (NAPP) is the licensing regulator for activities of crypto-asset service providers: https://napp.uz/en/pages/service-providers .
- Regulation No. 3380 (updated in 2026) covers licensing of crypto-exchanges, mining pools, crypto-depositories and crypto-shops, and says licenses for service providers are issued to legal-entity residents: https://www.lex.uz/ru/docs/6158227?ONDATE=01.10.2026+00 .
- Relevant topics in the regulation include licensed activities, handling of records and personal data, anti-money-laundering controls, advertising and server location. Whether Spider Chain code, a **noncustodial wallet**, SPD issuance, custody, USDT exchange, fiat on/offramp or token sales fall under an individual category requires a **qualified Uzbekistan crypto-assets lawyer** and a factual description of the deployed business flows. No license or regulatory endorsement has been obtained by creating this documentation.
- Seek written legal opinions for every target market **before** facilitating money transfers or a token offering. Arrange independent security audit and detailed pen-test scope; the assistant cannot perform an independent third-party audit of its own code.

## Explicit release blockers

1. Unproven BFT round/view-change safety and liveness in adversarial WAN conditions.
2. Missing true authenticated public P2P, staking/rewards/validator membership, upgrade governance and protocol formal verification.
3. Four real independent hosts and a physical-device/Wallet end-to-end run have not been verified.
4. Multisignature key custody/HSM, independent audit, tokenomics approval and legal compliance are incomplete.

**Mainnet status stays locked. Do not run a real-money fundraiser, issue USDT, or market SPD as production-ready on this source.**
