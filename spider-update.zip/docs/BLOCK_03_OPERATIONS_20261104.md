# Spider Chain — Block 3 operational hardening candidate

**Status: DEVNET RESEARCH, not Mainnet.** This change is an incremental hardening package on top of the Nov 4 cumulative repository. It does not replace SpiderBFT with a proven consensus algorithm, deploy remote validators or prove independent security.

## Validator queue and crash consistency

- `CertifiedNode` now owns `certified.pending/pending.json` **outside** the strict `certified/` evidence journal. The queue contains only signed transaction envelopes, **never private keys**. It is bounded to 128 records and 1 MiB; snapshots are written to a new file, `fsync`ed, atomically renamed and the directory is `fsync`ed before returning accepted.
- Snapshots carry chain ID, genesis hash, validator-set hash and last certified height. Startup independently verifies signatures, duplicate IDs, replay state, balance/nonce/expiry and certified history. Transaction IDs actually present in verified committed blocks are dropped on recovery; unrelated pending requests remain queued, if still executable.
- Missing, truncated, foreign, symlinked or inconsistent durable snapshots **fail closed**. On uncertain persistence, the node stops accepting new transactions and cannot propose until restarted. If a new valid block makes another pending transaction invalid, manual reconciliation is needed; never silently delete an unconfirmed request.
- A one-time upgrade from the old volatile queue creates an empty persistent store: transactions lost **before installation** cannot be recovered from the old in-memory pool. Coordinate cutover after draining the gateway spool. A pending transaction is still NOT a confirmed payment, and re-broadcasting is not certificate verification.
- `src/block3/durable_pending_tests.rs`: Rust checks for replay after restart, invalid state, missing journal, foreign set and symlink. These tests require the GitHub Rust runner; Rust was not available in the authoring environment.

## Existing certified catch-up

`certified_sync.rs` imports independently verified BFT proposal/prevote/precommit evidence into `FinalityJournal`, rather than trusting peers' block hashes or node-reported heights. This remains **loopback-only bounded static-peer research**. It is not authenticated Internet P2P, cryptographic peer discovery, or a formal BFT safety proof. Never expose it publicly or replace verified evidence with unsigned JSON state copies.

## Key custody

`spider-validator` supports exactly one signing key source: legacy inline `key_hex` (test-only warning), **or** `key_file` containing exactly 32 bytes in lowercase hex. On Unix the file must be a non-symlink regular file with permissions `0600`; it may not exceed 128 bytes. Do NOT commit it, upload it in ZIPs, include it in backups, or reuse a key on multiple concurrently running validator instances. Use a dedicated secrets manager/HSM and independent operator review before any real money. The current key-file mechanism alone does not provide HSM, remote attestation, rotation, nor multisignature custody.

## Offline backup and restore

**Stop the validator process first**; do not take an inconsistent live filesystem copy:

```bash
python3 ops/validator_backup.py create \
  --state-dir /private/validator-0 --output /private/backups/v0-state.zip \
  --confirm-stopped
python3 ops/validator_backup.py verify --archive /private/backups/v0-state.zip
python3 ops/validator_backup.py restore \
  --archive /private/backups/v0-state.zip --state-dir /private/validator-0-restored
```

The tool acquires the signer/certified owner locks, refuses symlinks, unexpected potentially secret files and reused restore destinations, and checks SHA-256 for every stored record. It **never includes signing keys**. **Important:** a valid ZIP hash proves only transport/integrity of this backup, not the authenticity of validator blocks, snapshot recency, vote safety, or absence of rollbacks. Do not start a restored signing validator without re-verifying every BFT certificate with Rust, comparing the highest signed vote/lock against the operator's current network and checking that this backup is NOT older than already-issued signatures. A stale signer WAL can lead to equivocation: require independent operator incident approval.

## Read-only monitoring

Use one trusted TLS endpoint and **a different token file per endpoint**. This is a health report, not a crypto proof:

```bash
python3 ops/devnet_probe.py \
  --origin https://validator0.example.org --token-file /secure/validator0-token \
  --origin https://validator1.example.org --token-file /secure/validator1-token \
  --chain-id spider-devnet-1 --genesis-hash ACTUAL_64_HEX_GENESIS_HASH \
  --max-lag 2 --state-file /private/monitoring/progress.json --stale-seconds 600
```

Do not copy the sample hostname or placeholder hash literally. The probe checks pinned network/genesis identity, strict devnet flags, numeric height, 64-character state roots, lag, and disagreement **only at the same height**. With `--state-file`, a certified height that stays unchanged for 600 seconds (or any configured threshold >= 60) triggers a nonzero alert across repeated polls. Exit nonzero is an alert trigger for an external scheduler/monitor. It does NOT authenticate remote BFT certificates; feed journal evidence to the Rust verifier to reach an independent conclusion. Logs from `spider-validator` also include a bounded `pending` queue depth, accept/reject counts and transport failures. Never log bearer tokens or private signing keys.

## Network safety and remaining work

- Transaction ingress remains loopback-only, 64 KiB body cap, 250 ms socket deadlines, two accepts per reactor turn.
- Incoming consensus batches are bounded at 64 messages. Existing relay/gateway apply framed message caps, rate limits, mTLS, separate evidence verification and replay protections, but public peer identity, anti-DoS and transport binding remain incomplete.
- Verify four independent **actual servers**, power-failure replay, partitions, clashing proposals, disk-full behavior, snapshot restore, peer allowlists and operations alerting before Testnet acceptance. Never open the Rust P2P listen address to the Internet as a shortcut.
