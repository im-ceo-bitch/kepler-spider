# Spider Chain v0.5.2 — cumulative research release gate (2026-11-04)

**Decision: NO PUBLIC MAINNET. The changes below are a stricter, fail-closed
Devnet research acceptance candidate; not a security certification.**

## Included in this cumulative source update

1. **Block 1 manifest repair.** The unchanged `tools/block1_release_gate.py`
   file was inspected: its current source digest is
   `665f7b4ad2f6512f5bf0dd250c0ba76d5c03963dbfc707d26684d52485eb27de`.
   The prior manifest recorded `f1e052c...`, blocking the entire Rust suite.
   Only the expected digest for this one already-existing script was updated
   in `docs/BLOCK_01_SHA256.txt`; all other frozen entries are unchanged.
   Manifest verification is not a signed attestation. Any future edits to a
   frozen file still require explicit review and a new documented baseline.
2. **Block 3 wallet replay fairness.** Incorporated the contained
   `spider-update.zip` change: bounded, wrapping 16-entry retry cursor,
   preserving still-unfinalized requests across outages, and four replay
   regressions. It does not claim trusted on-chain finality; the existing
   gateway trusts its configured loopback reader and remains devnet only.
3. **Formalized local safety acceptance.** The existing Rust signing journal,
   certificate verification, phase-2 vote tests and Byzantine bounded models
   remain active. Added a separate native-process failure gate, using actual
   Rust node binaries when run by Cargo or GitHub, for a 2+2 offline split,
   reconnect with preserved WALs, same hash/state root, and deliberately
   corrupted finality journal fail-closed checks.
4. **Four-independent-journal comparison.** New offline script
   `research/verify_four_states.py` verifies all four copied journals report
   exactly the same `(height, block_hash, state_root, previous_hash)`.
   It does NOT authenticate the proofs; the Rust FinalityJournal must do so.
5. **CI and permanent ZIP installer.** Both GitHub workflows, when installed,
   now check Python regression suites and bounded adversarial models in
   addition to pinned-dependency Rust format/check/tests/Clippy. Installer
   verifies the isolated staged candidate **before** touching `main`.

## Protocol safety contract and test evidence (research scope)

| Property | Intended requirement | Gate / current limitation |
|---|---|---|
| Identity | bind chain, genesis, validator set, height, round, step, target, signer | Rust phase-2 and signature tests; no untrusted WAN exposure |
| Single signing intent | persist one canonical ballot per height/round/step before broadcasting | `bft_safe_signer` and restart tests |
| Lock/unlock | never unlock a block on timeout alone; require authenticated newer-round prevote QC | phase-2 locking tests; arbitrary competing proposer values remain unimplemented in native peer |
| Round change | signed >2/3 timeout certificate must advance round monotonically | multiheight, offline leader and WAL round-change tests |
| Quorum | weighted >2/3, with faulty power strictly <1/3 | exhaustive bounded model, not a concrete protocol proof |
| Finalize | identical fully verified proposal/prevote/precommit evidence, durable append before reporting | `FinalityJournal`, process smoke test; proof incomplete under Byzantine WAN scheduling |
| Safety after split | 2/2 must not certify; 4/4 after heal should converge, with original WALs | **new native-process gate**, must pass on GitHub before release acceptance |
| Corruption | damaged persisted evidence must halt instead of silently rebuilding | **new native-process corruption scenario** |
| Four state roots | all independent processes/journals agree for each finalized height | native-process gate + offline four-journal comparator |

### Verification commands

Run at the root of the cumulative repo on Linux with **Rust stable, Python 3.12 and OpenSSL**:

```bash
python3 -m pip install -r gateway/requirements-ci.txt
python3 tools/block1_release_gate.py
python3 tools/bft_quorum_model.py
python3 tools/bft_phase2_model_v052.py
python3 tools/bft_reactor_model.py
python3 -m unittest discover -s gateway/tests -p 'test*.py' -v
python3 -m unittest discover -s research/tests -p 'test*.py' -v
cargo fmt --all -- --check
cargo check --locked --all-targets
RUST_TEST_THREADS=1 cargo test --locked --all-targets -- --test-threads=1
cargo clippy --locked --all-targets
cargo run --locked --bin spider-node -- demo
```

Native four-process gate independently (after `cargo build --locked --bin spider-bft-phase2-peer`):

```bash
python3 research/four_validator_release_gate.py target/debug/spider-bft-phase2-peer
```

Tested directly in the authoring environment: Block 1 checksum manifest,
15 Python gateway/mTLS/fairness tests, 4 Python oracle tests, bounded safety
models, Python syntax and YAML parse. **Cargo, Rust formatting, native four
processes and GitHub CI were NOT run there: no Rust compiler was available and
network download was unavailable.** These are mandatory release gates on the
first GitHub run, not claims of success.

### Checking journal exports from four hosts

Use a dedicated private verification machine. Securely transfer each of four
independently *Rust-validated* on-disk `validator-i` journal folders into
`/private/audit/validator-i`, retaining `certified/*.json`. For height 10:

```bash
python3 research/verify_four_states.py --height 10 \
  --journal /private/audit/validator-0 \
  --journal /private/audit/validator-1 \
  --journal /private/audit/validator-2 \
  --journal /private/audit/validator-3
```

Do not upload secret keys, TLS private keys, or user funds. Compare exact node
software hashes and genesis/validator-set ID separately. Merely finding matching
JSON files is NOT evidence that the network independently finalized a block.

## Why four remote validators have NOT been deployed

There are no four server endpoints or operator credentials in this archive.
More importantly, `spider-bft-phase2-peer` is a **loopback-only fixed-candidate
laboratory binary** with intentionally public keys and fixed genesis. Placing
this binary directly on four public servers would create a falsely secured
network. The existing mTLS relay can secure static TCP links, but does not
replace per-node secret signing identities, peer discovery/management,
Byzantine fork handling, resource protections or resilient cross-host gossip.
Four actual independent operators must be a *subsequent, isolated testnet*
after those requirements are implemented and reviewed. The code in this
update intentionally does not relax the localhost or Devnet-only boundaries.

## Mandatory blockers before any release with money

- Implement and model-check competing block proposals, explicit valid-round
  transfer, arbitrary delayed Byzantine messages and cross-round lock safety.
- Persist validator-side mempool and canonical state snapshots; add metrics,
  safe genesis/key rotation, resource limits, monitoring, backup/restore, and
  operator procedures.
- Run four genuine independent hosts with secret unique signing keys and mTLS;
  log continuous heights, 2+2 partition heal, restart after every WAL phase,
  state-root agreement, and adversarial tests. Obtain independent code audit.
- Verify real Wallet → gateway → validators → immutable certified receipt
  with pinned chain/genesis and independent certificate verification. No real
  SPD or USDT in this repository.

## Delivery warning for ZIP Installer

`.github/workflows/spider-upgrade.yml` explicitly forbids `.github/` paths in
`spider-update.zip`, because `GITHUB_TOKEN` may not update workflow files. To
activate BOTH updated workflows, use the full cumulative repo ZIP and commit
its workflow files through a credentialed Git push, or update the two YAML
files manually in GitHub *before* running the smaller installer patch.
Uploading only the patch installs Rust tests and the replay repair but does
not automatically install the updated workflow definitions.

An unexpected Rust failure or failure of the 2+2 recovery test must be treated
as a **real blocker**, not removed/ignored to force a passing mainnet label.
