# Spider Chain Block 3 — wallet ingress + concurrent certified services (CI candidate)

**Scope:** One incremental patch that **also includes Stage 1/2/3** for users who have not yet installed the previous Block 3 ZIP. Does not modify protected Block 1 artifacts or add dependencies.

## Changes

1. `src/block3/tx_ingress.rs` — optional loopback-only HTTP `POST /v1/transactions` ingress **into the actual SpiderBFT Reactor**, calling `Reactor::submit` (signature, chain, nonce, expiry, fees, balances and queue validation). Exactly `202 queued_locally_not_finalized` on acceptance; no commitment, broadcast, durable mempool or real funds are claimed. Bounded body (64 KiB), bounded headers, duplicate-length and oversized-request rejection, no chunked/pipelined requests, short deadlines, and a maximum of two accepts per consensus event-loop iteration.
2. `src/bft_runtime.rs` — optional `tx_listen` config, accepted only if loopback, not equal to consensus listener or listed peers; default is disabled for complete backward compatibility. This is **only** the private Block 2 test-reactor runner, not a public wallet gateway.
3. `src/block3/certified_sync.rs` — concurrent verified-evidence readers (max 16 active), so one slow inbound client does not stall legitimate certified catch-up. Every evidence record is still validated by `FinalityJournal` before durable import. Tests added.
4. `src/block3/certified_rpc.rs` — concurrent loopback-only read RPC (max 16 active), plus paginated, *certified-only* wallet transaction history. Pagination uses 20 complete blocks per page and a height cursor, never an unstable transaction offset. Tests added.

## Local lab configuration

Add to a private validator config JSON (all previous settings remain intact):

```json
"tx_listen": "127.0.0.1:8989"
```

The value is an optional field; no HTTP service is opened if omitted. Only a fully signed Spider transfer is accepted (no seed phrases or private keys ever belong in the RPC request):

```bash
curl -i http://127.0.0.1:8989/v1/transactions \
  -H 'Content-Type: application/json' \
  --data-binary @signed-transfer.json
```

The `202` reply means **temporary local candidate queue only**. Until transactions are propagated to the active proposer and finalized, no wallet may mark them as confirmed. A restart can discard the pending queue. Do not expose this plaintext port to the Internet or use it for real funds.

Read-only wallet history on the certified daemon:

```text
GET /v1/accounts/{valid-spider-address}/transactions
GET /v1/accounts/{valid-spider-address}/transactions/{before_height}
```

`next_before_height` is `null` when no older certified blocks remain. All returned transfers are from independently verified certified blocks, never from the unfinalized queue.

## CI verification (REQUIRED)

```bash
python3 tools/block1_release_gate.py
cargo fmt --all -- --check
cargo check --all-targets
cargo test --all-targets
cargo clippy --all-targets
cargo test --lib tx_ingress -- --nocapture
cargo test --lib certified_sync -- --nocapture
cargo test --lib certified_rpc -- --nocapture
```

## Remaining Block 3 gates

- Public cross-host **encrypted, mutually authenticated** P2P; peer key pinning, replay defense, peer discovery and persistent peer scoring are NOT implemented. All services here are still loopback-only.
- Transaction propagation to the current BFT proposer, durable mempool, full integration of evidence-sync with the live validator runtime, and reliable post-finality receipts are NOT implemented.
- Multi-host fault/DoS/reconnect tests and iOS-to-HTTPS-gateway end-to-end tests are NOT executed.
- Rust build and full native test outcomes can only be confirmed once CI runs. No Mainnet/SPD monetary/USDT readiness claim is made.


> **Later Block 3 update (2026-11-04):** The old volatile-queue statement above describes the original stage. `CertifiedNode` now persists validator signed transfers in `certified.pending` before 202. The queue is still **unfinalized** and can require operator reconciliation after conflicting certified commits. See `docs/BLOCK_03_OPERATIONS_20261104.md`.
