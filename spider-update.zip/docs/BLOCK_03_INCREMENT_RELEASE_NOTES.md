# Cumulative Spider Chain Block 3 candidate — 2026-11-04

**Base:** the most recently supplied `spider-full.zip` repository (v0.5.2). This is a cumulative source patch, NOT a new blockchain. Existing zip upgrade installer and research gates are retained. Public mainnet remains prohibited.

## Changes in this increment

1. `src/block3/durable_pending.rs` + embedded regression tests: signed validator mempool snapshot before 202; 128-tx / 1 MiB bound; atomic fsync+rename checkpoint; binding to chain/genesis/validator set; restart revalidation, certified-ID reconciliation and fail-closed corrupt/missing-state handling.
2. `src/finality_gate.rs`, `src/bft_reactor.rs`: integrate the queue with the only certificate-appending ledger boundary. Poison reactor on ambiguous durable persistence and prevent later proposals. Invalid/malformed evidence remains rejected without poisoning a healthy node; certificate-journal I/O failure is treated as uncertain durability.
3. `src/bft_runtime.rs`: opt-in private `key_file` with Unix mode 600 + no symlinks; bounded consensus batch length; pending queue count in existing diagnostic telemetry. `key_hex` remains for the original deterministic devnet research tests only.
4. `gateway/spider_wallet_gateway.py`: serializes POST admission bookkeeping; a retried signed POST rejected with 422 does not destroy an earlier durable queued copy. No time-based deletion or early finalization.
5. `gateway/block3_wallet_smoke.py`: acceptance requires `durable_mempool: true`, checks chain/genesis/state-root shape and strict certified receipt fields; does not claim client-side QC verification.
6. `integration/SpiderCertifiedWalletClient.swift`, `integration/SpiderWalletDevnetBridge.swift`: stricter HTTPS/202/receipt validation; persist pending transaction ID **before** network submission so an ambiguous response cannot trigger an automatic second send. Reference only, not wired into the actual wallet app.
7. `ops/`: offline backup/restore integrity verification, read-only multi-endpoint HTTPS health/height/root/staleness probe, and a deliberately unapproved 14-item mainnet release checklist. Tests include corrupted archives, symlinks, missing decisions, fork/lag/stale checkpoints.
8. `launch/`: illustrative, unapproved SPD allocations; deliberately non-executable genesis draft; no private keys and no real token minting.
9. CI `rust-ci.yml` and `spider-upgrade.yml` (provided **separately** from patch because installer refuses `.github` changes): add ops tests and parse the mainnet checklist. The `--require-complete` gate must continue to fail until real approvals and independent evidence exist.

## Actual local tests

- Block 1 fixed baseline SHA256: 51/51.
- Gateway unit tests: 18/18.
- Research test suite: 6/6.
- Operations tests: 7/7.
- Finite quorum, phase-2 and reactor model tests: passed (not a protocol proof).
- Swift changed source: `swiftc -frontend -parse` passed; **NOT an iOS build**.
- Python module compilation and both workflow YAML parsers: passed.
- Rust `cargo fmt`, `cargo check`, `cargo test` and `cargo clippy`: **NOT RUN locally** (no toolchain); GitHub installer MUST perform these before installation. The inserted Rust tests and system behavior are therefore an unverified candidate, not a passed release.
- Four separate *real* validator servers, physical iPhone, token launch, 3rd-party security audit and legal clearance: **NOT PERFORMED**.

## Operator deployment

1. Back up/stabilize existing `main`. Upload the cumulative `spider-update.zip` into the repository root only after old ZIPs are removed or replaced.
2. The existing ZIP Installer stages the patch in a disposable tree, automatically runs Rustfmt, Cargo, Python and models, and only then commits if all gates pass. Stop immediately on any failure: do not change tests to make the build green.
3. Install the companion new workflow YAML files through a separate GitHub file update, or install the complete repository source from `spider-full.zip` with appropriately formatted Rust sources; do **not** put `.github/` paths inside the patch.
4. Only after passing GitHub Rust gates, test on an offline four-process devnet and then an independently operated private testnet. Never fund the current source with real tokens.

**Release decision: BLOCK 3 ENGINEERING CANDIDATE ONLY. NOT MAINNET READY.**
