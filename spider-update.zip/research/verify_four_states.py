#!/usr/bin/env python3
"""Compare certified block hashes and state roots from four *separate* journals.

Offline comparison only. Each Rust FinalityJournal must independently verify its
own signed certificate on replay; JSON comparison does NOT authenticate proofs.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def certified_identity(journal: Path, height: int) -> tuple[int, str, str, str]:
    if not 1 <= height <= 2**64 - 1:
        raise ValueError("invalid height")
    file = journal / "certified" / f"{height:020}.json"
    if file.is_symlink() or not file.is_file():
        raise ValueError(f"missing/unsafe certified evidence: {file}")
    if file.stat().st_size > 2 * 1024 * 1024:
        raise ValueError(f"oversized evidence: {file}")
    block = json.loads(file.read_text(encoding="utf8"))["proposal"]["block"]
    fields = (block["height"], block["hash"], block["state_root"], block["prev_hash"])
    if type(fields[0]) is not int or fields[0] != height:
        raise ValueError(f"wrong evidence height: {file}")
    if any(not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value)
           for value in fields[1:]):
        raise ValueError(f"invalid certificate block digests: {file}")
    return fields


def verify(journals: list[Path], height: int) -> tuple[int, str, str, str]:
    if len(journals) != 4 or len({str(j.resolve()) for j in journals}) != 4:
        raise ValueError("four distinct local journal paths are required")
    identities = [certified_identity(journal, height) for journal in journals]
    if len(set(identities)) != 1:
        raise ValueError(f"DIVERGENT certified blocks at height {height}: {identities}")
    return identities[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--height", required=True, type=int)
    parser.add_argument("--journal", required=True, action="append", type=Path)
    args = parser.parse_args()
    try:
        h, block_hash, state_root, _ = verify(args.journal, args.height)
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        parser.exit(1, f"FAIL: {exc}\n")
    print(f"PASS four independent journal copies height={h} block={block_hash} root={state_root}")
    print("SCOPE comparison only; Rust certificate validation and independent server identities required")


if __name__ == "__main__":
    main()
