#!/usr/bin/env python3
"""Black-box multiheight native Rust test; bounded localhost research fixture.

Proves only authenticated evidence propagation, separate processes and replay;
does NOT establish Byzantine safety, secure P2P or arbitrary-fork liveness.
"""
from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile


def base_port():
    for _ in range(128):
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0))
            base = s.getsockname()[1]
        if base >= 65000 or base < 1024:
            continue
        held = []
        try:
            for n in range(4):
                s = socket.socket()
                s.bind(('127.0.0.1', base + n))
                held.append(s)
            return base
        except OSError:
            pass
        finally:
            for s in held:
                s.close()
    raise RuntimeError('unable to reserve four test ports')


def peer_process_timeout(height: int) -> int:
    # Match the native gate's 15s per height + 5s post-commit gossip +
    # 9s margin for GitHub runner scheduling.
    if not 1 <= height <= 16:
        raise ValueError('invalid research height')
    return 15 * height + 14


def exercise(binary: Path, root: Path, members, height: int, should_succeed: bool,
             expect_round_change: bool = False):
    port = base_port()
    procs = [subprocess.Popen([str(binary), str(i), str(port), str(root), str(height)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for i in members]
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(procs)) as executor:
            futures = [executor.submit(p.communicate, timeout=peer_process_timeout(height)) for p in procs]
            output = []
            for idx, proc, future in zip(members, procs, futures):
                try:
                    output.append(future.result())
                except subprocess.TimeoutExpired as exc:
                    raise AssertionError(
                        f'validator={idx} exceeded process timeout at height={height}; '
                        f'exit_codes={[p.poll() for p in procs]}; '
                        f'stderr_tail={str(exc.stderr)[-600:]}'
                    ) from exc
        fingerprints = set()
        for idx, process, (stdout, stderr) in zip(members, procs, output):
            succeeded = process.returncode == 0 and 'CERTIFIED_LEDGER_COMMIT' in stdout
            if succeeded != should_succeed:
                raise AssertionError(f'{idx} rc={process.returncode} expected success={should_succeed}: '
                                     f'{stdout[-1400:]} / {stderr[-1400:]}')
            certified = root / f'validator-{idx}' / 'certified'
            proofs = [certified / f'{h:020}.json' for h in range(1, height + 1)]
            if should_succeed:
                assert all(p.is_file() for p in proofs), f'missing certificates for {idx}'
                signatures = []
                for p in proofs:
                    evidence = json.loads(p.read_text())
                    block = evidence['proposal']['block']
                    signatures.append((block['height'], block['hash'], block['state_root']))
                fingerprints.add(tuple(signatures))
                if expect_round_change:
                    evidence = json.loads(proofs[0].read_text())
                    assert evidence['proposal']['round'] >= 1, 'offline round-zero leader must require view change'
                    assert (root / f'validator-{idx}' / 'timeouts' /
                            'timeout-00000000000000000001-0000000.bin').is_file(), \
                           'no locally signed round-zero timeout journal'
            else:
                assert not any(p.is_file() for p in proofs), f'insufficient quorum committed {idx}'
        if should_succeed:
            assert len(fingerprints) == 1, f'validator histories diverge: {fingerprints}'
    finally:
        for p in procs:
            if p.poll() is None:
                p.kill()
        for p in procs:
            p.wait(timeout=5)


def main():
    binary = Path(sys.argv[1]).resolve(strict=True)
    with tempfile.TemporaryDirectory(prefix='spider-multih-rust-') as tmp:
        root = Path(tmp)
        exercise(binary, root, (0, 1, 2, 3), 3, True)
        # Reopened journals must replay all evidence before reaching height 4.
        exercise(binary, root, (0, 1, 2, 3), 4, True)
    with tempfile.TemporaryDirectory(prefix='spider-no-quorum-') as tmp:
        exercise(binary, Path(tmp), (0, 1), 1, False)
    # Sorted fixture Ed25519 pubkeys give round-zero proposer index 3;
    # round-one proposer index 2. This explicitly verifies signed view change.
    with tempfile.TemporaryDirectory(prefix='spider-failed-leader-') as tmp:
        exercise(binary, Path(tmp), (0, 1, 2), 1, True, expect_round_change=True)
    print('PASS native 4-process 3+1 heights, crash replay, no quorum, offline leader view-change')
    print('SCOPE localhost fixed-candidate research (round 0 and 1): production consensus NOT proven')


if __name__ == '__main__':
    main()
