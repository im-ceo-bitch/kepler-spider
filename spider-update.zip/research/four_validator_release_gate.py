#!/usr/bin/env python3
"""FAIL-CLOSED bounded four-process SpiderBFT regression gate.

Four independent LOCALHOST Rust processes with separate WAL / evidence dirs.
The fault injection below does NOT model a genuine WAN, changing membership,
malicious peer networking, or arbitrary competing proposer values.

Run: python3 research/four_validator_release_gate.py target/debug/spider-bft-phase2-peer
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import socket
import subprocess
import tempfile
import time


def unused_ports() -> int:
    # Best effort test port allocation, not a production allocator.
    for _ in range(128):
        with socket.socket() as candidate:
            candidate.bind(("127.0.0.1", 0))
            base = candidate.getsockname()[1]
        if not 1000 < base < 65000:
            continue
        held = []
        try:
            for index in range(4):
                sock = socket.socket()
                sock.bind(("127.0.0.1", base + index))
                held.append(sock)
            return base
        except OSError:
            continue
        finally:
            for sock in held:
                sock.close()
    raise RuntimeError("no free group of four loopback test ports")


def evidence_path(root: Path, index: int, height: int) -> Path:
    return root / f"validator-{index}" / "certified" / f"{height:020}.json"


def histories(root: Path, indices: tuple[int, ...], height: int) -> tuple:
    snapshots = []
    for index in indices:
        chain = []
        for h in range(1, height + 1):
            path = evidence_path(root, index, h)
            if not path.is_file():
                raise AssertionError(f"validator {index} missing durable evidence at {h}")
            payload = json.loads(path.read_text(encoding="utf-8"))
            block = payload["proposal"]["block"]
            if block["height"] != h:
                raise AssertionError(f"validator {index} unexpected height {block['height']}")
            if h > 1 and block["prev_hash"] != chain[-1][1]:
                raise AssertionError(f"validator {index} broken parent linkage at {h}")
            chain.append((h, block["hash"], block["state_root"]))
        snapshots.append(tuple(chain))
    if len(set(snapshots)) != 1:
        raise AssertionError(f"validator histories diverged: {snapshots}")
    return snapshots[0]


def peer_process_timeout(height: int) -> int:
    # 15s/height is the Rust consensus research deadline, then 5s signed
    # evidence gossip; allow 9s scheduling margin for overloaded CI runners.
    if not 1 <= height <= 16:
        raise ValueError('invalid research height')
    return 15 * height + 14


def run_members(binary: Path, root: Path, indices: tuple[int, ...],
                height: int, expected_commit: bool, timeout: int | None = None) -> None:
    # A shorter Python timeout would be an invalid test of Rust liveness.
    minimum_timeout = peer_process_timeout(height)
    if timeout is None:
        timeout = minimum_timeout
    elif timeout < minimum_timeout:
        raise ValueError('test harness timeout must exceed the peer deadline')
    port = unused_ports()
    processes = [(index, subprocess.Popen(
        [str(binary), str(index), str(port), str(root), str(height)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )) for index in indices]
    try:
        with ThreadPoolExecutor(max_workers=len(processes)) as pool:
            futures = [(index, proc, pool.submit(proc.communicate, timeout=timeout))
                       for index, proc in processes]
            results = []
            for index, proc, future in futures:
                try:
                    output = future.result()
                except subprocess.TimeoutExpired as exc:
                    statuses = ', '.join(
                        f'v{i}:rc={p.poll()}' for i, p in processes
                    )
                    raise AssertionError(
                        f'validator {index} timed out after {timeout}s at target height={height}; '
                        f'processes: {statuses}; stderr_tail={str(exc.stderr)[-500:]}'
                    ) from exc
                results.append((index, proc, output))
        for index, proc, (out, err) in results:
            committed = proc.returncode == 0 and "CERTIFIED_LEDGER_COMMIT" in out
            if committed != expected_commit:
                raise AssertionError(
                    f"validator {index} expected commit={expected_commit}, observed={committed}, "
                    f"exit={proc.returncode}\nstdout={out[-1800:]}\nstderr={err[-1800:]}"
                )
            if expected_commit and not evidence_path(root, index, height).is_file():
                raise AssertionError(f"validator {index} committed without durable evidence")
            if not expected_commit and evidence_path(root, index, 1).exists():
                raise AssertionError(f"validator {index} finalized with fewer than 3 of 4")
        if expected_commit:
            histories(root, indices, height)
    finally:
        for _, proc in processes:
            if proc.poll() is None:
                proc.kill()
        for _, proc in processes:
            try:
                proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()


def exercise(binary: Path, output: Path) -> None:
    all_peers = (0, 1, 2, 3)
    clean = output / "full"
    clean.mkdir()
    run_members(binary, clean, all_peers, 2, True)
    run_members(binary, clean, all_peers, 3, True)  # Reopen all four WALs.
    triple = output / "leader-offline"
    triple.mkdir()
    # The research fixture nominates index 3 as initial proposer.
    run_members(binary, triple, (0, 1, 2), 1, True)

    partition = output / "two-plus-two"
    partition.mkdir()
    # Each pair is run in isolation (different network port groups). Both
    # MUST fail without signing a finality certificate. Their WALs are kept.
    run_members(binary, partition, (0, 1), 1, False)
    run_members(binary, partition, (2, 3), 1, False)
    # Rejoin all four WITHOUT resetting WAL state, force round change/replay.
    run_members(binary, partition, all_peers, 1, True)
    histories(partition, all_peers, 1)

    # Deliberate crash/corruption boundary: a damaged certified journal must
    # fail on restart, not silently accept a different finalized block.
    corrupt = evidence_path(clean, 0, 2)
    corrupt.write_bytes(b"{\"damaged\":true}")
    started = time.monotonic()
    result = subprocess.run(
        [str(binary), "0", str(unused_ports()), str(clean), "3"],
        text=True, capture_output=True, timeout=8, check=False,
    )
    if result.returncode == 0 or "CERTIFIED_LEDGER_COMMIT" in result.stdout:
        raise AssertionError("corrupt certified evidence was accepted on restart")
    if time.monotonic() - started > 7:
        raise AssertionError("corrupt evidence did not fail closed before network timeout")
    print("PASS 4 local Rust processes: height agreement, 3+1 crash replay, leader loss")
    print("PASS 2+2 isolation blocks finality; reconnect replays WAL and certifies")
    print("PASS tampered on-disk certificate prevents restart")
    print("SCOPE localhost fixed-candidate lab with TEST KEYS; not 4 independent servers or BFT proof")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    args = parser.parse_args()
    binary = args.binary.resolve(strict=True)
    if not binary.is_file():
        parser.error("binary is not a regular file")
    with tempfile.TemporaryDirectory(prefix="spider-4-validator-gate-") as temp:
        exercise(binary, Path(temp))


if __name__ == "__main__":
    main()
