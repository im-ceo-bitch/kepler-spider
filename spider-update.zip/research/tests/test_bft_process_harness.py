"""Regression tests for the fail-closed four-process CI harness.

These tests do not execute the Rust network and do not prove BFT safety.
"""
import importlib.util
from pathlib import Path
import unittest

RESEARCH = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, RESEARCH / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class HarnessDeadlineTests(unittest.TestCase):
    def test_python_must_wait_longer_than_native_research_deadline(self):
        for script in ("four_validator_release_gate", "phase2_multiheight_process_test"):
            mod = load(script)
            for height in (1, 2, 3, 4, 16):
                self.assertGreaterEqual(mod.peer_process_timeout(height), 15 * height + 5)
                self.assertEqual(mod.peer_process_timeout(height), 15 * height + 14)
            for bad in (0, -1, 17):
                with self.assertRaises(ValueError):
                    mod.peer_process_timeout(bad)

    def test_two_large_process_gates_cannot_start_as_parallel_rust_tests(self):
        source = (RESEARCH.parent / "tests/bft_native_multiheight_process.rs").read_text()
        self.assertEqual(source.count("#[test]"), 1)
        self.assertIn('"research/phase2_multiheight_process_test.py"', source)
        self.assertIn('"research/four_validator_release_gate.py"', source)
        self.assertIn('for (script, description)', source)


if __name__ == "__main__":
    unittest.main()
