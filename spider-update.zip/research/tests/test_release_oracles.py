"""Python-only tests for the verification oracles, not for Rust consensus."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


compare = load("verify_four_states")
lab = load("four_validator_release_gate")


class FourValidatorEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.journals = [self.root / f"validator-{i}" for i in range(4)]
        for j in self.journals:
            (j / "certified").mkdir(parents=True)
        self.write(1, "a" * 64, "b" * 64, "c" * 64)
        self.write(2, "d" * 64, "b" * 64, "a" * 64)

    def write(self, height, block_hash, state_root, prev, index=None):
        indices = range(4) if index is None else [index]
        for i in indices:
            file = self.journals[i] / "certified" / f"{height:020}.json"
            file.write_text(json.dumps({"proposal": {"block": {
                "height": height, "hash": block_hash,
                "state_root": state_root, "prev_hash": prev,
            }}}))

    def test_exact_four_way_agreement(self):
        self.assertEqual(compare.verify(self.journals, 2)[1], "d" * 64)
        self.assertEqual(len(lab.histories(self.root, (0, 1, 2, 3), 2)), 2)

    def test_mismatched_state_root_fails(self):
        self.write(2, "d" * 64, "f" * 64, "a" * 64, index=3)
        with self.assertRaisesRegex(ValueError, "DIVERGENT"):
            compare.verify(self.journals, 2)
        with self.assertRaisesRegex(AssertionError, "diverged"):
            lab.histories(self.root, (0, 1, 2, 3), 2)

    def test_parent_link_break_fails(self):
        self.write(2, "d" * 64, "b" * 64, "e" * 64)
        with self.assertRaisesRegex(AssertionError, "parent linkage"):
            lab.histories(self.root, (0, 1, 2, 3), 2)

    def test_missing_unsafe_and_duplicate_journals_fail(self):
        with self.assertRaises(ValueError):
            compare.verify(self.journals[:3] + self.journals[:1], 1)
        (self.journals[0] / "certified" / f"{1:020}.json").unlink()
        with self.assertRaises(ValueError):
            compare.verify(self.journals, 1)


if __name__ == "__main__":
    unittest.main()
