#!/usr/bin/env python3
"""Devnet-only Spider Wallet HTTPS-reverse-proxy backend.

Listens on 127.0.0.1 only; require TLS termination (Caddy) on the public side.
Rejects unauthenticated requests, validates route/method/body, and retries signed
transaction payloads after outages. A 202 NEVER means BFT finality.
No private keys or seeds are received or stored.
"""
from __future__ import annotations
import argparse
from collections import deque
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import http.client
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import struct
import threading
import time
from urllib.parse import urlsplit
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

MAX_BODY = 64 * 1024
MAX_ROWS = 256
TX_ID = re.compile(r"^[a-f0-9]{64}$")
ADDR = re.compile(r"^spider1[023456789acdefghjklmnpqrstuvwxyz]{20,90}$")
ACCOUNT = re.compile(r"^/v1/accounts/(spider1[023456789acdefghjklmnpqrstuvwxyz]{20,90})(/transactions(/[1-9][0-9]*)?)?$")
TX_STATUS = re.compile(r"^/v1/transactions/([a-f0-9]{64})/status$")
BLOCK = re.compile(r"^/v1/blocks/([1-9][0-9]*)$")
READ_PATHS = frozenset(("/v1/status", "/v1/assets", "/v1/fees"))
FIELDS = ("chain_id", "sender", "recipient", "asset_id", "amount", "nonce", "gas_limit", "max_fee_per_gas", "expiry_height")
UINT64_MAX = 2**64 - 1
BECH32_ALPHABET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
BECH32_GENERATORS = (0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)


def pubkey_address(pk: bytes) -> str:
    """Rust address.rs: Bech32m(spider, SHA256(ed25519 pubkey)[:20])."""
    if len(pk) != 32:
        raise ValueError("invalid Ed25519 public key length")
    digest = hashlib.sha256(pk).digest()[:20]
    acc, bits = 0, 0
    symbols = []
    for byte in digest:
        acc = ((acc << 8) | byte) & 0xFFFF
        bits += 8
        while bits >= 5:
            bits -= 5
            symbols.append((acc >> bits) & 31)
    if bits:
        symbols.append((acc << (5 - bits)) & 31)
    hrp = "spider"
    expanded = [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]
    chk = 1
    for value in expanded + symbols + [0] * 6:
        high = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ value
        for n, generator in enumerate(BECH32_GENERATORS):
            if (high >> n) & 1:
                chk ^= generator
    chk ^= 0x2BC830A3
    checksum = [(chk >> (5 * (5 - n))) & 31 for n in range(6)]
    return hrp + "1" + "".join(BECH32_ALPHABET[v] for v in symbols + checksum)


def encode_field(value: str) -> bytes:
    raw = value.encode("utf-8")
    if len(raw) > 4096:
        raise ValueError("overlong transfer field")
    return struct.pack(">I", len(raw)) + raw


def transaction_id(payload: dict) -> str:
    """Rust tx.rs/codec.rs canonical signing preimage and ID, independently verified by fixture."""
    if not isinstance(payload, dict) or set(payload) != {"payload", "public_key", "signature"}:
        raise ValueError("invalid signed transfer shape")
    tx = payload["payload"]
    if not isinstance(tx, dict) or set(tx) != set(FIELDS):
        raise ValueError("invalid transfer payload")
    for key in FIELDS[:4]:
        if not isinstance(tx[key], str) or not tx[key] or len(tx[key]) > 180:
            raise ValueError("invalid string field")
    if not ADDR.fullmatch(tx["sender"]) or not ADDR.fullmatch(tx["recipient"]):
        raise ValueError("invalid Spider address")
    if tx["chain_id"] != "spider-devnet-1":
        raise ValueError("wrong devnet chain")
    for key in FIELDS[4:]:
        if type(tx[key]) is not int or not 0 <= tx[key] <= UINT64_MAX:
            raise ValueError("invalid atomic unsigned integer")
    if tx["amount"] == 0 or tx["gas_limit"] < 21_000 or tx["max_fee_per_gas"] == 0 or tx["expiry_height"] == 0:
        raise ValueError("invalid transfer amount/gas/expiry")
    pk, sig = payload["public_key"], payload["signature"]
    if not isinstance(pk, str) or not isinstance(sig, str):
        raise ValueError("invalid signature fields")
    if not TX_ID.fullmatch(pk) or not re.fullmatch(r"[a-f0-9]{128}", sig):
        raise ValueError("noncanonical key or signature")
    signing = b"SPIDER/TX/TRANSFER/V1\0"
    for key in FIELDS[:4]:
        signing += encode_field(tx[key])
    for key in FIELDS[4:]:
        signing += struct.pack(">Q", tx[key])
    public = bytes.fromhex(pk)
    if pubkey_address(public) != tx["sender"]:
        raise ValueError("signed transfer sender does not match public key")
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(bytes.fromhex(sig), signing)
    except (ValueError, InvalidSignature) as error:
        raise ValueError("invalid Ed25519 transfer signature") from error
    preimage = b"SPIDER/TXID/V1\0" + struct.pack(">I", len(signing)) + signing
    preimage += encode_field(pk) + encode_field(sig)
    return hashlib.sha256(preimage).hexdigest()


def token_from_file(path: str) -> str:
    p = Path(path)
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_mode & 0o077:
        raise ValueError("token file must be a regular file, chmod 600")
    token = p.read_text("ascii").strip()
    if not re.fullmatch(r"[a-f0-9]{64}", token):
        raise ValueError("token file must contain 32 cryptographically random bytes as lowercase hex")
    return token


class DurableQueue:
    def __init__(self, path: str):
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None, timeout=3)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=FULL")
        self.conn.execute("CREATE TABLE IF NOT EXISTS signed_pending(id TEXT PRIMARY KEY, body BLOB NOT NULL, created INTEGER NOT NULL)")

    def record(self, txid: str, body: bytes):
        with self.lock:
            if self.conn.execute("SELECT COUNT(*) FROM signed_pending").fetchone()[0] >= MAX_ROWS:
                if self.conn.execute("SELECT 1 FROM signed_pending WHERE id=?", (txid,)).fetchone() is None:
                    raise ValueError("durable queue capacity reached")
            self.conn.execute("INSERT OR IGNORE INTO signed_pending(id,body,created) VALUES(?,?,?)", (txid, body, int(time.time())))

    def has_exact(self, txid: str, body: bytes) -> bool:
        with self.lock:
            row = self.conn.execute("SELECT body FROM signed_pending WHERE id=?", (txid,)).fetchone()
            if row is None:
                return False
            if row[0] != body:
                raise ValueError("stored signed transaction ID has conflicting payload")
            return True

    def remove(self, txid: str):
        with self.lock:
            self.conn.execute("DELETE FROM signed_pending WHERE id=?", (txid,))

    def items(self, after: str = ""):
        """Return one bounded, wrapping page in stable transaction-ID order.

        A fixed oldest-first LIMIT would retry the same 16 entries forever
        under an outage and starve every other transaction. The cursor is
        deliberately independent of insertion time (which is not unique).
        """
        if after and not TX_ID.fullmatch(after):
            raise ValueError("invalid replay cursor")
        with self.lock:
            rows = self.conn.execute(
                "SELECT id,body,created FROM signed_pending WHERE id>? ORDER BY id LIMIT 16",
                (after,),
            ).fetchall()
            if len(rows) < 16:
                rows.extend(self.conn.execute(
                    "SELECT id,body,created FROM signed_pending WHERE id<=? ORDER BY id LIMIT ?",
                    (after, 16 - len(rows)),
                ).fetchall())
            return rows


class State:
    def __init__(self, token: str, db: str, read_port: int, submit_port: int):
        self.token = token
        self.queue = DurableQueue(db)
        self.read_port = read_port
        self.submit_port = submit_port
        self.lock = threading.Lock()
        self.submit_lock = threading.Lock()  # serialize admission/rejection bookkeeping
        self.reads = deque()
        self.posts = deque()
        self.stop = threading.Event()
        self.replay_cursor = ""

    def rate(self, method: str) -> bool:
        now = time.monotonic()
        with self.lock:
            q, limit = (self.posts, 20) if method == "POST" else (self.reads, 120)
            while q and now - q[0] > 60:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True

    def upstream(self, port: int, method: str, path: str, body: bytes = b""):
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=2.0)
        try:
            headers = {"Host": "127.0.0.1", "Connection": "close"}
            if body:
                headers["Content-Type"] = "application/json"
            conn.request(method, path, body=body if method == "POST" else None, headers=headers)
            response = conn.getresponse()
            data = response.read(MAX_BODY + 1)
            if len(data) > MAX_BODY:
                raise ValueError("upstream response too large")
            value = json.loads(data)
            if not isinstance(value, dict):
                raise ValueError("upstream response was not an object")
            return response.status, value
        finally:
            conn.close()

    def replay_once(self):
        """Recheck one fair page of previously signed transactions.

        Never silently erase unfinalized signed requests because a wall-clock
        timer elapsed: an outage is not certified finality. The 256-entry bound
        remains in force; operations must handle stale entries explicitly.
        """
        for txid, body, _created in self.queue.items(after=self.replay_cursor):
            self.replay_cursor = txid
            try:
                code, result = self.upstream(self.read_port, "GET", f"/v1/transactions/{txid}/status")
                if code == 200 and result.get("id") == txid and result.get("finalized") is True:
                    self.queue.remove(txid)
                    continue
                # A 202 is NOT finality. Never delete a signed request because
                # an intermediate network hop rejected or lost a replay.
                self.upstream(self.submit_port, "POST", "/v1/transactions", body)
            except (OSError, ValueError, json.JSONDecodeError, http.client.HTTPException):
                # The original signed request stays durably queued for retry.
                pass

    def replay(self):
        while not self.stop.wait(3):
            self.replay_once()


class Handler(BaseHTTPRequestHandler):
    server_version = "SpiderWalletDevnet/1"
    protocol_version = "HTTP/1.1"

    @property
    def state(self) -> State:
        return self.server.state

    def log_message(self, fmt, *args):
        # Do not log access tokens or signed transactions.
        pass

    def reply(self, status, value):
        data = json.dumps(value, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)
        self.close_connection = True

    def check(self, method):
        # Reject ambiguous duplicate authentication/framing headers before
        # proxying. Never let downstream and upstream interpret them differently.
        if (len(self.headers.get_all("Authorization", [])) > 1
                or len(self.headers.get_all("Host", [])) > 1
                or self.headers.get("Transfer-Encoding") is not None):
            self.reply(400, {"error": "ambiguous HTTP headers"})
            return False
        supplied = self.headers.get("Authorization", "")
        if not hmac.compare_digest(supplied, "Bearer " + self.state.token):
            self.reply(401, {"error": "unauthorized"})
            return False
        if not self.state.rate(method):
            self.reply(429, {"error": "rate limit exceeded"})
            return False
        return True

    def do_GET(self):
        if not self.check("GET"):
            return
        path = urlsplit(self.path)
        raw = path.path
        if path.query or path.fragment or not (raw in READ_PATHS or ACCOUNT.fullmatch(raw) or TX_STATUS.fullmatch(raw) or BLOCK.fullmatch(raw)):
            self.reply(404, {"error": "route not available"})
            return
        try:
            status, value = self.state.upstream(self.state.read_port, "GET", raw)
            self.reply(status, value)
        except (OSError, ValueError, http.client.HTTPException):
            self.reply(503, {"error": "certified reader unavailable"})

    def do_POST(self):
        if not self.check("POST"):
            return
        with self.state.submit_lock:
            self._submit_once()

    def _submit_once(self):
        if self.path != "/v1/transactions" or self.headers.get("Content-Type") != "application/json":
            self.reply(404, {"error": "route not available"})
            return
        if self.headers.get("Transfer-Encoding") or len(self.headers.get_all("Content-Length", [])) != 1:
            self.reply(400, {"error": "invalid HTTP framing"})
            return
        try:
            length = int(self.headers["Content-Length"])
            if not 1 <= length <= MAX_BODY:
                raise ValueError("body size limit exceeded")
            body = self.rfile.read(length)
            if len(body) != length:
                raise ValueError("incomplete body")
            parsed = json.loads(body)
            txid = transaction_id(parsed)
            already_queued = self.state.queue.has_exact(txid, body)
            self.state.queue.record(txid, body)
        except (ValueError, TypeError, UnicodeError, json.JSONDecodeError):
            self.reply(400, {"error": "invalid devnet signed transfer or queue full"})
            return
        try:
            status, value = self.state.upstream(self.state.submit_port, "POST", "/v1/transactions", body)
            if status == 202 and value.get("id") == txid:
                self.reply(202, value)
            elif status in (400, 422):
                # A duplicate POST after a lost HTTP response may receive 422
                # even though its *identical* signed tx is already queued on a
                # validator. Never erase the original durable spool record.
                # Initial invalid submissions still leave no provisional row.
                if not already_queued:
                    self.state.queue.remove(txid)
                self.reply(status, value)
            else:
                self.reply(503, {"error": "validator did not confirm queue receipt", "id": txid})
        except (OSError, ValueError, http.client.HTTPException):
            self.reply(503, {"error": "validator unavailable; safe to retry", "id": txid})

    def do_PUT(self):
        self.reply(405, {"error": "unsupported method"})

    do_DELETE = do_PUT
    do_PATCH = do_PUT


class Server(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False
    allow_reuse_address = True
    def __init__(self, addr, state):
        self._slots = threading.BoundedSemaphore(32)
        if addr[0] not in ("127.0.0.1", "::1"):
            raise ValueError("gateway backend must be bound to loopback")
        super().__init__(addr, Handler)
        self.state = state

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    def get_request(self):
        socket, addr = super().get_request()
        socket.settimeout(3.0)
        return socket, addr


def main():
    p = argparse.ArgumentParser(description="Spider Wallet DEVNET only: run behind a TLS proxy")
    p.add_argument("--listen-port", type=int, default=29080)
    p.add_argument("--read-port", type=int, default=28982)
    p.add_argument("--submit-port", type=int, default=28981)
    p.add_argument("--token-file", required=True)
    p.add_argument("--db", required=True)
    a = p.parse_args()
    if len({a.listen_port, a.read_port, a.submit_port}) != 3 or not all(1 <= port <= 65535 for port in (a.listen_port, a.read_port, a.submit_port)):
        p.error("all three ports must be distinct nonzero values")
    token = token_from_file(a.token_file)
    os.umask(0o077)  # SQLite state/WAL files are private.
    state = State(token, a.db, a.read_port, a.submit_port)
    server = Server(("127.0.0.1", a.listen_port), state)
    worker = threading.Thread(target=state.replay, daemon=True)
    worker.start()
    try:
        print(f"Spider Wallet DEVNET gateway listening on 127.0.0.1:{a.listen_port} (NO TLS HERE)", flush=True)
        server.serve_forever(poll_interval=0.2)
    finally:
        state.stop.set()
        server.server_close()


if __name__ == "__main__":
    main()
