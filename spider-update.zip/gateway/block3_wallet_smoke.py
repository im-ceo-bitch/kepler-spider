#!/usr/bin/env python3
"""Operator-driven HTTPS smoke check. Never mints SPD or reports HTTP 202 as finality.

Commands:
  python3 tools/block3_wallet_smoke.py --url https://... --token-file /secure/token \
      --chain-id spider-devnet-1 --genesis-hash HEX --account spider1...
  ... --signed-json /secure/test-transfer.json --poll-attempts 20

Submitting is opt-in and uses an already signed DEVNET transfer (NO private keys).
"""
import argparse
import json
from pathlib import Path
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit


def request(base: str, token: str, method: str, path: str, signed: bytes | None = None):
    req = urllib.request.Request(base + path, data=signed, method=method,
                                 headers={'Authorization': 'Bearer ' + token,
                                          'Accept': 'application/json',
                                          **({'Content-Type': 'application/json'} if signed is not None else {})})
    with urllib.request.urlopen(req, timeout=8, context=ssl.create_default_context()) as response:
        if response.status not in (200, 202):
            raise ValueError('unexpected HTTP status')
        data = response.read(1024 * 1024 + 1)
        if len(data) > 1024 * 1024:
            raise ValueError('RPC response larger than 1 MiB')
        output = json.loads(data)
        if not isinstance(output, dict):
            raise ValueError('non-JSON-object RPC response')
        return response.status, output


def inspect(status: dict, chain: str, genesis: str):
    if (status.get('network') != 'SPIDER_CERTIFIED_DEVNET_RESEARCH'
        or status.get('chain_id') != chain
        or status.get('genesis_hash') != genesis
        or status.get('real_spd') is not False or status.get('real_usdt') is not False):
        raise ValueError('CERTIFIED DEVNET identity mismatch; refusing to submit')
    height = status.get('height')
    root = status.get('state_root')
    if type(height) is not int or height < 0 or not isinstance(root, str) or not re.fullmatch(r'[a-f0-9]{64}', root):
        raise ValueError('invalid certified height or state root')
    return height


def verify_receipt(receipt: dict, txid: str, chain: str) -> bool:
    if receipt.get('chain_id') != chain or receipt.get('id') != txid or type(receipt.get('finalized')) is not bool:
        raise ValueError('certified transaction identity mismatch')
    if receipt['finalized']:
        if (type(receipt.get('height')) is not int or receipt['height'] <= 0
                or not isinstance(receipt.get('block_hash'), str)
                or not re.fullmatch(r'[a-f0-9]{64}', receipt['block_hash'])
                or receipt.get('status') != 'included_in_verified_devnet_block'):
            raise ValueError('invalid RPC-reported certified receipt')
        return True
    if receipt.get('status') != 'not_in_certified_history':
        raise ValueError('unrecognized pending status')
    return False


def main():
    parser = argparse.ArgumentParser(description='Spider Wallet verified-devnet HTTPS smoke check')
    parser.add_argument('--url', required=True)
    parser.add_argument('--token-file', required=True)
    parser.add_argument('--chain-id', required=True)
    parser.add_argument('--genesis-hash', required=True)
    parser.add_argument('--account', required=True)
    parser.add_argument('--signed-json', help='OPTIONAL: explicitly submit an already-signed test transfer')
    parser.add_argument('--poll-attempts', type=int, default=20)
    opts = parser.parse_args()
    u = urlsplit(opts.url)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('', '/'):
        parser.error('--url must be an HTTPS origin, not a URL with credentials/path')
    if not re.fullmatch(r'[a-f0-9]{64}', opts.genesis_hash):
        parser.error('--genesis-hash must be 64 lowercase hex chars')
    if not re.fullmatch(r'spider1[023456789acdefghjklmnpqrstuvwxyz]{20,90}', opts.account):
        parser.error('--account must be a Spider address')
    if not 1 <= opts.poll_attempts <= 120:
        parser.error('--poll-attempts must be 1..120')
    # Token-file validation is shared with the gateway and requires chmod 600.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from spider_wallet_gateway import token_from_file, transaction_id
    token = token_from_file(opts.token_file)
    base = opts.url.rstrip('/')
    _, status = request(base, token, 'GET', '/v1/status')
    height = inspect(status, opts.chain_id, opts.genesis_hash)
    _, account = request(base, token, 'GET', '/v1/accounts/' + opts.account)
    if account.get('chain_id') != opts.chain_id or account.get('address') != opts.account:
        raise ValueError('certified account chain/address mismatch')
    print(f'PASS certified identity and account read: height={height}, nonce={account.get("nonce")}')
    if not opts.signed_json:
        print('READ-ONLY COMPLETE: no funds or signed transactions were sent')
        return
    body = Path(opts.signed_json).read_bytes()
    if len(body) > 64 * 1024:
        raise ValueError('signed JSON too large')
    txid = transaction_id(json.loads(body))
    _, accepted = request(base, token, 'POST', '/v1/transactions', body)
    if (accepted.get('id') != txid or accepted.get('status') != 'queued_locally_not_finalized'
            or accepted.get('durable_mempool') is not True or accepted.get('real_spd') is not False):
        raise ValueError('validator did not acknowledge this signed transfer durably and unfinalized')
    print('QUEUED TEST TRANSFER, not finalized:', txid)
    for i in range(opts.poll_attempts):
        _, receipt = request(base, token, 'GET', f'/v1/transactions/{txid}/status')
        if verify_receipt(receipt, txid, opts.chain_id):
            print(f'PASS DEVNET RPC-REPORTED CERTIFICATION: height={receipt["height"]}, block={receipt["block_hash"]} (independent QC check still required)')
            return
        if i + 1 < opts.poll_attempts:
            time.sleep(3)
    raise SystemExit('NOT FINALIZED: transaction remains unknown/pending; do not mark payment successful')

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, urllib.error.URLError, json.JSONDecodeError) as error:
        raise SystemExit(f'BLOCK 3 WALLET SMOKE FAILED: {error}')
