"""Block 3 acceptance tests: durable, fair, fail-closed wallet relay retries.

These are gateway tests, not evidence of BFT finality or a public P2P network.
"""
import importlib.util
from pathlib import Path
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'spider_wallet_gateway.py'
spec = importlib.util.spec_from_file_location('spider_wallet_gateway_replay_test', SOURCE)
gw = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gw)


class DurableReplayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = str(Path(self.tmp.name) / 'queue.db')
        self.state = gw.State('ab' * 32, self.db, 28982, 28981)
        self.addCleanup(self.state.queue.conn.close)

    @staticmethod
    def txid(number):
        return f'{number:064x}'

    def fill(self, count):
        for number in range(1, count + 1):
            self.state.queue.record(self.txid(number), f'signed-{number}'.encode())

    def test_256_pending_transactions_receive_fair_retries_without_expiry_deletion(self):
        self.fill(gw.MAX_ROWS)
        # Simulate an extended outage. No 24h wall-clock eviction is permitted.
        self.state.queue.conn.execute('UPDATE signed_pending SET created=1')
        calls = []

        def fake_upstream(port, method, path, body=b''):
            if method == 'GET':
                return 200, {'id': path.split('/')[-2], 'finalized': False}
            calls.append(body)
            return 202, {'status': 'queued_locally_not_finalized'}

        self.state.upstream = fake_upstream
        for _ in range(gw.MAX_ROWS // 16):
            self.state.replay_once()
        self.assertEqual(len(calls), gw.MAX_ROWS)
        self.assertEqual(set(calls), {f'signed-{i}'.encode() for i in range(1, gw.MAX_ROWS + 1)})
        self.assertEqual(len(self.state.queue.items()), 16)
        self.assertEqual(self.state.queue.conn.execute('SELECT COUNT(*) FROM signed_pending').fetchone()[0], gw.MAX_ROWS)
        # Verify wraparound rather than starvation by the first 16 rows.
        self.state.replay_once()
        self.assertEqual(calls[-16:], [f'signed-{i}'.encode() for i in range(1, 17)])

    def test_only_matching_certified_finality_removes_pending_transfer(self):
        self.fill(2)
        first = self.txid(1)
        second = self.txid(2)
        seen = []

        def fake_upstream(port, method, path, body=b''):
            if method == 'GET':
                # An unrelated receipt must not remove the local request.
                return 200, {'id': second, 'finalized': True}
            seen.append(body)
            return 422, {'error': 'stale pending transfer'}

        self.state.upstream = fake_upstream
        self.state.replay_once()
        self.assertEqual(seen, [b'signed-1'])
        self.assertEqual([row[0] for row in self.state.queue.items()], [first])
        self.assertEqual(self.state.queue.conn.execute('SELECT COUNT(*) FROM signed_pending').fetchone()[0], 1)

    def test_restart_replays_existing_queue_without_dropping_it(self):
        self.fill(35)
        # Advance cursor and reopen the SQLite queue; WAL state survives.
        self.state.upstream = lambda port, method, path, body=b'': (
            (200, {'id': path.split('/')[-2], 'finalized': False}) if method == 'GET'
            else (202, {'status': 'queued_locally_not_finalized'})
        )
        self.state.replay_once()
        restarted = gw.State('ab' * 32, self.db, 28982, 28981)
        self.addCleanup(restarted.queue.conn.close)
        seen = []

        def upstream(port, method, path, body=b''):
            if method == 'GET':
                return 200, {'id': path.split('/')[-2], 'finalized': False}
            seen.append(body)
            return 202, {}

        restarted.upstream = upstream
        for _ in range(3):
            restarted.replay_once()
        self.assertEqual(len(seen), 35 + 13)  # one complete pass + 13 wrapped
        self.assertEqual(set(seen), {f'signed-{i}'.encode() for i in range(1, 36)})

    def test_queue_bounds_and_cursor_validation(self):
        self.fill(gw.MAX_ROWS)
        with self.assertRaises(ValueError):
            self.state.queue.record(self.txid(gw.MAX_ROWS + 1), b'signed-extra')
        with self.assertRaises(ValueError):
            self.state.queue.items(after='../danger')
        # Repeated IDs remain idempotent even when queue is full.
        self.state.queue.record(self.txid(1), b'signed-1')


if __name__ == '__main__':
    unittest.main()
