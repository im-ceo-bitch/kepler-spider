import importlib.util
import json
import os
from pathlib import Path
import socket
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SOURCE = Path(__file__).resolve().parents[1] / 'spider_wallet_gateway.py'
spec = importlib.util.spec_from_file_location('spider_wallet_gateway', SOURCE)
gw = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gw)
VECTOR = json.loads((Path(__file__).resolve().parents[2] / 'test-vectors' / 'transfer-v1.json').read_text())
TRANSFER = {key: VECTOR[key] for key in ('payload', 'public_key', 'signature')}

class MockHandler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_POST(self):
        data = self.rfile.read(int(self.headers['Content-Length']))
        self.server.received.append(data)
        status, obj = (202, {'id': gw.transaction_id(json.loads(data)), 'status': 'queued_locally_not_finalized', 'broadcast': False, 'durable_mempool': False, 'real_spd': False})
        if self.server.reject: status, obj = (422, {'error': 'invalid transaction'})
        self.send(status, obj)
    def do_GET(self):
        if self.path == '/v1/status':
            self.send(200, {'network':'SPIDER_CERTIFIED_DEVNET_RESEARCH', 'chain_id':'spider-devnet-1', 'genesis_hash':'some-devnet-hash', 'height':0})
        else:
            txid = self.path.split('/')[-2]
            self.send(200, {'id':txid, 'chain_id':'spider-devnet-1', 'finalized': self.server.finalized, 'status':'included_in_verified_devnet_block' if self.server.finalized else 'not_in_certified_history'})
    def send(self, status, obj):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

class MockServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self):
        super().__init__(('127.0.0.1', 0), MockHandler)
        self.received=[]
        self.reject=False
        self.finalized=False

def running(server):
    t = threading.Thread(target=server.serve_forever, daemon=True); t.start()
    return t

class GatewayTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.mock = MockServer(); self.mock_thread = running(self.mock)
        self.token = 'ab'*32
        self.state = gw.State(self.token, os.path.join(self.tmp.name, 'queue.db'), self.mock.server_port, self.mock.server_port)
        self.server = gw.Server(('127.0.0.1', 0), self.state)
        self.worker = running(self.server)
        self.root = f'http://127.0.0.1:{self.server.server_port}'
    def tearDown(self):
        self.server.shutdown(); self.server.server_close()
        self.mock.shutdown(); self.mock.server_close()
        self.state.queue.conn.close(); self.tmp.cleanup()
    def call(self, route, method='GET', data=None, token=None, content_type='application/json'):
        req = urllib.request.Request(self.root+route, data=data, method=method)
        if token is not False:
            req.add_header('Authorization', 'Bearer ' + (token or self.token))
        if data is not None:
            req.add_header('Content-Type', content_type)
        try:
            with urllib.request.urlopen(req, timeout=3) as resp:
                return resp.status, json.load(resp)
        except urllib.error.HTTPError as e:
            return e.code, json.load(e)

    def test_reference_txid_and_verify_signature(self):
        self.assertEqual(gw.transaction_id(TRANSFER), VECTOR['transaction_id'])
        # Optional independent Ed25519 oracle available in working environment.
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        except ImportError:
            return  # stdlib-only GitHub CI also validates canonical transaction ID
        msg = bytes.fromhex(VECTOR['signing_bytes_hex'])
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(TRANSFER['public_key'])).verify(bytes.fromhex(TRANSFER['signature']), msg)
    def test_authorization_and_routes(self):
        self.assertEqual(self.call('/v1/status', token=False)[0], 401)
        self.assertEqual(self.call('/v1/status', token='cd'*32)[0], 401)
        self.assertEqual(self.call('/v1/status')[0], 200)
        self.assertEqual(self.call('/admin')[0], 404)
        self.assertEqual(self.call('/v1/status?url=evil')[0], 404)
        self.assertEqual(self.call('/v1/accounts/%2e%2e')[0], 404)
    def test_submission_not_finality_and_spool_recovery(self):
        data = json.dumps(TRANSFER).encode()
        code, result = self.call('/v1/transactions', method='POST', data=data)
        self.assertEqual(code, 202)
        self.assertEqual(result['id'], VECTOR['transaction_id'])
        self.assertEqual(result['status'], 'queued_locally_not_finalized')
        self.assertFalse(result['real_spd'])
        self.assertEqual(len(self.state.queue.items()), 1)
        self.assertEqual(self.call('/v1/transactions/'+VECTOR['transaction_id']+'/status')[1]['finalized'], False)
        # Restart does not erase the already-signed, unfinalized submission.
        db2=gw.DurableQueue(os.path.join(self.tmp.name, 'queue.db'))
        self.assertEqual(db2.items()[0][0], VECTOR['transaction_id'])
        db2.conn.close()
        self.mock.finalized=True
        retry = threading.Thread(target=self.state.replay, daemon=True)
        retry.start()
        time.sleep(3.3)
        self.assertFalse(self.state.queue.items())
        self.state.stop.set()
    def test_bad_transfer_does_not_enter_spool(self):
        forged = json.loads(json.dumps(TRANSFER))
        forged['payload']['chain_id'] = 'other'
        self.assertEqual(self.call('/v1/transactions', method='POST', data=json.dumps(forged).encode())[0], 400)
        self.assertFalse(self.state.queue.items())
        forged = json.loads(json.dumps(TRANSFER)); forged['payload']['amount'] = -1
        self.assertEqual(self.call('/v1/transactions', method='POST', data=json.dumps(forged).encode())[0], 400)
        self.assertFalse(self.state.queue.items())
    def test_tampered_signed_transfer_rejected_before_validator(self):
        for mutation in ('signature', 'sender', 'amount', 'gas_limit', 'expiry_height'):
            bad = json.loads(json.dumps(TRANSFER))
            if mutation == 'signature':
                bad['signature'] = '00' * 64
            elif mutation == 'sender':
                bad['payload']['sender'] = bad['payload']['recipient']
            elif mutation == 'amount':
                bad['payload']['amount'] += 1  # signature does not cover changed amount
            elif mutation == 'gas_limit':
                bad['payload']['gas_limit'] = 1
            else:
                bad['payload']['expiry_height'] = 0
            code, _ = self.call('/v1/transactions', method='POST', data=json.dumps(bad).encode())
            self.assertEqual(code, 400, mutation)
        self.assertEqual(self.mock.received, [])
        self.assertEqual(self.state.queue.items(), [])

    def test_repeated_send_422_never_discards_earlier_durable_transfer(self):
        raw = json.dumps(TRANSFER).encode()
        self.assertEqual(self.call('/v1/transactions', method='POST', data=raw)[0], 202)
        self.assertEqual(len(self.state.queue.items()), 1)
        # Simulate an accepted first send whose HTTP response was lost. The
        # validator responds 422 on the user's retry because it already has it.
        self.mock.reject = True
        self.assertEqual(self.call('/v1/transactions', method='POST', data=raw)[0], 422)
        self.assertEqual(len(self.state.queue.items()), 1)
        self.assertEqual(self.state.queue.items()[0][0], VECTOR['transaction_id'])

    def test_upstream_rejection_removes_provisional_queue(self):
        self.mock.reject=True
        status, _ = self.call('/v1/transactions', method='POST', data=json.dumps(TRANSFER).encode())
        self.assertEqual(status, 422)
        self.assertFalse(self.state.queue.items())
    def test_token_permissions(self):
        path = Path(self.tmp.name)/'token.txt'
        path.write_text(self.token)
        os.chmod(path, 0o644)
        with self.assertRaises(ValueError): gw.token_from_file(str(path))
        os.chmod(path, 0o600)
        self.assertEqual(gw.token_from_file(str(path)), self.token)
        bad = Path(self.tmp.name)/'symlink.txt'
        bad.symlink_to(path)
        with self.assertRaises(ValueError): gw.token_from_file(str(bad))
    def test_binds_only_localhost(self):
        with self.assertRaises(ValueError): gw.Server(('0.0.0.0', 0), self.state)

if __name__ == '__main__': unittest.main()
