import importlib.util
from pathlib import Path
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'block3_wallet_smoke.py'
spec = importlib.util.spec_from_file_location('block3_wallet_smoke', SOURCE)
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)

class WalletSmokeGates(unittest.TestCase):
    def status(self):
        return {'network':'SPIDER_CERTIFIED_DEVNET_RESEARCH', 'chain_id':'spider-devnet-1',
                'genesis_hash':'a'*64, 'state_root':'b'*64, 'height': 2,
                'real_spd': False, 'real_usdt': False}

    def test_status_identity_and_root(self):
        self.assertEqual(smoke.inspect(self.status(), 'spider-devnet-1', 'a'*64), 2)
        x=self.status(); x['state_root']='forged'
        with self.assertRaises(ValueError): smoke.inspect(x,'spider-devnet-1','a'*64)
        x=self.status(); x['real_spd']=True
        with self.assertRaises(ValueError): smoke.inspect(x,'spider-devnet-1','a'*64)

    def test_unfinalized_receipt_cannot_claim_success(self):
        txid='0'*64
        base={'chain_id':'spider-devnet-1', 'id':txid, 'finalized':False,
              'status':'not_in_certified_history'}
        self.assertFalse(smoke.verify_receipt(base,txid,'spider-devnet-1'))
        base['finalized']=True
        with self.assertRaises(ValueError): smoke.verify_receipt(base,txid,'spider-devnet-1')
        base.update(status='included_in_verified_devnet_block', height=1,block_hash='f'*64)
        self.assertTrue(smoke.verify_receipt(base,txid,'spider-devnet-1'))
        base['block_hash']='fake'
        with self.assertRaises(ValueError): smoke.verify_receipt(base,txid,'spider-devnet-1')

if __name__=='__main__': unittest.main()
