//! Native four-process release gate. BOTH exercises run in sequence so even
//! the older ZIP Installer's default-parallel `cargo test --all-targets` can't
//! launch two large loopback networks simultaneously. No checks are skipped.
//! This is a localhost research fixture, not a production BFT safety proof.
use std::process::Command;

#[test]
fn native_four_process_replay_partition_healing_and_corruption_gates() {
    let binary = env!("CARGO_BIN_EXE_spider-bft-phase2-peer");
    for (script, description) in [
        (
            "research/phase2_multiheight_process_test.py",
            "multiheight, restart, no-quorum and offline leader",
        ),
        (
            "research/four_validator_release_gate.py",
            "four-peer 2+2 isolation, healing and damaged WAL",
        ),
    ] {
        let status = Command::new("python3")
            .arg(script)
            .arg(binary)
            .current_dir(env!("CARGO_MANIFEST_DIR"))
            .status()
            .unwrap_or_else(|error| panic!("could not run {description}: {error}"));
        assert!(status.success(), "native SpiderBFT gate failed: {description}");
    }
}
