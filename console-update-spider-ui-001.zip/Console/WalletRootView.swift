import SwiftUI
import UIKit

/// Two independent histories: financial navigation never replaces a conversation.
/// Only short, transactional workflows are presented modally.
private enum SpyderWalletPage: Hashable {
    case center, accounts, security, addressBook, settings, activity, asset(SpyderChain)
}

private enum SpyderNetworkPage: Hashable {
    case identity, chat(WalletContact), contact(WalletContact)
}

struct WalletRootView: View {
    @EnvironmentObject private var chat: SpyderChatStore
    @State private var showingLinkInvite = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var selectedTab: WalletTab = .wallet
    @State private var walletPath: [SpyderWalletPage] = []
    @State private var networkPath: [SpyderNetworkPage] = []
    @State private var presented: WalletModal?
    @State private var sendChain: SpyderChain?
    @State private var selectedContact = WalletContact(id: "", name: "Не выбран", handle: "", letter: "", preview: "", time: "")

    private var atRoot: Bool {
        switch selectedTab {
        case .wallet: return walletPath.isEmpty
        case .chats: return networkPath.isEmpty
        }
    }

    var body: some View {
        ZStack {
            walletNavigation
                .opacity(selectedTab == .wallet ? 1 : 0)
                .allowsHitTesting(selectedTab == .wallet)
                .accessibilityHidden(selectedTab != .wallet)
                .zIndex(selectedTab == .wallet ? 1 : 0)
            networkNavigation
                .environment(\.spyderChatSectionActive, selectedTab == .chats && presented == nil && !showingLinkInvite)
                .opacity(selectedTab == .chats ? 1 : 0)
                .allowsHitTesting(selectedTab == .chats)
                .accessibilityHidden(selectedTab != .chats)
                .zIndex(selectedTab == .chats ? 1 : 0)

        }
        .tint(WalletTheme.ink)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if atRoot { bottomBar }
        }
        .sheet(item: Binding(get: { presented == .touch ? nil : presented }, set: { value in
            if presented != .touch { presented = value }
        })) { modal in
            modalView(modal)
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(30)
        }
        .fullScreenCover(isPresented: Binding(get: { presented == .touch }, set: { value in
            if !value && presented == .touch { presented = nil }
        })) {
            WalletTouchView { contact in
                presented = nil
                selectedTab = .chats
                networkPath.append(.chat(contact))
            }
        }
        .sheet(isPresented: $showingLinkInvite) {
            SpyderInvitePage(onOpen: { person in
                showingLinkInvite = false
                selectedTab = .chats
                networkPath.append(.chat(person))
            })
        }
        .onChange(of: chat.pendingInviteCode) { _, code in
            if code != nil {
                selectedTab = .chats
                showingLinkInvite = chat.hasIdentity
            }
        }
        .onChange(of: chat.hasIdentity) { _, ready in
            if ready && chat.pendingInviteCode != nil { showingLinkInvite = true }
        }
        .task {
            openChatAfterNotificationIfNeeded()
            if chat.pendingInviteCode != nil {
                selectedTab = .chats
                showingLinkInvite = chat.hasIdentity
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .spyderChatOpenRequested)) { _ in
            openChatAfterNotificationIfNeeded()
        }
        .background(WalletTheme.canvas.ignoresSafeArea())
    }

    private var walletNavigation: some View {
        NavigationStack(path: $walletPath) {
            WalletHomeView(onAction: { action in
                sendChain = nil
                presented = action
            }, onActivity: {
                walletPath.append(.activity)
            }, onAsset: { chain in
                walletPath.append(.asset(chain))
            }, onControlCenter: {
                walletPath.append(.center)
            })
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: SpyderWalletPage.self) { destination in
                walletDestination(destination)
                    .toolbar(.visible, for: .navigationBar)
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }

    private var networkNavigation: some View {
        NavigationStack(path: $networkPath) {
            ChatsHomeView(onOpen: { person in
                networkPath.append(.chat(person))
            }, onAdd: {
                showingLinkInvite = true
            }, onProfile: {
                networkPath.append(.identity)
            }, isActive: selectedTab == .chats)
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: SpyderNetworkPage.self) { destination in
                networkDestination(destination)
                    .toolbar(.visible, for: .navigationBar)
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }

    @ViewBuilder
    private func walletDestination(_ destination: SpyderWalletPage) -> some View {
        switch destination {
        case .center:
            SpyderWalletProfilePage(
                onAccounts: { walletPath.append(.accounts) },
                onSecurity: { walletPath.append(.security) },
                onAddressBook: { walletPath.append(.addressBook) },
                onActivity: { walletPath.append(.activity) },
                onSettings: { walletPath.append(.settings) },
                onReceive: { sendChain = nil; presented = .receive }
            )
        case .accounts:
            WalletAccountsView()
        case .security:
            WalletSecurityCenterView()
        case .addressBook:
            WalletAddressBookView()
        case .settings:
            WalletSettingsView()
        case .activity:
            WalletActivityView(onBack: { if !walletPath.isEmpty { walletPath.removeLast() } })
        case .asset(let chain):
            WalletAssetDetailView(chain: chain, onSend: { target in
                sendChain = target
                presented = .send
            }, onReceive: {
                sendChain = chain
                presented = .receive
            })
        }
    }

    @ViewBuilder
    private func networkDestination(_ destination: SpyderNetworkPage) -> some View {
        switch destination {
        case .identity:
            SpyderIdentityHubView()
        case .chat(let contact):
            SpyderConversationSession(contact: contact, ownerPersonaID: chat.activePersonaID, onBack: {
                if !networkPath.isEmpty { networkPath.removeLast() }
            }, onAction: { action in
                selectedContact = contact
                if action == .profile {
                    networkPath.append(.identity)
                } else {
                    presented = action
                }
            }, onOpenActivity: {
                // Explicitly switch to the financial history when requested by Terminal.
                selectedTab = .wallet
                walletPath.append(.activity)
            })
        case .contact(let contact):
            SpyderContactProfilePage(contact: contact, onOpenChat: {
                if !networkPath.isEmpty { networkPath.removeLast() }
            }, onBlocked: {
                networkPath.removeAll()
            })
        }
    }

    private func openChatAfterNotificationIfNeeded() {
        guard UserDefaults.standard.bool(forKey: "spyder.chat.push.open.pending") else { return }
        UserDefaults.standard.set(false, forKey: "spyder.chat.push.open.pending")
        selectedTab = .chats
        // Keep the Network path if the person was already reading a conversation.
    }

    @ViewBuilder
    private func modalView(_ modal: WalletModal) -> some View {
        switch modal {
        case .send:
            WalletSendFlowView(preselected: sendChain)
        case .request:
            WalletTransferView(isRequest: true, contact: selectedContact)
        case .devnetTransfer:
            WalletTransferView(isRequest: false, contact: selectedContact)
        case .receive:
            WalletReceiveView(preselected: sendChain ?? .ethereum)
                .presentationDetents([.medium, .large])
        case .touch:
            WalletTouchView(onConnect: { contact in
                presented = nil
                selectedTab = .chats
                networkPath.append(.chat(contact))
            })
        case .profile:
            SpyderIdentityHubView() // Legacy external action fallback.
        case .accounts:
            WalletAccountsView()
        case .security:
            WalletSecurityCenterView()
        case .addressBook:
            WalletAddressBookView()
        }
    }

    private var bottomBar: some View {
        HStack(spacing: 0) {
            tabButton(.wallet, title: "Кошелёк", symbol: "wallet.pass")
            tabButton(.chats, title: "Чаты", symbol: "message")
        }
        .padding(.horizontal, WalletTheme.pageInset)
        .padding(.vertical, 3)
        .background(WalletTheme.canvas)
        .overlay(alignment: .top) { Divider() }
    }

    private func tabButton(_ tab: WalletTab, title: String, symbol: String) -> some View {
        let isSelected = selectedTab == tab
        return Button {
            guard selectedTab != tab else { return }
            UISelectionFeedbackGenerator().selectionChanged()
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                selectedTab = tab
            }
        } label: {
            VStack(spacing: 3) {
                Image(systemName: symbol)
                    .symbolVariant(isSelected ? .fill : .none)
                    .font(.system(size: 20, weight: isSelected ? .semibold : .regular))
                    .accessibilityHidden(true)
                Text(LocalizedStringKey(title))
                    .font(.caption.weight(isSelected ? .semibold : .regular))
            }
            .frame(maxWidth: .infinity)
            .frame(minHeight: 48)
            .foregroundStyle(isSelected ? WalletTheme.ink : WalletTheme.secondary)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}
