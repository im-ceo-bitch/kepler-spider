import SwiftUI
import UIKit

/// Wallet-only presentation. All financial values come from verified store responses;
/// absent balances and prices are never replaced with plausible sample numbers.
private enum WalletHomeSection: String {
    case assets, cryptocurrencies
}

private struct WalletMarketSelection: Identifiable {
    let ticker: String
    var id: String { ticker }
}

struct WalletHomeView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @ScaledMetric(relativeTo: .largeTitle) private var balanceSize: CGFloat = 48
    @EnvironmentObject private var chains: WalletChainStore
    @EnvironmentObject private var access: WalletAccess
    @EnvironmentObject private var publicAssets: WalletPublicAssetsStore
    @EnvironmentObject private var market: WalletMarketStore
    @EnvironmentObject private var live: WalletLiveMarketStore
    @EnvironmentObject private var history: WalletActivityStore
    @EnvironmentObject private var spider: SpiderDevnetStore
    @AppStorage("spyder.wallet.privacyHidden") private var privacyHidden = false
    @StateObject private var catalog = WalletCatalogStore()
    @State private var selectedSection = WalletHomeSection.assets.rawValue
    @State private var selectedToken: WalletVerifiedToken?
    @State private var expandedMarket: WalletMarketSelection?
    @State private var spdSheet: SPDWalletSheet?
    @State private var chooseSendAsset = false
    private enum SPDWalletSheet: String, Identifiable {
        case settings, details, receive, send
        var id: String { rawValue }
    }
    @State private var showIDPreview = false
    @State private var showNetworkPortfolio = false
    let onAction: (WalletModal) -> Void
    let onActivity: () -> Void
    let onAsset: (SpyderChain) -> Void
    let onControlCenter: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            walletHeader
                .padding(.horizontal, 20)
                .padding(.top, 6)
                .padding(.bottom, 12)
                .background(WalletTheme.canvas)
                .zIndex(1)
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    if selectedSection == WalletHomeSection.cryptocurrencies.rawValue {
                        marketNavigationHeader
                        marketStrip
                        WalletCatalogSection(catalog: catalog)
                            .environmentObject(market)
                            .environmentObject(live)
                    } else {
                        portfolioCard
                        quickActions
                        spdAssetEntry
                        networkPortfolioEntry
                        SpyderIDPreviewEntry { showIDPreview = true }
                        assetsSection
                        recentSection
                        marketEntry
                    }

                }
                .padding(.horizontal, 20)
                .padding(.top, 5)
                .padding(.bottom, 18)
                .frame(maxWidth: 700)
                .frame(maxWidth: .infinity)
            }
            .id(selectedSection) // New section always starts at the top, not at the old scroll offset.
            .refreshable {
                if selectedSection == WalletHomeSection.cryptocurrencies.rawValue {
                    await catalog.refresh(force: true)
                } else {
                    await refreshWallet()
                }
            }
        }
        // Keep scrolling content below the actual iOS status-bar safe area.
        // The header is a sibling of ScrollView, not its first scrolling row.
        .background(WalletTheme.canvas.ignoresSafeArea())
        .fullScreenCover(item: $expandedMarket) { selection in
            WalletLiveStageView(ticker: selection.ticker)
                .environmentObject(market)
                .environmentObject(live)
        }
        .confirmationDialog("Выбрать актив для перевода", isPresented: $chooseSendAsset, titleVisibility: .visible) {
            Button("SPD · тестовая сеть") { spdSheet = spider.hasConfiguration ? .send : .settings }
            Button("Другие активы · проверка реквизитов") { onAction(.send) }
            Button("Отмена", role: .cancel) {}
        }
        .sheet(item: $spdSheet) { route in
            switch route {
            case .settings: SpiderDevnetSettingsView()
            case .details: spdDetails
            case .receive: WalletReceiveView(spd: true)
            case .send: WalletTransferView(isRequest: false, contact: WalletContact(id: "", name: "", handle: "", letter: "", preview: "", time: ""))
            }
        }
        .sheet(isPresented: $showNetworkPortfolio) {
            if access.unlocked, let address = chains.address(for: .ethereum), chains.verifiedForReceiving,
               chains.verifiedWalletID == access.activeWalletID {
                WalletNetworkPortfolioView(address: address, privacyHidden: privacyHidden, walletID: access.activeWalletID, solanaAddress: chains.address(for: .solana), bitcoinAddress: chains.address(for: .bitcoin))
                    .id(access.activeWalletID)
            }
        }
        .sheet(isPresented: $showIDPreview) {
            SpyderIDVisualPreview()
        }
        .sheet(item: $selectedToken) { token in
            WalletTokenDetailView(token: token)
                .environmentObject(chains)
                .environmentObject(publicAssets)
                .environmentObject(history)
                .environmentObject(spider)
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(30)
        }
        .task(id: scenePhase) {
            // Only refresh market prices while this screen is visible and the app is active.
            guard scenePhase == .active else { return }
            await market.refreshQuotes()
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 90_000_000_000) }
                catch { break }
                guard !Task.isCancelled, scenePhase == .active else { break }
                await market.refreshQuotes()
            }
        }
        .task(id: access.activeWalletID) {
            chains.selectAccount(access.activeWalletID)
        }
        .onChange(of: access.activeWalletID) { _, _ in
            history.clear()
            spdSheet = nil
            selectedToken = nil
            showNetworkPortfolio = false
        }
        .onChange(of: access.unlocked) { _, unlocked in
            if !unlocked { showNetworkPortfolio = false; spdSheet = nil }
        }
        .onChange(of: chains.verifiedForReceiving) { _, verified in
            if !verified { showNetworkPortfolio = false }
        }
        .task(id: chains.addresses) {
            if chains.addresses.isEmpty && !chains.isLoading {
                chains.activate()
            } else if !chains.addresses.isEmpty {
                await refreshWallet()
            }
        }
        .alert("Не удалось создать адреса", isPresented: Binding(
            get: { chains.errorMessage != nil },
            set: { if !$0 { chains.errorMessage = nil } }
        )) {
            Button("Понятно", role: .cancel) { chains.errorMessage = nil }
        } message: { Text(chains.errorMessage ?? "") }
    }

    private func refreshWallet() async {
        if spider.address != nil && spider.hasConfiguration { await spider.refresh() }
        guard !chains.addresses.isEmpty else { return }
        async let balances: Void = publicAssets.refresh(addresses: chains.addresses)
        async let activity: Void = history.refresh(addresses: chains.addresses)
        _ = await (balances, activity)
    }

    private var walletHeader: some View {
        HStack(spacing: 8) {
            Button { onAction(.accounts) } label: {
                HStack(spacing: 8) {
                    Image(systemName: "wallet.pass")
                        .font(.body.weight(.medium))
                    Text(access.activeAccountName)
                        .font(.headline)
                        .lineLimit(1)
                    Image(systemName: "chevron.down")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(WalletTheme.secondary)
                }
                .frame(minHeight: 44)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Выбрать кошелёк")
            .accessibilityValue(Text(access.activeAccountName))
            Spacer(minLength: 4)
            headerButton("clock", label: "История операций", action: onActivity)
            headerButton("person.crop.circle", label: "Профиль", action: onControlCenter)
        }
        .foregroundStyle(WalletTheme.ink)
        .frame(maxWidth: 660)
        .frame(maxWidth: .infinity)
    }

    private func headerButton(_ icon: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.title3.weight(.regular))
                .frame(width: 44, height: 44)
                .contentShape(Rectangle())
        }
        .foregroundStyle(WalletTheme.ink)
        .buttonStyle(.plain)
        .accessibilityLabel(Text(LocalizedStringKey(label)))
    }

    private var portfolioCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 2) {
                Text("Общий баланс")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(WalletTheme.secondary)
                headerButton(privacyHidden ? "eye.slash" : "eye",
                             label: privacyHidden ? "Показать баланс" : "Скрыть баланс") {
                    withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.18)) { privacyHidden.toggle() }
                    UISelectionFeedbackGenerator().selectionChanged()
                }
                Spacer()
                if !privacyHidden {
                    Text("USD")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(WalletTheme.secondary)
                }
                headerButton("arrow.clockwise", label: "Обновить балансы") {
                    Task {
                        await market.refreshQuotes(force: true)
                        await refreshWallet()
                    }
                }
                .disabled(publicAssets.loading)
            }
            Text(privacyHidden ? "••••••" : (publicAssets.totalUSD.map {
                "$" + WalletPublicAssetsStore.formatted($0, fractionDigits: 2)
            } ?? "—"))
                .font(.system(size: balanceSize, weight: .semibold))
                .monospacedDigit()
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .foregroundStyle(WalletTheme.ink)
                .privacySensitive()
            Text("Основные сети")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(WalletTheme.secondary)
            Text(publicAssets.totalUSD == nil ? "Ожидаем данные из сетей" :
                 publicAssets.isPartialEstimate ? "Неполная оценка портфеля" : "Оценка по текущим котировкам")
                .font(.footnote)
                .foregroundStyle(WalletTheme.secondary)
            if let updatedAt = publicAssets.updatedAt {
                HStack(spacing: 4) {
                    Text("Обновлено")
                    Text(updatedAt, style: .time)
                }
                    .font(.caption)
                    .foregroundStyle(WalletTheme.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var networkPortfolioEntry: some View {
        Button {
            if access.unlocked && chains.verifiedForReceiving && chains.verifiedWalletID == access.activeWalletID {
                showNetworkPortfolio = true
            } else {
                chains.activate()
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "network").font(.title3)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Networks & Routes").font(.subheadline.weight(.semibold))
                    Text(LocalizedStringKey(chains.verifiedForReceiving ? "Network balances · Swap & Bridge preview" : "Verify wallet to view networks"))
                        .font(.caption).foregroundStyle(WalletTheme.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.semibold))
            }
            .foregroundStyle(WalletTheme.ink)
            .padding(16)
            .background(WalletTheme.surface, in: RoundedRectangle(cornerRadius: 22))
        }
        .buttonStyle(.plain)
        .disabled(chains.isLoading)
    }

    private var marketEntry: some View {
        Button {
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                selectedSection = WalletHomeSection.cryptocurrencies.rawValue
            }
            UISelectionFeedbackGenerator().selectionChanged()
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "chart.line.uptrend.xyaxis")
                    .font(.title3)
                    .frame(width: 36, height: 44)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Рынок криптовалют")
                        .font(.subheadline.weight(.semibold))
                    Text("Курсы и каталог · не баланс кошелька")
                        .font(.caption)
                        .foregroundStyle(WalletTheme.secondary)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(WalletTheme.secondary)
            }
            .foregroundStyle(WalletTheme.ink)
            .padding(16)
            .background(WalletTheme.surface, in: RoundedRectangle(cornerRadius: 22))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityHint("Посмотреть курсы. Это не средства на вашем кошельке.")
    }

    private var marketNavigationHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button {
                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                    selectedSection = WalletHomeSection.assets.rawValue
                }
                UISelectionFeedbackGenerator().selectionChanged()
            } label: {
                Label("Вернуться в кошелёк", systemImage: "chevron.left")
                    .font(.subheadline.weight(.semibold))
                    .frame(minHeight: 44)
            }
            .buttonStyle(.plain)
            Text("Рынок криптовалют")
                .font(.title2.bold())
            Text("Курсы и наблюдение. Монеты из каталога не добавлены к вашему балансу.")
                .font(.subheadline)
                .foregroundStyle(WalletTheme.secondary)
        }
        .foregroundStyle(WalletTheme.ink)
    }

    private var marketStrip: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Рынок")
                    .font(.system(size: 16, weight: .semibold))
                Spacer()
                Text(live.ticks.values.contains(where: { $0.isFresh() })
                     ? NSLocalizedString("LIVE · Coinbase / CoinGecko 24ч", comment: "")
                     : NSLocalizedString("CoinGecko · USD", comment: ""))
                    .font(.footnote)
                    .foregroundStyle(WalletTheme.secondary)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 9) {
                    ForEach([SpyderChain.bitcoin, .ethereum, .solana]) { chain in
                        Button { expandedMarket = WalletMarketSelection(ticker: chain.ticker) } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(chain.ticker)
                                    .font(.footnote.weight(.semibold))
                                    .foregroundStyle(WalletTheme.secondary)
                                Text(live.tick(chain.ticker).map { WalletMarketFormatting.price($0.usdPrice) } ?? market.quote(chain.ticker).flatMap { $0.isStale() ? nil : WalletMarketFormatting.price($0.usdPrice) } ?? "—")
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .monospacedDigit()
                                    .foregroundStyle(WalletTheme.ink)
                                WalletMarketChangeView(ticker: chain.ticker)
                            }
                            .frame(minWidth: 110, alignment: .leading)
                            .padding(14)
                            .background(WalletTheme.surface, in: RoundedRectangle(cornerRadius: 19))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Открыть live-график " + chain.name)
                    }
                }
            }
            if let error = market.quoteError {
                Label(error, systemImage: "wifi.exclamationmark")
                    .font(.footnote)
                    .foregroundStyle(WalletTheme.secondary)
            }
        }
    }

    private var quickActions: some View {
        let layout = dynamicTypeSize.isAccessibilitySize
            ? AnyLayout(VStackLayout(spacing: 8))
            : AnyLayout(HStackLayout(spacing: 10))
        return layout {
            actionButton("Отправить", symbol: "arrow.up.right", primary: true) { chooseSendAsset = true }
            actionButton("Получить", symbol: "arrow.down.left", primary: false) { onAction(.receive) }
        }
    }

    private func actionButton(_ title: String, symbol: String, primary: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(LocalizedStringKey(title), systemImage: symbol)
                .lineLimit(2)
                .multilineTextAlignment(.center)
        }
        .buttonStyle(SpyderActionButtonStyle(primary ? .primary : .secondary))
        .accessibilityHint(Text(primary ? "Проверить реквизиты и комиссию. Отправка зависит от актива и способа подключения." : "Показать проверенный адрес и QR-код"))
    }

    private var assetsSection: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("Поддерживаемые активы · 3 сети")
                .font(.caption)
                .foregroundStyle(WalletTheme.secondary)
            if chains.addresses.isEmpty {
                WalletCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Label("Открыть адреса кошелька", systemImage: "key.horizontal")
                            .font(.system(size: 16, weight: .semibold))
                        Text("Подтверди Face ID или код устройства, чтобы показать адреса и загрузить балансы.")
                            .font(.footnote)
                            .foregroundStyle(WalletTheme.secondary)
                        Button { chains.activate() } label: {
                            HStack {
                                if chains.isLoading { ProgressView().tint(WalletTheme.contrast) }
                                Text(chains.isLoading ? "Открываем…" : "Открыть адреса")
                            }.spyderPrimaryButton()
                        }
                        .disabled(chains.isLoading)
                    }
                }
            } else {
                VStack(spacing: 0) {
                    ForEach([SpyderChain.bitcoin, .ethereum, .solana]) { chain in
                        Button { onAsset(chain) } label: { nativeRow(chain) }
                            .buttonStyle(.plain)
                        assetDivider
                    }
                    ForEach(WalletTokenCatalog.ethereumERC20) { token in
                        Button { selectedToken = token } label: { tokenRow(token) }
                            .buttonStyle(.plain)
                        if token.id != WalletTokenCatalog.ethereumERC20.last?.id { assetDivider }
                    }
                }
                if publicAssets.updatedAt != nil && (publicAssets.isPartialEstimate || !publicAssets.failures.isEmpty || !publicAssets.stablecoinFailures.isEmpty) {
                    Label("Часть балансов или курсов пока недоступна. Пустое значение не означает ноль.", systemImage: "info.circle")
                        .font(.footnote)
                        .foregroundStyle(WalletTheme.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }

    private var assetDivider: some View {
        Divider().padding(.leading, 59)
    }

    private func nativeRow(_ chain: SpyderChain) -> some View {
        HStack(spacing: 12) {
            WalletAssetMark(symbol: chain.symbol, ticker: chain.ticker)
            VStack(alignment: .leading, spacing: 3) {
                Text(chain.name)
                    .font(.system(size: 15, weight: .semibold))
                HStack(spacing: 5) {
                    Text(chain.ticker)
                        .font(.footnote)
                        .foregroundStyle(WalletTheme.secondary)
                    WalletMarketChangeView(ticker: chain.ticker)
                }
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 4) {
                Text(privacyHidden ? "••••" : nativeUSD(chain))
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                Text(privacyHidden ? "••••" : (publicAssets.balances[chain].map {
                    WalletPublicAssetsStore.formatted($0, fractionDigits: 7) + " " + chain.ticker
                } ?? "— " + chain.ticker))
                    .font(.footnote)
                    .foregroundStyle(WalletTheme.secondary)
                    .monospacedDigit()
            }
            Image(systemName: "chevron.right")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(WalletTheme.secondary)
        }
        .foregroundStyle(WalletTheme.ink)
        .padding(.vertical, 14)
        .contentShape(Rectangle())
    }

    private func tokenRow(_ token: WalletVerifiedToken) -> some View {
        HStack(spacing: 12) {
            WalletAssetMark(symbol: "dollarsign", ticker: token.ticker)
            VStack(alignment: .leading, spacing: 3) {
                Text(token.name).font(.system(size: 15, weight: .semibold))
                HStack(spacing: 5) {
                    Text("ERC-20")
                        .font(.footnote).foregroundStyle(WalletTheme.secondary)
                    WalletMarketChangeView(ticker: token.ticker)
                }
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 4) {
                Text(privacyHidden ? "••••" : tokenUSD(token.ticker))
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                Text(privacyHidden ? "••••" : (publicAssets.stablecoins[token.ticker].map {
                    WalletPublicAssetsStore.formatted($0, fractionDigits: 6) + " " + token.ticker
                } ?? "— " + token.ticker))
                    .font(.footnote)
                    .foregroundStyle(WalletTheme.secondary)
                    .monospacedDigit()
            }
            Image(systemName: "chevron.right")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(WalletTheme.secondary)
        }
        .foregroundStyle(WalletTheme.ink)
        .padding(.vertical, 14)
        .contentShape(Rectangle())
    }

    private func chainNetwork(_ chain: SpyderChain) -> String {
        switch chain {
        case .ethereum: "Ethereum"
        case .solana: "Solana"
        case .bitcoin: "Bitcoin"
        }
    }

    private func nativeUSD(_ chain: SpyderChain) -> String {
        guard let balance = publicAssets.balances[chain], let price = publicAssets.prices[chain] else { return "—" }
        return "$" + WalletPublicAssetsStore.formatted(balance * price, fractionDigits: 2)
    }

    private func tokenUSD(_ ticker: String) -> String {
        guard let balance = publicAssets.stablecoins[ticker], let price = publicAssets.stablecoinPrices[ticker] else { return "—" }
        return "$" + WalletPublicAssetsStore.formatted(balance * price, fractionDigits: 2)
    }

    private var recentSection: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Text("Последние операции")
                    .font(.title3.weight(.semibold))
                Spacer()
                Button("Все") { onActivity() }
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(WalletTheme.secondary)
                    .frame(minWidth: 44, minHeight: 44)
                    .accessibilityLabel("Открыть всю историю операций")
            }
            .foregroundStyle(WalletTheme.ink)
            WalletCard {
                if history.recent.isEmpty {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 19))
                            .foregroundStyle(WalletTheme.secondary)
                            .frame(width: 43, height: 43)
                            .background(WalletTheme.canvas, in: Circle())
                        VStack(alignment: .leading, spacing: 5) {
                            Text(history.loading.isEmpty ? "Нет загруженных операций" : "Обновляем историю…")
                                .font(.system(size: 15, weight: .semibold))
                            Text(history.loading.isEmpty ? "Открой историю для проверки сетей и статуса загрузки." : "Получаем последние подтверждения из сетей.")
                                .font(.footnote)
                                .foregroundStyle(WalletTheme.secondary)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                } else {
                    VStack(spacing: 0) {
                        ForEach(Array(history.recent.prefix(3))) { item in
                            Link(destination: item.explorerURL) {
                                HStack(spacing: 12) {
                                    Image(systemName: item.state == .confirmed ? "checkmark" : "clock")
                                        .font(.system(size: 16, weight: .semibold))
                                        .frame(width: 42, height: 42)
                                        .background(WalletTheme.canvas, in: Circle())
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.direction + " · " + item.symbol)
                                            .font(.system(size: 14, weight: .semibold))
                                        Text(item.timestamp?.formatted(date: .abbreviated, time: .shortened) ?? "Дата неизвестна")
                                            .font(.footnote)
                                            .foregroundStyle(WalletTheme.secondary)
                                    }
                                    Spacer(minLength: 3)
                                    Text(privacyHidden ? "••••" : (item.amount.map {
                                        WalletPublicAssetsStore.formatted($0, fractionDigits: 6) + " " + item.symbol
                                    } ?? "—"))
                                        .font(.footnote.weight(.semibold))
                                        .monospacedDigit()
                                }
                                .foregroundStyle(WalletTheme.ink)
                                .padding(.vertical, 8)
                            }
                            if item.id != history.recent.prefix(3).last?.id { Divider() }
                        }
                    }
                }
            }
        }
    }

    private var spdAssetEntry: some View {
        WalletCard {
            VStack(alignment: .leading, spacing: 12) {
                Button { spdSheet = spider.hasConfiguration ? .details : .settings } label: {
                    HStack(spacing: 12) {
                        Image("SpyderLaunchLogo").resizable().scaledToFit().padding(9)
                            .frame(width: 47, height: 47).background(WalletTheme.canvas, in: Circle())
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Spyder Network").font(.headline)
                            Text("SPD · тестовая сеть").font(.footnote).foregroundStyle(WalletTheme.secondary)
                        }
                        Spacer(minLength: 6)
                        VStack(alignment: .trailing, spacing: 4) {
                            Text(privacyHidden ? "••••" : (spider.connected ? spider.balanceText + " SPD" : "— SPD"))
                                .font(.headline.monospacedDigit())
                            Text(spider.connected ? "Подключено" : (spider.hasConfiguration ? "Не проверено" : "Не настроено"))
                                .font(.caption).foregroundStyle(spider.connected ? Color.green : WalletTheme.secondary)
                        }
                        Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(WalletTheme.secondary)
                    }.frame(minHeight: 48).contentShape(Rectangle())
                }.buttonStyle(.plain)
                if !spider.hasConfiguration {
                    Button("Подключить SPD") { spdSheet = .settings }
                        .buttonStyle(SpyderActionButtonStyle(.primary))
                } else if spider.address == nil {
                    Button { spider.selectAccount(access.activeWalletID); spider.deriveAddress() } label: {
                        HStack {
                            if spider.busy { ProgressView().tint(WalletTheme.contrast) }
                            Text(spider.busy ? "Открываем адрес…" : "Открыть SPD")
                        }
                    }.buttonStyle(SpyderActionButtonStyle(.primary)).disabled(spider.busy)
                } else {
                    let layout = dynamicTypeSize.isAccessibilitySize ? AnyLayout(VStackLayout(spacing: 8)) : AnyLayout(HStackLayout(spacing: 8))
                    layout {
                        Button { spdSheet = .send } label: { Label("Отправить", systemImage: "arrow.up.right") }
                            .buttonStyle(SpyderActionButtonStyle(.secondary))
                        Button { spdSheet = .receive } label: { Label("Получить", systemImage: "arrow.down.left") }
                            .buttonStyle(SpyderActionButtonStyle(.secondary))
                    }
                }
                if spider.hasConfiguration {
                    Button { spdSheet = .settings } label: {
                        Label("Настройки сети", systemImage: "gearshape").font(.subheadline)
                            .frame(minHeight: 44)
                    }.buttonStyle(.plain)
                }
                if spider.pendingForAddress != nil {
                    Label("Есть перевод в ожидании", systemImage: "clock").font(.footnote)
                }
                if let error = spider.error {
                    Text(error).font(.footnote).foregroundStyle(WalletTheme.secondary)
                }
            }.foregroundStyle(WalletTheme.ink)
        }
    }

    private var spdDetails: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Тестовый баланс").font(.subheadline).foregroundStyle(WalletTheme.secondary)
                        Text(privacyHidden ? "•••• SPD" : (spider.connected ? spider.balanceText + " SPD" : "— SPD"))
                            .font(.largeTitle.bold()).monospacedDigit().privacySensitive()
                        Label(spider.connected ? "Блок \(spider.certifiedHeight ?? 0) · подтверждено шлюзом" : "Нет свежего подтверждения", systemImage: spider.connected ? "checkmark.seal" : "wifi.exclamationmark")
                            .font(.footnote).foregroundStyle(WalletTheme.secondary)
                        if let date = spider.refreshedAt { Text("Обновлено: \(date.formatted(date: .omitted, time: .standard))").font(.caption).foregroundStyle(WalletTheme.secondary) }
                        if let address = spider.address {
                            Text(address).font(.footnote.monospaced()).textSelection(.enabled).privacySensitive()
                        }
                    }
                    Button {
                        if spider.address == nil { spider.selectAccount(access.activeWalletID); spider.deriveAddress() }
                        else { Task { await spider.refresh() } }
                    } label: {
                        HStack {
                            if spider.refreshing || spider.busy { ProgressView() }
                            Text(spider.address == nil ? "Открыть адрес" : "Обновить баланс")
                        }
                    }.buttonStyle(SpyderActionButtonStyle(.secondary)).disabled(spider.refreshing || spider.busy)
                    if let pending = spider.pendingForAddress {
                        WalletCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Label(pending.queued ? "Ожидает финализации" : "Статус отправки неизвестен", systemImage: "clock").font(.headline)
                                Text(privacyHidden ? "•••• SPD" : SpiderDevnetStore.displayAmount(pending.amountAtomic) + " SPD")
                                Text(pending.id).font(.caption.monospaced()).textSelection(.enabled)
                                if pending.signed != nil {
                                    Button("Повторить доставку той же транзакции") {
                                        Task { do { try await spider.retryPending() } catch { spider.error = error.localizedDescription } }
                                    }.buttonStyle(SpyderActionButtonStyle(.secondary)).disabled(spider.sending || spider.refreshing || !spider.connected)
                                }
                                Text("Не создавай новый перевод, пока этот не разрешён.").font(.footnote).foregroundStyle(WalletTheme.secondary)
                            }
                        }
                    } else if spider.latestExpired != nil {
                        Label("Срок перевода истёк. Транзакция не подтверждена.", systemImage: "clock.badge.exclamationmark").foregroundStyle(WalletTheme.secondary)
                    } else if let confirmed = spider.latestConfirmed {
                        Label("Перевод подтверждён в блоке \(confirmed.height)", systemImage: "checkmark.seal.fill").foregroundStyle(.green)
                    }
                    if let error = spider.error { Text(error).font(.footnote).foregroundStyle(.red) }
                    Text("Операции").font(.title2.bold())
                    if !spider.connected { Text("История может быть устаревшей.").font(.footnote).foregroundStyle(WalletTheme.secondary) }
                    if spider.activities.isEmpty { Text(spider.connected ? "Подтверждённых переводов пока нет" : "Подключи сеть и обнови данные").foregroundStyle(WalletTheme.secondary) }
                    ForEach(spider.activities) { entry in
                        let outgoing = entry.transaction.payload.sender == spider.address
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Label(outgoing ? "Отправлено" : "Получено", systemImage: outgoing ? "arrow.up.right" : "arrow.down.left")
                                Spacer()
                                Text(privacyHidden ? "••••" : SpiderDevnetStore.displayAmount(entry.transaction.payload.amount) + " SPD").monospacedDigit()
                            }.font(.subheadline.weight(.semibold))
                            Text("Блок \(entry.height) · \(entry.id)").font(.caption.monospaced()).foregroundStyle(WalletTheme.secondary).textSelection(.enabled)
                            Divider()
                        }
                    }
                    Text("Изменить сеть: Профиль → Настройки кошелька → Spyder Network · SPD. Тестовые SPD не имеют денежной стоимости.").font(.footnote).foregroundStyle(WalletTheme.secondary)
                }.padding(WalletTheme.pageInset).foregroundStyle(WalletTheme.ink)
            }.background(WalletTheme.canvas)
                .navigationTitle("SPD · Devnet").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Готово") { spdSheet = nil } } }
        }
    }

}

struct WalletActivityView: View {
    @AppStorage("spyder.wallet.privacyHidden") private var privacyHidden = false
    @EnvironmentObject private var history: WalletActivityStore
    @EnvironmentObject private var chains: WalletChainStore
    @EnvironmentObject private var spider: SpiderDevnetStore
    @State private var chainFilter = "all"
    @State private var statusFilter = "all"
    let onBack: () -> Void

    private var selectedChains: [SpyderChain] {
        SpyderChain.allCases.filter { chainFilter == "all" || $0.rawValue == chainFilter }
    }

    private func visibleEntries(_ chain: SpyderChain) -> [WalletChainActivity] {
        (history.activity[chain] ?? [])
            .filter { statusFilter == "all" || $0.state.rawValue == statusFilter }
            .sorted { ($0.timestamp ?? .distantPast) > ($1.timestamp ?? .distantPast) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("История операций")
                        .font(.largeTitle.weight(.bold))
                        .accessibilityAddTraits(.isHeader)
                    Text("Mainnet: публичные API могут показывать неполную историю. Для Solana суммы неизвестны, пока не обработаны изменения балансов транзакций.")
                        .font(.footnote)
                        .foregroundStyle(WalletTheme.secondary)
                }
                HStack {
                    Picker("Сеть", selection: $chainFilter) {
                        Text("Все сети").tag("all")
                        Text("SPD · Devnet").tag("spd")
                        ForEach(SpyderChain.allCases) { chain in
                            Text(chain.name).tag(chain.rawValue)
                        }
                    }
                    Divider().frame(height: 20)
                    Picker("Статус", selection: $statusFilter) {
                        Text("Все операции").tag("all")
                        Text("Подтверждено").tag(WalletChainActivity.State.confirmed.rawValue)
                        Text("Ожидание").tag(WalletChainActivity.State.pending.rawValue)
                        Text("Ошибка").tag(WalletChainActivity.State.failed.rawValue)
                    }
                }
                .pickerStyle(.menu)
                .font(.subheadline)
                .frame(minHeight: 44)
                ForEach(selectedChains) { chain in
                    WalletCard {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text(chain.name).font(.headline)
                                Spacer()
                                if let date = history.updatedAt[chain] {
                                    Text(date.formatted(date: .omitted, time: .shortened))
                                        .font(.caption).foregroundStyle(WalletTheme.secondary)
                                }
                            }
                            if let error = history.errors[chain] {
                                Label("Провайдер недоступен: " + error, systemImage: "wifi.exclamationmark")
                                    .font(.footnote).foregroundStyle(WalletTheme.secondary)
                            }
                            if history.loading.contains(chain) { ProgressView("Загрузка…") }
                            let entries = visibleEntries(chain)
                            if entries.isEmpty && !history.loading.contains(chain) {
                                Text(history.errors[chain] != nil ? "Данные могут быть устаревшими" :
                                     (statusFilter == "all" ? "Нет записей в доступном диапазоне" : "По выбранному статусу операций нет"))
                                    .font(.footnote).foregroundStyle(WalletTheme.secondary)
                            }
                            ForEach(entries) { item in
                                Link(destination: item.explorerURL) {
                                    HStack(spacing: 12) {
                                        Image(systemName: item.state == .confirmed ? "checkmark.circle" : item.state == .pending ? "clock" : "exclamationmark.circle")
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(item.direction).font(.subheadline.weight(.semibold))
                                            Text(item.timestamp?.formatted(date: .abbreviated, time: .shortened) ?? "Дата неизвестна")
                                                .font(.caption).foregroundStyle(WalletTheme.secondary)
                                        }
                                        Spacer()
                                        Text(privacyHidden ? "••••" : (item.amount.map { WalletPublicAssetsStore.formatted($0, fractionDigits: 6) + " " + item.symbol } ?? "—"))
                                            .font(.caption.monospacedDigit())
                                        Image(systemName: "arrow.up.right.square").font(.caption)
                                    }
                                }
                                Divider()
                            }
                        }
                    }
                }
                if chainFilter == "all" || chainFilter == "spd" {
                    Text("Spider Chain · Devnet").font(.headline)
                    WalletCard {
                        VStack(alignment: .leading, spacing: 10) {
                            if !spider.connected { Text("Нет свежего подтверждения SPD").font(.footnote).foregroundStyle(WalletTheme.secondary) }
                            if statusFilter == "all" || statusFilter == WalletChainActivity.State.pending.rawValue, let pending = spider.pendingForAddress {
                                Label("В ожидании · " + (privacyHidden ? "••••" : SpiderDevnetStore.displayAmount(pending.amountAtomic) + " SPD"), systemImage: "clock")
                            }
                            if statusFilter == "all" || statusFilter == WalletChainActivity.State.confirmed.rawValue {
                                if spider.activities.isEmpty { Text("Нет загруженных подтверждённых операций SPD.").font(.footnote) }
                                ForEach(spider.activities) { entry in
                                    let outgoing = entry.transaction.payload.sender == spider.address
                                    Label((outgoing ? "Отправлено · " : "Получено · ") + (privacyHidden ? "••••" : SpiderDevnetStore.displayAmount(entry.transaction.payload.amount) + " SPD"), systemImage: outgoing ? "arrow.up.right" : "arrow.down.left")
                                        .font(.subheadline)
                                    Text("Блок \(entry.height) · \(entry.id.prefix(14))…").font(.caption.monospaced())
                                }
                            }
                        }
                    }
                }
            }
            .foregroundStyle(WalletTheme.ink).padding(20)
            .frame(maxWidth: 700)
            .frame(maxWidth: .infinity)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: onBack) {
                    Image(systemName: "chevron.backward")
                }
                .accessibilityLabel("Назад")
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await history.refresh(addresses: chains.addresses); await spider.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .accessibilityLabel("Обновить")
                .disabled(!history.loading.isEmpty)
            }
        }
        .background(WalletTheme.canvas.ignoresSafeArea())
        .task(id: chains.addresses) { await history.refresh(addresses: chains.addresses) }
    }
}
