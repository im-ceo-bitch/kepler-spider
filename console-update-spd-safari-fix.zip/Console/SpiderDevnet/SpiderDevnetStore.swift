import Foundation
import Combine
import CryptoKit
import Security
import LocalAuthentication

// Device-only credentials; never put the token, signing key or mnemonic in UserDefaults.
private enum SpiderDevnetCredentials {
    static let service = "com.spyder.wallet.devnet.gateway.v1"
    static let account = "bearer-token"

    static func load() throws -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let result = SecItemCopyMatching(query as CFDictionary, &item)
        if result == errSecItemNotFound { return nil }
        guard result == errSecSuccess, let data = item as? Data,
              let string = String(data: data, encoding: .utf8) else {
            throw SpiderDevnetStoreError.keychain(result)
        }
        return string
    }

    static func save(_ token: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let data = Data(token.utf8)
        let result = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if result == errSecSuccess { return }
        guard result == errSecItemNotFound else { throw SpiderDevnetStoreError.keychain(result) }
        var newItem = query
        newItem[kSecValueData as String] = data
        newItem[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let created = SecItemAdd(newItem as CFDictionary, nil)
        guard created == errSecSuccess else { throw SpiderDevnetStoreError.keychain(created) }
    }
}

struct SpiderGatewayConfiguration: Codable {
    var origin: String
    var genesisHash: String
    let chainID = "spider-devnet-1"
    private enum CodingKeys: String, CodingKey { case origin, genesisHash }
}

struct SpiderPendingTransfer: Codable {
    let id: String
    let sender: String
    let recipient: String
    let amountAtomic: UInt64
    let genesisHash: String
    let nonce: UInt64
    let expiryHeight: UInt64
    var queued: Bool
    // Optional for compatibility with pending records saved by previous app builds.
    // This is a signed PUBLIC envelope, never a seed or a private key.
    let signed: SpiderSignedTransfer?
}

struct SpiderCompletedTransfer {
    let id: String
    let height: UInt64
    let blockHash: String
}

enum SpiderDevnetStoreError: LocalizedError {
    case notConfigured, noWalletAddress, pendingTransfer, wrongSigner, invalidRecipient, invalidAmount, wrongConfiguration, pendingPersistence, retryUnavailable, keychain(OSStatus)

    var errorDescription: String? {
        switch self {
        case .notConfigured: "Сначала настройте HTTPS-шлюз Spider Devnet в профиле."
        case .noWalletAddress: "Сначала откройте SPD-адрес с подтверждением Face ID."
        case .pendingTransfer: "Есть незавершённая отправка. Сначала проверьте её финализацию, чтобы не повторить nonce."
        case .wrongSigner: "Ключ не совпадает с ранее полученным SPD-адресом. Отправка заблокирована."
        case .invalidRecipient: "Некорректный адрес Bech32m spider1… или попытка отправить себе."
        case .invalidAmount: "Введите положительную сумму SPD, до 9 цифр после запятой."
        case .wrongConfiguration: "Укажите HTTPS-адрес (без пути), 64-символьный genesis hash и 64-символьный токен."
        case .pendingPersistence: "Не удалось сохранить неподтверждённую транзакцию. Отправка остановлена."
        case .retryUnavailable: "Старая транзакция без сохранённой подписи. Проверьте её статус, не создавайте новый перевод с тем же nonce."
        case .keychain(let status): "Keychain недоступен (код \(status))."
        }
    }
}

@MainActor
final class SpiderDevnetStore: ObservableObject {
    private static let configurationKey = "spyder.devnet.v1.configuration"
    private static let pendingKey = "spyder.devnet.v1.pending"
    private var sessionEpoch = 0
    private(set) var walletID = WalletVault.legacyID
    @Published private(set) var configuring = false
    @Published private(set) var refreshedAt: Date?

    @Published private(set) var address: String?
    @Published private(set) var busy = false
    @Published private(set) var refreshing = false
    @Published private(set) var sending = false
    @Published private(set) var connected = false
    @Published private(set) var balanceAtomic: UInt64?
    @Published private(set) var certifiedHeight: UInt64?
    @Published private(set) var configuration: SpiderGatewayConfiguration?
    @Published private(set) var pending: SpiderPendingTransfer?
    @Published private(set) var latestConfirmed: SpiderCompletedTransfer?
    @Published private(set) var latestExpired: String?
    @Published private(set) var activities: [SpiderCertifiedHistoryEntry] = []
    @Published var error: String?

    init() {
        if let data = UserDefaults.standard.data(forKey: Self.configurationKey) {
            configuration = try? JSONDecoder().decode(SpiderGatewayConfiguration.self, from: data)
        }
        if let data = UserDefaults.standard.data(forKey: Self.pendingKey) {
            pending = try? JSONDecoder().decode(SpiderPendingTransfer.self, from: data)
        }
    }

    var hasConfiguration: Bool { configuration != nil }
    var balanceText: String { balanceAtomic.map(Self.displayAmount) ?? "—" }
    var pendingForAddress: SpiderPendingTransfer? {
        guard let address, pending?.sender == address,
              pending?.genesisHash == configuration?.genesisHash else { return nil }
        return pending
    }

    nonisolated static func displayAmount(_ units: UInt64) -> String {
        let whole = units / 1_000_000_000
        let remainder = units % 1_000_000_000
        if remainder == 0 { return String(whole) }
        let tail = String(format: "%09llu", remainder)
        return "\(whole).\(tail.replacingOccurrences(of: "0+$", with: "", options: .regularExpression))"
    }

    nonisolated static func validate(_ url: String, genesis: String, token: String) throws -> SpiderGatewayConfiguration {
        guard let address = URL(string: url), address.absoluteString == url,
              address.scheme == "https", address.host != nil,
              !url.contains("@"), address.query == nil, address.fragment == nil,
              address.user == nil, address.password == nil,
              address.path.isEmpty || address.path == "/" else {
            throw SpiderDevnetStoreError.wrongConfiguration
        }
        let hash = genesis.trimmingCharacters(in: .whitespacesAndNewlines)
        _ = try SpiderCertifiedWalletClient(readBaseURL: address, submitBaseURL: address,
             expectedChainID: SpiderDevnetSigner.chainID, expectedGenesisHash: hash,
             devnetBearerToken: token)
        return SpiderGatewayConfiguration(origin: url, genesisHash: hash)
    }

    func configure(origin: String, genesis: String, token: String) async throws {
        guard pending == nil, !sending, !configuring else { throw SpiderDevnetStoreError.pendingTransfer }
        let trimmedOrigin = origin.trimmingCharacters(in: .whitespacesAndNewlines)
        let effectiveToken: String
        if token.isEmpty {
            // A token belongs to one gateway and one genesis; never reuse it silently
            // when the user switches to another host/network.
            guard let previous = configuration,
                  previous.origin == trimmedOrigin,
                  previous.genesisHash == genesis.trimmingCharacters(in: .whitespacesAndNewlines) else {
                throw SpiderDevnetStoreError.wrongConfiguration
            }
            effectiveToken = try SpiderDevnetCredentials.load() ?? ""
        } else { effectiveToken = token.trimmingCharacters(in: .whitespacesAndNewlines) }
        let newConfiguration = try Self.validate(trimmedOrigin, genesis: genesis, token: effectiveToken)
        configuring = true
        let epoch = sessionEpoch
        defer { configuring = false }
        guard let endpoint = URL(string: newConfiguration.origin) else { throw SpiderDevnetStoreError.wrongConfiguration }
        let candidate = try SpiderCertifiedWalletClient(readBaseURL: endpoint, submitBaseURL: endpoint,
            expectedChainID: SpiderDevnetSigner.chainID, expectedGenesisHash: newConfiguration.genesisHash,
            devnetBearerToken: effectiveToken)
        _ = try await candidate.status()
        try Task.checkCancellation()
        guard epoch == sessionEpoch, pending == nil, !sending else { throw SpiderDevnetStoreError.pendingTransfer }
        let configData = try JSONEncoder().encode(newConfiguration)
        if !token.isEmpty { try SpiderDevnetCredentials.save(effectiveToken) }
        UserDefaults.standard.set(configData, forKey: Self.configurationKey)
        configuration = newConfiguration
        sessionEpoch &+= 1  // invalidate responses from any previous network
        connected = false
        balanceAtomic = nil
        certifiedHeight = nil
        activities = []
        latestConfirmed = nil
        latestExpired = nil
        refreshedAt = nil
        error = nil
        // The candidate has verified identity, but balance must be read separately.
    }

    private func client() throws -> SpiderCertifiedWalletClient {
        guard let configuration, let url = URL(string: configuration.origin),
              let token = try SpiderDevnetCredentials.load() else {
            throw SpiderDevnetStoreError.notConfigured
        }
        return try SpiderCertifiedWalletClient(readBaseURL: url, submitBaseURL: url,
               expectedChainID: SpiderDevnetSigner.chainID,
               expectedGenesisHash: configuration.genesisHash, devnetBearerToken: token)
    }

    func selectAccount(_ id: String) {
        guard id != walletID else { return }
        clear()
        walletID = id
    }

    func clear() {
        sessionEpoch &+= 1
        // Screen lock only clears public address and session state. Non-secret pending IDs
        // remain persisted across lock/restart so we never silently reuse a pending nonce.
        address = nil
        connected = false
        balanceAtomic = nil
        certifiedHeight = nil
        activities = []
        latestConfirmed = nil
        latestExpired = nil
        refreshedAt = nil
        error = nil
        // An in-flight authentication remains busy until its own defer runs.
    }

    func deriveAddress() {
        guard !busy else { return }
        busy = true
        error = nil
        let epoch = sessionEpoch
        let selectedWalletID = walletID
        Task {
            defer { busy = false }
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    try SpiderProtocolV1.verifyPublicTestVector()
                    guard SpiderDevnetSigner.verifyProtocolFixture() else { throw SpiderProtocolV1.Failure.badVector }
                    var words = try WalletVault.revealForSigning(id: selectedWalletID, reason: "Открыть адрес SPD", context: LAContext())
                    defer { words.removeAll(keepingCapacity: false) }
                    let key = try SpiderProtocolV1.devnetSigningKey(mnemonic: words.joined(separator: " "))
                    return SpiderDevnetSigner.address(for: key.publicKey.rawRepresentation)
                }.value
                guard epoch == sessionEpoch else { return }
                address = result
                if hasConfiguration { await refresh() }
            } catch {
                if epoch == sessionEpoch { self.error = error.localizedDescription }
            }
        }
    }

    func refresh() async {
        guard let address, hasConfiguration, !refreshing, !configuring else { return }
        refreshing = true
        let epoch = sessionEpoch
        defer { refreshing = false }
        do {
            let client = try client()
            _ = try await client.status()
            let account = try await client.account(address)
            let history = try await client.history(address)
            let status = try await client.status()
            guard epoch == sessionEpoch, self.address == address else { return }
            guard account.height <= status.height, history.allSatisfy({ $0.height <= status.height }),
                  refreshedAt == nil || status.height >= (certifiedHeight ?? 0) else { throw SpiderWalletBridgeError.staleCertifiedState }
            balanceAtomic = account.balances["SPD", default: 0]
            certifiedHeight = status.height
            activities = history.filter { $0.transaction.payload.asset_id == "SPD" }.sorted { $0.height > $1.height }
            connected = true
            refreshedAt = Date()
            if let pending = pendingForAddress {
                let proof = try await client.confirmation(pending.id)
                guard epoch == sessionEpoch, self.address == address else { return }
                if proof.finalized, let height = proof.height, let hash = proof.block_hash {
                    latestConfirmed = SpiderCompletedTransfer(id: pending.id, height: height, blockHash: hash)
                    self.pending = nil
                    UserDefaults.standard.removeObject(forKey: Self.pendingKey)
                    let updated = try await client.account(address)
                    guard epoch == sessionEpoch, self.address == address else { return }
                    balanceAtomic = updated.balances["SPD", default: 0]
                } else if account.height > pending.expiryHeight, account.nonce == pending.nonce {
                    // All certified heights at which this signed payload could be valid have
                    // passed. The canonical certified ledger still has the old nonce and the
                    // tx was never finalized. No future valid inclusion is possible.
                    latestExpired = pending.id
                    self.pending = nil
                    UserDefaults.standard.removeObject(forKey: Self.pendingKey)
                }
            }
            error = nil
        } catch {
            if epoch == sessionEpoch {
                connected = false
                balanceAtomic = nil
                certifiedHeight = nil
                self.error = error.localizedDescription
            }
        }
    }

    // Exact SPD atomic units, never floating point rounding.
    func send(to recipientInput: String, amountText: String) async throws {
        guard !sending, !configuring else { throw SpiderDevnetStoreError.pendingTransfer }
        guard let address else { throw SpiderDevnetStoreError.noWalletAddress }
        guard hasConfiguration else { throw SpiderDevnetStoreError.notConfigured }
        guard pending == nil else { throw SpiderDevnetStoreError.pendingTransfer }
        let recipient = recipientInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard SpiderDevnetSigner.isValidAddress(recipient), recipient != address else {
            throw SpiderDevnetStoreError.invalidRecipient
        }
        guard let amount = try? SpiderProtocolV1.amountUnits(amountText), amount > 0 else {
            throw SpiderDevnetStoreError.invalidAmount
        }
        sending = true
        latestConfirmed = nil
        latestExpired = nil
        let epoch = sessionEpoch
        let selectedWalletID = walletID
        defer { sending = false }
        let client = try client()
        let signingKey = try await Task.detached(priority: .userInitiated) {
            try SpiderProtocolV1.verifyPublicTestVector()
            var words = try WalletVault.revealForSigning(id: selectedWalletID, reason: "Подписать перевод тестовых SPD", context: LAContext())
            defer { words.removeAll(keepingCapacity: false) }
            return try SpiderProtocolV1.devnetSigningKey(mnemonic: words.joined(separator: " "))
        }.value
        guard epoch == sessionEpoch, self.address == address else {
            throw SpiderDevnetStoreError.noWalletAddress
        }
        guard SpiderDevnetSigner.address(for: signingKey.publicKey.rawRepresentation) == address else {
            throw SpiderDevnetStoreError.wrongSigner
        }
        let bridge = SpiderWalletDevnetBridge(client: client)
        guard let genesis = configuration?.genesisHash else { throw SpiderDevnetStoreError.notConfigured }
        _ = try await bridge.sendTestSPD(to: recipient, amountAtomic: amount, signingKey: signingKey) { prepared in
            try await self.recordPrepared(prepared, genesis: genesis, epoch: epoch)
        }
        // HTTP 202 is ONLY queued; keep pending until certified finality is observed.
        if pending?.sender == address, pending?.recipient == recipient, pending?.genesisHash == genesis {
            pending?.queued = true
            if let pending { UserDefaults.standard.set(try JSONEncoder().encode(pending), forKey: Self.pendingKey) }
        }
        await refresh()
    }

    // On network timeout, replay only the previously signed transaction. Creating
    // another signature with the same certified nonce is forbidden until resolved.
    func retryPending() async throws {
        guard !sending, !configuring else { throw SpiderDevnetStoreError.pendingTransfer }
        guard let address, let original = pendingForAddress else {
            throw SpiderDevnetStoreError.noWalletAddress
        }
        guard let signed = original.signed, signed.id() == original.id,
              signed.payload.sender == address,
              signed.payload.recipient == original.recipient,
              signed.payload.amount == original.amountAtomic,
              signed.payload.nonce == original.nonce,
              signed.payload.expiry_height == original.expiryHeight,
              signed.payload.chain_id == SpiderDevnetSigner.chainID else {
            throw SpiderDevnetStoreError.retryUnavailable
        }
        sending = true
        let epoch = sessionEpoch
        defer { sending = false }
        let client = try client()
        let proof = try await client.confirmation(original.id)
        guard epoch == sessionEpoch, self.address == address else {
            throw SpiderDevnetStoreError.noWalletAddress
        }
        if proof.finalized { await refresh(); return }
        let status = try await client.status()
        let account = try await client.account(address)
        guard epoch == sessionEpoch, self.address == address else {
            throw SpiderDevnetStoreError.noWalletAddress
        }
        guard status.height <= original.expiryHeight,
              account.height <= status.height, account.nonce == original.nonce else {
            await refresh()  // May clear a genuinely expired reservation.
            throw SpiderDevnetStoreError.pendingTransfer
        }
        let accepted = try await client.submit(signed)
        guard epoch == sessionEpoch, self.address == address, accepted.id == original.id else {
            throw SpiderWalletBridgeError.invalidFinalityResponse
        }
        pending?.queued = true
        if let pending { UserDefaults.standard.set(try JSONEncoder().encode(pending), forKey: Self.pendingKey) }
        await refresh()
    }

    private func recordPrepared(_ transfer: SpiderQueuedDevnetTransfer, genesis: String, epoch: Int) throws {
        guard epoch == sessionEpoch, address == transfer.from, pending == nil,
              configuration?.genesisHash == genesis else { throw SpiderDevnetStoreError.pendingTransfer }
        let item = SpiderPendingTransfer(id: transfer.id, sender: transfer.from,
                    recipient: transfer.to, amountAtomic: transfer.amountAtomic,
                    genesisHash: genesis, nonce: transfer.nonce,
                    expiryHeight: transfer.expiryHeight, queued: false,
                    signed: transfer.signed)
        pending = item
        let data = try JSONEncoder().encode(item)
        UserDefaults.standard.set(data, forKey: Self.pendingKey)
        guard UserDefaults.standard.synchronize() else {
            throw SpiderDevnetStoreError.pendingPersistence
        }
    }
}
